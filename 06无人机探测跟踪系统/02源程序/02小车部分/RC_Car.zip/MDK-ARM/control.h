#ifndef __CONTROL_H
#define __CONTROL_H
#include "sys.h"


extern int Final_Moto1,Final_Moto2;
extern float Velocity,Turn;
extern int Moto1,Moto2,Final_Moto1,Final_Moto2;    //���PWM���� Ӧ��Motor�� ��Moto�¾�	
extern float Distance;

void Set_Pwm(int moto1,int moto2);
void Control(void);

int myabs(int a);

u16  Linear_Conversion(int moto);

extern u8 cmdFlag;

void Motor_Control(float velocity,float turn);
#endif
