
#include "control.h"	
#include "sys.h"
#include "oled.h"
#include "show.h"
#include "key.h"

#define TURN_RIGHT  Motor_Control( 2500, - 1500)		
#define TURN_LEFT   Motor_Control( 2500,   1500)		
#define GO				  Motor_Control( 4500, 	    0)		
#define BACK  			Motor_Control(-4500, 	    0)		
																						 
#define STOP  			Motor_Control(    0, 	    0)		
																						 

u8 targetFlag;

int Final_Moto1, Final_Moto2;
int Moto1, Moto2, Final_Moto1, Final_Moto2;    //���PWM���� Ӧ��Motor�� ��Moto�¾�	
u8 cmdFlag;
float Distance;

float Velocity, Turn;

int Voltage_Temp, Voltage_Count, Voltage_All;

void Set_Pwm(int moto1, int moto2)
{
    if (moto1 > 0) Right_Direction = 0;
    else Right_Direction = 1;
    if (moto2 > 0) Left_Direction = 0;
    else Left_Direction = 1;
    Final_Moto1 = Linear_Conversion(moto1);  //���Ի�
    Final_Moto2 = Linear_Conversion(moto2);
}

u16 Linear_Conversion(int moto)
{
    u32 temp;
    u16 Linear_Moto;
    temp = 36000000 / (14 + 1) / 13000 * 5000 / myabs(moto);
    if (temp > 65535) Linear_Moto = 65535;
    else Linear_Moto = (u16)temp;
    return Linear_Moto;
}

int myabs(int a)
{
    int temp;
    if (a < 0) temp = -a;
    else temp = a;
    return temp;
}
int cnt = 0;
int speed_cnt = 0;
u8 TIME = 100;
void Control(void)
{
		u8 last_flag = 0;
//		GO;
	
		if(cmdFlag != 0)
		{
//			speed_cnt = speed_cnt <= TIME ? (speed_cnt + 1) : TIME;
			speed_cnt = TIME;
		}
		else
		{
			speed_cnt = speed_cnt > 0 ? (speed_cnt - 1) : 0;
		}
	
    if (speed_cnt > 0)
    {
        switch (targetFlag)   //�������
        {
						case 1: Motor_Control(1500 + 35 * speed_cnt, 0); TIME = 100; break;
            case 2: Motor_Control(- (1500 + 35 * speed_cnt), 0); TIME = 100; break;
            case 3: TURN_LEFT; TIME =15; break;
            case 4: TURN_RIGHT; TIME = 15; break;
            case 5: STOP; TIME = 100; break;
            default: STOP; break;
//            case 1: GO; break;
//            case 2: BACK; break;
//            case 3: TURN_LEFT; break;
//            case 4: TURN_RIGHT; break;
//            case 5: STOP; break;
//            default: STOP; break;
        }
    }
    else
    {
        STOP;
    }
		
		
		
    if (cmdFlag != 0)
    {
        cnt++;
        if (cnt >= TIME)
        {
            cmdFlag = 0;
            cnt = 0;
        }
				last_flag = 1;
    }
}


void Limit_Pwm(void)//����PWM��ֵ 
{
    int Amplitude_H = 5000, Amplitude_L = -5000;
    if (Moto1 < Amplitude_L) Moto1 = Amplitude_L;
    if (Moto1 > Amplitude_H) Moto1 = Amplitude_H;
    if (Moto2 < Amplitude_L) Moto2 = Amplitude_L;
    if (Moto2 > Amplitude_H) Moto2 = Amplitude_H;
}



void Motor_Control(float velocity, float turn)
{
    Moto1 = velocity - turn;                                                //===�������ֵ������PWM
    Moto2 = velocity + turn;                                                //===�������ֵ������PWM
    if (myabs(Moto1) < 1 && myabs(Moto2) < 1) ST = 0;
    else ST = 1;
    Limit_Pwm();
    Set_Pwm(Moto1, Moto2);                                      //===��ֵ��PWM�Ĵ���             

}

void cmd_encoder(uint8_t data)
{
    targetFlag = data - 48;
    cmdFlag = 1;
    cnt = 0;
}

void ultra_encoder(uint8_t data)
{
    static u8 ultra_data[10];
    static int state = 0;
    const u8 N = 20;
    static int temp[N] = { 0 };
    static u8 cnt = 0;
    if (state == 0 && data == 0xA5)   //֡ͷ
    {
        ultra_data[state] = data;
        state++;
    }
    else if (state == 1)
    {
        ultra_data[state] = data;
        state++;
    }
    else if (state == 2)
    {
        ultra_data[state] = data;
			
				/*���������˲�*/
        temp[cnt] = ultra_data[1] << 8 | ultra_data[2];
        cnt = (cnt + 1) % N;
        int sum;
        for (u8 i = 0; i < N; i++)
        {
            sum += temp[i];
        }
        Distance = (float)sum / (float)N;
				
//				DataExchange((int)Distance);
//				printf("%f\r\n", Distance);
				
        state = 0;
    }
    else
    {
        state = 0;
    }
}

#define BYTE0(dwTemp)       ( *( (char *)(&dwTemp)		) )
#define BYTE1(dwTemp)       ( *( (char *)(&dwTemp) + 1) )
#define BYTE2(dwTemp)       ( *( (char *)(&dwTemp) + 2) )
#define BYTE3(dwTemp)       ( *( (char *)(&dwTemp) + 3) )
	
void DataExchange(int data)
{
	u8 data_to_send[10];
	u8 cnt=0;
	
	data_to_send[cnt++] = 0xAA;
	data_to_send[cnt++] = BYTE1(data);
	data_to_send[cnt++] = BYTE0(data);
	
	UartSend(data_to_send,cnt);
}
