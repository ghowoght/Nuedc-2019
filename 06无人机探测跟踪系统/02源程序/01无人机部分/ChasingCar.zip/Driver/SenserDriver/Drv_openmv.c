#include "Drv_openmv.h"
#include "FcData.h"
#include "Math.h"
#include "math.h"
#include "Imu.h"

#define MV_Pixel_X	240.0f * 2.4f//(��������)
#define MV_Pixel_Y	320.0f * 2.4f
#define Shot_field_angle_X	90.0f 
#define Shot_field_angle_Y	115.0f 
#define	P_P2A_X	 MV_Pixel_X / Shot_field_angle_X
#define	P_P2A_Y	 MV_Pixel_Y / Shot_field_angle_Y

#define PC_P2L  0.01f

#define NUM  2
typedef struct
{
 float Position[NUM];//λ�ù�����
 float Speed[NUM];//�ٶȹ�����
 float Acceleration[NUM];//���ٶȹ�����
 float Pos_History[NUM];//��ʷ�ߵ�λ��
 float Vel_History[NUM];//��ʷ�ߵ��ٶ�
 float Acce_Bias[NUM];//�ߵ����ٶ�Ư����������
 float Last_Acceleration[NUM];
 float Last_Speed[NUM];
}SINS;

SINS openmv_sins;

u8 openmv_datatemp[20];  //���յ������ݻ���

/*
 *openmv���ڽ��ս�����ʽ
 *
 *					1		  |		  2	  	|	  	3		  |	  	4		  ~			7		  |			 8		  ~	  	11	  	|	
 *				 
 *(Ѱ��) 	֡ͷ		  	ģʽ��	 		��ɫ����		  				X								   		  	Y 							
 *
 *(Ѳ��) 	֡ͷ				ģʽ				�ո�			 				 rho							  			theta 	 				 	
 *
 */

/*Ѱ�����*/
u16 openmv_X_coordinate;	
u16 openmv_Y_coordinate;
int Transform_X_coordinate;
int Transform_Y_coordinate;

int True_X_coordinate_pix;
int True_Y_coordinate_pix;
float True_X_coordinate_len;
float True_Y_coordinate_len;
float P_c_x;		//Proportionality coefficient	����ϵ��
float P_c_y;

_vector2_st openmv_point[2];
_vector2_st last_point;

u8 color_code_name;

/*Ѳ�߱���*/
_line_st line;

u16 openmv_rho;
u16 openmv_theta;


void OPENMV_GetOneByte(uint8_t data)
{
	static u8 state = 0;
	
	if(state == 0 && data == 'A')						//֡ͷ	
	{
		state = 1;
		openmv_datatemp[0] = data;
	}
	else if(state == 1)											//ģʽ
	{
		state = 2;
		openmv_datatemp[1] = data - 48;
	}
	else if(state == 2 )											
	{
		state = 3;
		openmv_datatemp[2] = data;
	}
	
/*��һ������*/
	else if(state == 3)			
	{
		state = 4;
		openmv_datatemp[3] = data - 48;
	}
	else if(state == 4)			
	{
		state = 5;
		openmv_datatemp[4] = data - 48;
	}
	else if(state == 5)			
	{
		state = 6;
		openmv_datatemp[5] = data - 48;
	}
	else if(state == 6)			
	{
		state = 7;
		openmv_datatemp[6] = data - 48;
	}
	
/*�ڶ�������*/
	else if(state == 7)			
	{
		state = 8;
		openmv_datatemp[7] = data - 48;
	}
	else if(state == 8)			
	{
		state = 9;
		openmv_datatemp[8] = data - 48;
	}
	else if(state == 9)			
	{
		state = 10;
		openmv_datatemp[9] = data - 48;
	}
	else if(state == 10)			
	{
		state = 0;
		openmv_datatemp[10] = data - 48;
		
		OPENMV_DataAnl(openmv_datatemp);
	}
	else
		state = 0;
}


void OPENMV_DataAnl(uint8_t *data_buf)
{
	u8 openmv_mode = openmv_datatemp[1];  //ģʽ
	
	openmv_mode = TRACK_POINT;
	
	if(openmv_mode == TRACK_POINT)
	{
		flag.ctrl_mode = FOLLOW;
		
		openmv_point[0].x = openmv_datatemp[3] * 1000 + openmv_datatemp[4] * 100 
									 + openmv_datatemp[5] * 10   + openmv_datatemp[6];
		openmv_point[0].y = openmv_datatemp[7] * 1000 + openmv_datatemp[8] * 100 
									 + openmv_datatemp[9] * 10   + openmv_datatemp[10];
		
		openmv_point[0].x /= 10.0;							 
		openmv_point[0].y /= 10.0;
		
		if(openmv_point[0].x == 999 && openmv_point[0].y == 999)  //��⵽Ŀ��
		{
			flag.openmv_loss = 1;
			
			openmv_point[1].x = last_point.x;							 
			openmv_point[1].y = last_point.y;
		}
		else
		{			
			flag.openmv_loss = 0;
			
			openmv_point[1].x = openmv_point[0].x - 120;							 
			openmv_point[1].y = openmv_point[0].y - 160;
		}

	}
	
	else if(openmv_mode == TRACK_LINE)
	{
		flag.ctrl_mode = TRACK;
		
		line.rho = openmv_datatemp[3] * 1000 + openmv_datatemp[4] * 100 
						 + openmv_datatemp[5] * 10   + openmv_datatemp[6];
		
		line.rho /= 10.0f;
		
		line.rho = line.rho - 40;
		
		line.theta = openmv_datatemp[7] * 1000 + openmv_datatemp[8] * 100 
							 + openmv_datatemp[9] * 10   + openmv_datatemp[10];
		
		line.theta /= 10.0f;
		
		line.theta = line.theta > 90 ? (90 - line.theta): line.theta;
	}
}

#define Ra  30.0f				
#define KALMAN_DT 0.02f
float R[2]={0.5f*Ra*KALMAN_DT*KALMAN_DT,Ra*KALMAN_DT};	
float Q=10;						
#define  Observation_Err_Max   500//pixel
float Pre_conv[4]=
{
  0.18,0.1,				
  0.1,0.18				
};//��һ��Э����

void  KalmanFilter(float Observation,//λ�ù۲���
									 SINS *Ins_Kf,//�ߵ��ṹ��
									 float *R,
                   float Q,
                   float dt,
									 u8 N)							
{
	float Q_Temp = 0;
  float Temp_conv[4] = {0};//����Э����
  float Conv_Z = 0, Cor = 0;
  float k[2] = {0};//�������
  float Ctemp = 0;
	
	Q_Temp= LIMIT (Q,0,1500);
	
  Ins_Kf->Position[N] += Ins_Kf -> Vel_History[N] * dt ;
	
	//����Э����
	Ctemp = Pre_conv[1] + Pre_conv[3] * dt;
	Temp_conv[0] = Pre_conv[0] + Pre_conv[2] * dt + Ctemp*dt + R[0];
	Temp_conv[1] = Ctemp;
	Temp_conv[2] = Pre_conv[2] + Pre_conv[3] * dt;
	Temp_conv[3] = Pre_conv[3] + R[1];
	
	//���㿨��������
	Conv_Z = Temp_conv[0] + Q_Temp;
	k[0] = Temp_conv[0] / Conv_Z;
	k[1] = Temp_conv[2] / Conv_Z;
	
	//�ں��������
	Cor = LIMIT (Observation - Ins_Kf -> Pos_History[N], -Observation_Err_Max, Observation_Err_Max);
	
	Ins_Kf -> Position[N] += k[0] * Cor;
	Ins_Kf -> Speed[N] += k[1] * Cor;
	
	//����״̬Э�������
	Pre_conv[0] = (1 - k[0]) * Temp_conv[0];
	Pre_conv[1] = (1 - k[0]) * Temp_conv[1];
	Pre_conv[2] = Temp_conv[2] - k[1] * Temp_conv[0];
	Pre_conv[3] = Temp_conv[3] - k[1] * Temp_conv[1]; 
	
	Ins_Kf -> Pos_History[N] = Ins_Kf -> Position[N];
	Ins_Kf -> Vel_History[N] = Ins_Kf -> Speed[N];
}

#define LOSS_TIME 2000  // ms
void Get_obs_XY_coordinate(float fix_heigh,u8 dT_ms)
{
	/*����ת���*/
	True_X_coordinate_pix = openmv_point[1].x - P_P2A_X * imu_data.pit;  //С�Ƕ�ģ�͵�Ч
	True_Y_coordinate_pix = openmv_point[1].y - P_P2A_Y * imu_data.rol;

	static int cnt = 0;
	
	if(flag.openmv_loss == 1)
	{
		cnt += dT_ms;
		if(cnt >= LOSS_TIME)
		{
			flag.target_loss = 1;  //openmv��Ұ��Ŀ�궪ʧ1s�����ж�Ŀ�궪ʧ
		}
		else
		{
			flag.target_loss = 0;
		}
	}
	else
	{
		flag.target_loss = 0;
		cnt = 0;
	}
	
	if(flag.target_loss == 0)  //���Ŀ��û��ʧ������п������˲�
	{
		KalmanFilter(True_X_coordinate_pix,
							 &openmv_sins,
							 R,
							 Q,
							 2e-2f,
							 X);
		KalmanFilter(True_Y_coordinate_pix,
							 &openmv_sins,
							 R,
							 Q,
							 2e-2f,
							 Y);
		last_point.x = openmv_point[1].x;
		last_point.y = openmv_point[1].y;
	}
	else
	{
		openmv_sins.Position[X] = openmv_sins.Position[Y] = 0;
	}
	
	
	
	True_X_coordinate_len = 1.0* openmv_sins.Position[X];
                          
	True_Y_coordinate_len = 1.0* openmv_sins.Position[Y];
}

