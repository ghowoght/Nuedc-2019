#include "Drv_skz5.h"
#include "FcData.h"


u8 tof_datatemp[13];
u16 tof_skz5_distance_raw;
u16 tof_skz5_distance_queue[N2];
float	Laser_height_mm;


void TOF_GetOneByte(uint8_t data)
{
	static u8 state = 0;
	
	if(state==0&&data==0x7E)		//֡ͷ
	{
		state=1;
		tof_datatemp[0]=data;
	}
	else if(state==1)			//��������ַ
	{
		state=2;
		tof_datatemp[1]=data;
	}
	else if(state==2)			//��������ַ
	{
		state=3;
		tof_datatemp[2]=data;
	}
	else if(state==3)			//״̬�Ĵ���
	{
		state = 4;
		tof_datatemp[3]=data;
	}
	else if(state==4)			//״̬�Ĵ���
	{
		state = 5;
		tof_datatemp[4]=data;
	}
	else if(state==5)			//������ַ 15:12
	{
		state = 6;
		tof_datatemp[5]=data;
	}
	else if(state==6)			//������ַ 11:8
	{
		state = 7;
		tof_datatemp[6]=data;
	}
	else if(state==7)			//������ַ 7:4
	{
		state = 8;
		tof_datatemp[7]=data;
	}
	else if(state==8)			//������ַ 3:0
	{
		state = 9;
		tof_datatemp[8]=data;
	}
	else if(state==9)			//����ֵ 15:12
	{
		state = 10;
		tof_datatemp[9]=data;
	}
	else if(state==10)		//����ֵ 11:8
	{
		state = 11;
		tof_datatemp[10]=data;
	}
	else if(state==11)		//����ֵ 7:4
	{
		state = 12;
		tof_datatemp[11]=data;
	}
	else if(state==12)		//����ֵ 3:0
	{
		state = 0;
		tof_datatemp[12]=data;
		TOF_DataAnl(tof_datatemp);
	}
	else
		state = 0;
}
void TOF_Queue_Update(u16 heigh_raw)
{
	for(int i = N2 - 1; i > 0; i--)
	{
		tof_skz5_distance_queue[i] = tof_skz5_distance_queue[i-1];//��β����
	}
	
	tof_skz5_distance_queue[0] = heigh_raw;//��������
}

void TOF_DataAnl(uint8_t *data_buf)
{
	tof_skz5_distance_raw = ((tof_datatemp[9] - (tof_datatemp[9] > 0x39? 0x37:0x30)) << 12) + 		// 0x41 - 0x37 = 0x0A
													((tof_datatemp[10] - (tof_datatemp[10] > 0x39? 0x37:0x30)) << 8) + 
													((tof_datatemp[11] - (tof_datatemp[11] > 0x39? 0x37:0x30)) << 4) + 
													(tof_datatemp[12]- (tof_datatemp[12] > 0x39? 0x37:0x30));
	
	TOF_Queue_Update(tof_skz5_distance_raw);
//	tof_skz5_distance = GildeAverageValueFilter_TOF( (float)tof_skz5_distance_raw, tof_skz5_distance_queue );	//���Բ��ڽ����������ڸ߶��ںϵ�ʱ������Ҳ���ԣ���ʡCPU
	
}

void Get_TOF_Height(void)
{
	u32 sum_hei;
	for(int i = N2 - 1; i >= 0; i--)
	{
		sum_hei += tof_skz5_distance_queue[i];
	}
	
	Laser_height_mm = (float)sum_hei / N2;
}



