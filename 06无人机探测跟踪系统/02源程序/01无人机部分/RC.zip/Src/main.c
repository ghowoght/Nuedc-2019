
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  ** This notice applies to any and all portions of this file
  * that are not between comment pairs USER CODE BEGIN and
  * USER CODE END. Other portions of this file, whether 
  * inserted by the user or by software development tools
  * are owned by their respective copyright owners.
  *
  * COPYRIGHT(c) 2019 STMicroelectronics
  *
  * Redistribution and use in source and binary forms, with or without modification,
  * are permitted provided that the following conditions are met:
  *   1. Redistributions of source code must retain the above copyright notice,
  *      this list of conditions and the following disclaimer.
  *   2. Redistributions in binary form must reproduce the above copyright notice,
  *      this list of conditions and the following disclaimer in the documentation
  *      and/or other materials provided with the distribution.
  *   3. Neither the name of STMicroelectronics nor the names of its contributors
  *      may be used to endorse or promote products derived from this software
  *      without specific prior written permission.
  *
  * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
  * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
  * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
  * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
  * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
  * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
  * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
  *
  ******************************************************************************
  */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "stm32f1xx_hal.h"

/* USER CODE BEGIN Includes */
#include "math.h"

/* USER CODE END Includes */

/* Private variables ---------------------------------------------------------*/
ADC_HandleTypeDef hadc1;
DMA_HandleTypeDef hdma_adc1;

TIM_HandleTypeDef htim1;

UART_HandleTypeDef huart1;
UART_HandleTypeDef huart3;

/* USER CODE BEGIN PV */
/* Private variables ---------------------------------------------------------*/

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_DMA_Init(void);
static void MX_ADC1_Init(void);
static void MX_USART1_UART_Init(void);
static void MX_USART3_UART_Init(void);
static void MX_TIM1_Init(void);

/* USER CODE BEGIN PFP */
/* Private function prototypes -----------------------------------------------*/
uint32_t AD_Value[100];

typedef struct
{
	uint16_t voltage;
	int32_t  alt;
	int32_t  alt_add;
	int16_t  yaw;	
	int16_t  target;	
	int16_t  uv_loc;
	uint8_t	 task;
	uint8_t  last_task;
}status_st;

status_st status={0,0,0,0};

uint8_t data;

void data_encoder(uint8_t data);

/* USER CODE END PFP */

/* USER CODE BEGIN 0 */

#ifdef __GNUC__ 
	#define PUTCHAR_PROTOTYPE int __io_putchar(int ch) 
#else 
	#define PUTCHAR_PROTOTYPE int fputc(int ch, FILE *f) 
#endif /* __GNUC__ */ 
 
	PUTCHAR_PROTOTYPE 
	{ 
		HAL_UART_Transmit(&huart1, (uint8_t *)&ch, 1, 0xFFFF); 
		return ch; 
	} 

void Key_Scan_Left(void)
{
	if(PAin(3))
	{
		HAL_Delay(50);
		if(PAin(3))
		{
			while(PAin(3)){};
			PAout(4)=~PAout(4);
			{
				cmd[0]=0x61;
				cmd[1]=0;
				cmd[2]=0;
				cmd[3]=1;
				cmd[4]=0;
				cmd[5]=0;
				cmd[6]=0;
				UartSend(cmd,7);
			}
		}
	}
}

void Key_Scan_Right(void)
{
	if(PAin(8))
	{
		HAL_Delay(50);
		if(PAin(8))
		{
			while(PAin(8)){};
			PAout(4)=~PAout(4);
			cmd[0]=0x61;
			cmd[1]=0;
			cmd[2]=0;
			cmd[3]=0;
			cmd[4]=1;
			cmd[5]=0;
			cmd[6]=0;
			UartSend(cmd,7);
		}
	}
}

	
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  *
  * @retval None
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration----------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_ADC1_Init();
  MX_USART1_UART_Init();
  MX_USART3_UART_Init();
  MX_TIM1_Init();
  /* USER CODE BEGIN 2 */

	OLED_Init();

	HAL_TIM_Base_Start_IT(&htim1);
	HAL_ADC_Start_DMA(&hadc1,(uint32_t*)&AD_Value,100);
	OLED_ShowString(25,10,"Initial Mode");;
	OLED_Refresh_Gram();	
	
	HAL_UART_Receive_IT(&huart3,&data,1);
	
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
		Key_Scan_Left();
		Key_Scan_Right();
		
  /* USER CODE END WHILE */

  /* USER CODE BEGIN 3 */

  }
  /* USER CODE END 3 */

}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{

  RCC_OscInitTypeDef RCC_OscInitStruct;
  RCC_ClkInitTypeDef RCC_ClkInitStruct;
  RCC_PeriphCLKInitTypeDef PeriphClkInit;

    /**Initializes the CPU, AHB and APB busses clocks 
    */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = 16;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI_DIV2;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL16;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

    /**Initializes the CPU, AHB and APB busses clocks 
    */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

  PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_ADC;
  PeriphClkInit.AdcClockSelection = RCC_ADCPCLK2_DIV6;
  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

    /**Configure the Systick interrupt time 
    */
  HAL_SYSTICK_Config(HAL_RCC_GetHCLKFreq()/1000);

    /**Configure the Systick 
    */
  HAL_SYSTICK_CLKSourceConfig(SYSTICK_CLKSOURCE_HCLK);

  /* SysTick_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(SysTick_IRQn, 0, 0);
}

/* ADC1 init function */
static void MX_ADC1_Init(void)
{

  ADC_ChannelConfTypeDef sConfig;

    /**Common config 
    */
  hadc1.Instance = ADC1;
  hadc1.Init.ScanConvMode = ADC_SCAN_ENABLE;
  hadc1.Init.ContinuousConvMode = ENABLE;
  hadc1.Init.DiscontinuousConvMode = DISABLE;
  hadc1.Init.ExternalTrigConv = ADC_SOFTWARE_START;
  hadc1.Init.DataAlign = ADC_DATAALIGN_RIGHT;
  hadc1.Init.NbrOfConversion = 4;
  if (HAL_ADC_Init(&hadc1) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

    /**Configure Regular Channel 
    */
  sConfig.Channel = ADC_CHANNEL_0;
  sConfig.Rank = ADC_REGULAR_RANK_1;
  sConfig.SamplingTime = ADC_SAMPLETIME_1CYCLE_5;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

    /**Configure Regular Channel 
    */
  sConfig.Channel = ADC_CHANNEL_2;
  sConfig.Rank = ADC_REGULAR_RANK_2;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

    /**Configure Regular Channel 
    */
  sConfig.Channel = ADC_CHANNEL_6;
  sConfig.Rank = ADC_REGULAR_RANK_3;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

    /**Configure Regular Channel 
    */
  sConfig.Channel = ADC_CHANNEL_8;
  sConfig.Rank = ADC_REGULAR_RANK_4;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

}

/* TIM1 init function */
static void MX_TIM1_Init(void)
{

  TIM_ClockConfigTypeDef sClockSourceConfig;
  TIM_MasterConfigTypeDef sMasterConfig;

  htim1.Instance = TIM1;
  htim1.Init.Prescaler = 639;
  htim1.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim1.Init.Period = 999;
  htim1.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim1.Init.RepetitionCounter = 0;
  htim1.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim1) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim1, &sClockSourceConfig) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim1, &sMasterConfig) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

}

/* USART1 init function */
static void MX_USART1_UART_Init(void)
{

  huart1.Instance = USART1;
  huart1.Init.BaudRate = 115200;
  huart1.Init.WordLength = UART_WORDLENGTH_8B;
  huart1.Init.StopBits = UART_STOPBITS_1;
  huart1.Init.Parity = UART_PARITY_NONE;
  huart1.Init.Mode = UART_MODE_TX_RX;
  huart1.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart1.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart1) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

}

/* USART3 init function */
static void MX_USART3_UART_Init(void)
{

  huart3.Instance = USART3;
  huart3.Init.BaudRate = 115200;
  huart3.Init.WordLength = UART_WORDLENGTH_8B;
  huart3.Init.StopBits = UART_STOPBITS_1;
  huart3.Init.Parity = UART_PARITY_NONE;
  huart3.Init.Mode = UART_MODE_TX_RX;
  huart3.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart3.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart3) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

}

/** 
  * Enable DMA controller clock
  */
static void MX_DMA_Init(void) 
{
  /* DMA controller clock enable */
  __HAL_RCC_DMA1_CLK_ENABLE();

  /* DMA interrupt init */
  /* DMA1_Channel1_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA1_Channel1_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(DMA1_Channel1_IRQn);

}

/** Configure pins as 
        * Analog 
        * Input 
        * Output
        * EVENT_OUT
        * EXTI
*/
static void MX_GPIO_Init(void)
{

  GPIO_InitTypeDef GPIO_InitStruct;

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4|GPIO_PIN_15, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_3|GPIO_PIN_4|GPIO_PIN_5, GPIO_PIN_RESET);

  /*Configure GPIO pins : PA3 PA8 */
  GPIO_InitStruct.Pin = GPIO_PIN_3|GPIO_PIN_8;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pins : PA4 PA15 */
  GPIO_InitStruct.Pin = GPIO_PIN_4|GPIO_PIN_15;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pin : PA5 */
  GPIO_InitStruct.Pin = GPIO_PIN_5;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pins : PB3 PB4 PB5 */
  GPIO_InitStruct.Pin = GPIO_PIN_3|GPIO_PIN_4|GPIO_PIN_5;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /* EXTI interrupt init*/
  HAL_NVIC_SetPriority(EXTI3_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(EXTI3_IRQn);

  HAL_NVIC_SetPriority(EXTI9_5_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(EXTI9_5_IRQn);

}

/* USER CODE BEGIN 4 */
u8 flag = 0;

#define W 7
void ShowSmallNum(float num,u8 x,u8 y)
{
//	int flag=0;
//	num=-987.23;
	if(num<0)
	{
		OLED_ShowString(x-W,y,"-");
	}
	else
	{
		OLED_ShowString(x-W,y," ");
	}
	
	num*=100;
	
	OLED_ShowNumber(x+0,y,num/pow(10,4),1,12);
	
	num=(int)num%(int)pow(10,4);
	OLED_ShowNumber(x+W,y,num/pow(10,3),1,12);
	
	num=(int)num%(int)pow(10,3);
	OLED_ShowNumber(x+2*W,y,num/pow(10,2),1,12);
	
	num=(int)num%(int)pow(10,2);
	OLED_ShowNumber(x+4*W,y,num/pow(10,1),1,12);
	
	num=(int)num%(int)pow(10,1);
	OLED_ShowNumber(x+5*W,y,num,1,12);
	
	OLED_ShowString(x+3*W,y,".");
	
}

u8  cmd[10];
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
	static int n=0;
	if(htim==&htim1)
	{		
		if(flag)
		{
			if(status.voltage >= 0 && status.alt_add <= 1500)
				ShowSmallNum(status.voltage/100.0,13,20);
			OLED_ShowString(13+6*W,20,"V");
			
			if(status.alt >= 0 && status.alt <= 500)
				ShowSmallNum(status.alt,83,20);
//			OLED_ShowString(83+6*W,20,"cm");
			
			if(status.alt_add > 0 && status.alt_add <= 500)
				ShowSmallNum(status.alt_add,13,30);
//			OLED_ShowString(13+6*W,30,"cm");
			
//			if(status.yaw >= -360 && status.yaw <= 360)
			ShowSmallNum(status.yaw/100.0,83,30);
//			OLED_ShowString(83+6*W,30,"��");
			
			ShowSmallNum(status.target,13,40);
			
			ShowSmallNum(status.uv_loc,83,40);
			
			
			if(status.last_task != status.task && n%10==0)
			{
				switch(status.task)
				{
					case 0: OLED_ShowString(25,10,"Initial Mode");break;
					case 1: OLED_ShowString(25,10,"  Basic 1   ");break;
					case 2: OLED_ShowString(25,10,"  Basic 2   ");break;
					case 3: OLED_ShowString(25,10,"  Basic 3   ");break;
					case 4: OLED_ShowString(25,10,"  Extra 1   ");break;
					case 5: OLED_ShowString(25,10,"  Extra 2   ");break;
					case 6: OLED_ShowString(25,10,"  Extra 3   ");break;
					default:break;
				}	
				status.last_task = status.task;
			}
			
			OLED_Refresh_Gram();	
			
			flag = 0;
		}
			
		if(n%10==0)
		{
				HAL_UART_Receive_IT(&huart3,&data,1);
				ModeChange_Key();				
		}
		if(n++>=50)
		{
			PAout(4)=~PAout(4);
			OLED_Refresh_Gram();
			HAL_UART_Receive_IT(&huart3,&data,1);
			n=0;
		}
	}
}

void HAL_UART_RxCpltCallback(UART_HandleTypeDef *UartHandle) 
{ 
	if(UartHandle==&huart3)
	{
		HAL_UART_Receive_IT(&huart3,&data,1);
		
		data_encoder(data);
	}
	
}

void UartSend(uint8_t *pData, uint16_t Size)
{
	HAL_UART_Transmit(&huart3,pData,Size,10);
}

void data_encoder(uint8_t data)
{
    static u8 datatemp[20];
    static int state = 0;
    if (state == 0 && (data == 0xAA || data == 0xBB)) 
    {
			if(data == 0xAA)
			{
        datatemp[state] = data;
        state++;
			}
			else
			{
				state = 10;
			}
    }
    else if (state == 1)
    {
        datatemp[state] = data;
        state++;
    }
    else if (state == 2)
    {
        datatemp[state] = data;
        state++;
    }
    else if (state == 3)
    {
        datatemp[state] = data;
        state++;
    }
    else if (state == 4)
    {
        datatemp[state] = data;
        state++;
    }
    else if (state == 5)
    {
        datatemp[state] = data;
        state++;
    }
    else if (state == 6)
    {
        datatemp[state] = data;
        state++;
    }
    else if (state == 7)
    {
        datatemp[state] = data;
        state++;
    }
    else if (state == 8)
    {
        datatemp[state] = data;
        state++;
    }
		 else if (state == 9)
    {
        datatemp[state] = data;
        state++;
    }
		 else if (state == 10)
    {
        datatemp[state] = data;
        state++;
    }
		 else if (state == 11)
    {
        datatemp[state] = data;
        state++;
    }
		 else if (state == 12)
    {
        datatemp[state] = data;
        state++;
    }
		 else if (state == 13)
    {
        datatemp[state] = data;
        state++;
    }
		 else if (state == 14)
    {
        datatemp[state] = data;
        state++;
    }
		 else if (state == 15)
    {
        datatemp[state] = data;
        state++;
    }
		 else if (state == 16)
    {
        datatemp[state] = data;
        state++;
    }
		 else if (state == 17)
    {
        datatemp[state] = data;
        state++;
    }
	  else
    {
        state = 0;
    }

    if (state == 18)
    {
        status.voltage = (uint16_t)((datatemp[1] <<  8) +  datatemp[2]);
			
			  status.alt 		 = ( int32_t)((datatemp[3] << 24) + (datatemp[4] << 16) 
											 +   				  (datatemp[5] <<  8) +  datatemp[6]);
			
			  status.alt_add = ( int32_t)((datatemp[7] << 24) + (datatemp[8] << 16) 
											 +   				  (datatemp[9] <<  8) +  datatemp[10]);
			
			  status.yaw     = ( int16_t)((datatemp[11] << 8) +  datatemp[12]);
			
				status.target  = ( int16_t)((datatemp[13] << 8) +  datatemp[14]);
			
//				status.uv_loc  = ( int16_t)((datatemp[15] << 8) +  datatemp[16]);
					
			  status.task		 =	datatemp[15];	
			
				state = 0;
			
				flag = 1;
    }

}

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @param  file: The file name as string.
  * @param  line: The line in file as a number.
  * @retval None
  */
void _Error_Handler(char *file, int line)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  while(1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t* file, uint32_t line)
{ 
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     tex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

/**
  * @}
  */

/**
  * @}
  */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
