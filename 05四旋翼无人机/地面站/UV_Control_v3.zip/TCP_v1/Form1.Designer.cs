﻿namespace TCP_v1
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Series series2 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Series series3 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Series series4 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.btn_setting = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.btn_para_set_ok = new System.Windows.Forms.Button();
            this.enter_setting = new System.Windows.Forms.Button();
            this.Transmit_TextBox = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.cbb_pid3 = new System.Windows.Forms.ComboBox();
            this.cbb_pid2 = new System.Windows.Forms.ComboBox();
            this.cbb_pid1 = new System.Windows.Forms.ComboBox();
            this.Receive_TextBox = new System.Windows.Forms.TextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.lab_xout = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.txb_xout = new System.Windows.Forms.TextBox();
            this.txb_yout = new System.Windows.Forms.TextBox();
            this.txb_zout = new System.Windows.Forms.TextBox();
            this.txb_roll = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.tbx_accz = new System.Windows.Forms.TextBox();
            this.txb_iout = new System.Windows.Forms.TextBox();
            this.txb_pout = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.txb_fly_enabled = new System.Windows.Forms.TextBox();
            this.txb_dout = new System.Windows.Forms.TextBox();
            this.fly_enabled = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.txb_thr = new System.Windows.Forms.TextBox();
            this.txb_speedz = new System.Windows.Forms.TextBox();
            this.txb_yaw = new System.Windows.Forms.TextBox();
            this.txb_pitch = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.txb_height = new System.Windows.Forms.TextBox();
            this.txb_gz = new System.Windows.Forms.TextBox();
            this.txb_gy = new System.Windows.Forms.TextBox();
            this.txb_gx = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.btn_right = new System.Windows.Forms.Button();
            this.btn_back = new System.Windows.Forms.Button();
            this.btn_ahead = new System.Windows.Forms.Button();
            this.btn_start_stop = new System.Windows.Forms.Button();
            this.btn_left = new System.Windows.Forms.Button();
            this.panel6 = new System.Windows.Forms.Panel();
            this.btn_CW = new System.Windows.Forms.Button();
            this.btn_ACW = new System.Windows.Forms.Button();
            this.panel5 = new System.Windows.Forms.Panel();
            this.chart1 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.panel8 = new System.Windows.Forms.Panel();
            this.btn_h_down = new System.Windows.Forms.Button();
            this.btn_h_up = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.panel9 = new System.Windows.Forms.Panel();
            this.txb_defyaw = new System.Windows.Forms.TextBox();
            this.txb_defpitch = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.txb_defheight = new System.Windows.Forms.TextBox();
            this.txb_defroll = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.panel2.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).BeginInit();
            this.panel8.SuspendLayout();
            this.SuspendLayout();
            // 
            // btn_setting
            // 
            this.btn_setting.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btn_setting.Font = new System.Drawing.Font("幼圆", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btn_setting.ForeColor = System.Drawing.SystemColors.Window;
            this.btn_setting.Location = new System.Drawing.Point(97, 200);
            this.btn_setting.Name = "btn_setting";
            this.btn_setting.Size = new System.Drawing.Size(108, 30);
            this.btn_setting.TabIndex = 6;
            this.btn_setting.Text = "Setting!";
            this.btn_setting.UseVisualStyleBackColor = false;
            this.btn_setting.Click += new System.EventHandler(this.btn_setting_Click);
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel2.Controls.Add(this.button1);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.comboBox3);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Controls.Add(this.comboBox2);
            this.panel2.Controls.Add(this.comboBox1);
            this.panel2.Location = new System.Drawing.Point(9, 12);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(293, 172);
            this.panel2.TabIndex = 1;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button1.Font = new System.Drawing.Font("幼圆", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button1.ForeColor = System.Drawing.SystemColors.Window;
            this.button1.Location = new System.Drawing.Point(97, 116);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(60, 30);
            this.button1.TabIndex = 6;
            this.button1.Text = "创建";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("幼圆", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label3.ForeColor = System.Drawing.SystemColors.Window;
            this.label3.Location = new System.Drawing.Point(23, 15);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(71, 15);
            this.label3.TabIndex = 5;
            this.label3.Text = "协议类型";
            // 
            // comboBox3
            // 
            this.comboBox3.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.comboBox3.Font = new System.Drawing.Font("幼圆", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.comboBox3.ForeColor = System.Drawing.SystemColors.Window;
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.comboBox3.Items.AddRange(new object[] {
            "TCP Server",
            "TCP Client",
            "UDP"});
            this.comboBox3.Location = new System.Drawing.Point(112, 12);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(170, 23);
            this.comboBox3.TabIndex = 4;
            this.comboBox3.Text = "TCP Server";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("幼圆", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label2.ForeColor = System.Drawing.SystemColors.Window;
            this.label2.Location = new System.Drawing.Point(23, 80);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(87, 15);
            this.label2.TabIndex = 3;
            this.label2.Text = "本地端口号";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("幼圆", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.ForeColor = System.Drawing.SystemColors.Window;
            this.label1.Location = new System.Drawing.Point(22, 48);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(87, 15);
            this.label1.TabIndex = 2;
            this.label1.Text = "本地IP地址";
            // 
            // comboBox2
            // 
            this.comboBox2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.comboBox2.Font = new System.Drawing.Font("幼圆", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.comboBox2.ForeColor = System.Drawing.SystemColors.Window;
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Items.AddRange(new object[] {
            "8090"});
            this.comboBox2.Location = new System.Drawing.Point(112, 77);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(170, 23);
            this.comboBox2.TabIndex = 1;
            this.comboBox2.Text = "8090";
            // 
            // comboBox1
            // 
            this.comboBox1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.comboBox1.Font = new System.Drawing.Font("幼圆", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.comboBox1.ForeColor = System.Drawing.SystemColors.Window;
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            ""});
            this.comboBox1.Location = new System.Drawing.Point(112, 45);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(170, 23);
            this.comboBox1.TabIndex = 0;
            this.comboBox1.Text = "192.168.43.108";
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            this.comboBox1.Click += new System.EventHandler(this.btnGetLocalIP_Click);
            // 
            // panel4
            // 
            this.panel4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel4.Controls.Add(this.btn_para_set_ok);
            this.panel4.Controls.Add(this.enter_setting);
            this.panel4.Controls.Add(this.Transmit_TextBox);
            this.panel4.Controls.Add(this.label19);
            this.panel4.Controls.Add(this.label18);
            this.panel4.Controls.Add(this.label17);
            this.panel4.Controls.Add(this.label16);
            this.panel4.Controls.Add(this.cbb_pid3);
            this.panel4.Controls.Add(this.cbb_pid2);
            this.panel4.Controls.Add(this.cbb_pid1);
            this.panel4.Controls.Add(this.btn_setting);
            this.panel4.Location = new System.Drawing.Point(9, 188);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(293, 296);
            this.panel4.TabIndex = 2;
            this.panel4.Tag = "";
            // 
            // btn_para_set_ok
            // 
            this.btn_para_set_ok.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btn_para_set_ok.Font = new System.Drawing.Font("幼圆", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btn_para_set_ok.ForeColor = System.Drawing.SystemColors.Window;
            this.btn_para_set_ok.Location = new System.Drawing.Point(159, 242);
            this.btn_para_set_ok.Name = "btn_para_set_ok";
            this.btn_para_set_ok.Size = new System.Drawing.Size(108, 30);
            this.btn_para_set_ok.TabIndex = 29;
            this.btn_para_set_ok.Text = "OK";
            this.btn_para_set_ok.UseVisualStyleBackColor = false;
            this.btn_para_set_ok.Click += new System.EventHandler(this.btn_para_set_ok_Click);
            // 
            // enter_setting
            // 
            this.enter_setting.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.enter_setting.Font = new System.Drawing.Font("幼圆", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.enter_setting.ForeColor = System.Drawing.SystemColors.Window;
            this.enter_setting.Location = new System.Drawing.Point(45, 242);
            this.enter_setting.Name = "enter_setting";
            this.enter_setting.Size = new System.Drawing.Size(108, 30);
            this.enter_setting.TabIndex = 28;
            this.enter_setting.Text = "Enter Mode";
            this.enter_setting.UseVisualStyleBackColor = false;
            this.enter_setting.Click += new System.EventHandler(this.enter_setting_Click);
            // 
            // Transmit_TextBox
            // 
            this.Transmit_TextBox.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.Transmit_TextBox.Font = new System.Drawing.Font("幼圆", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Transmit_TextBox.ForeColor = System.Drawing.SystemColors.Window;
            this.Transmit_TextBox.Location = new System.Drawing.Point(159, 152);
            this.Transmit_TextBox.Name = "Transmit_TextBox";
            this.Transmit_TextBox.Size = new System.Drawing.Size(100, 24);
            this.Transmit_TextBox.TabIndex = 27;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("幼圆", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label19.ForeColor = System.Drawing.SystemColors.Window;
            this.label19.Location = new System.Drawing.Point(50, 155);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(103, 15);
            this.label19.TabIndex = 26;
            this.label19.Text = "所要设置的值";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("幼圆", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label18.ForeColor = System.Drawing.SystemColors.Window;
            this.label18.Location = new System.Drawing.Point(50, 100);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(71, 15);
            this.label18.TabIndex = 24;
            this.label18.Text = "PID对 象";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("幼圆", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label17.ForeColor = System.Drawing.SystemColors.Window;
            this.label17.Location = new System.Drawing.Point(50, 61);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(79, 15);
            this.label17.TabIndex = 23;
            this.label17.Text = "PID从类型";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("幼圆", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label16.ForeColor = System.Drawing.SystemColors.Window;
            this.label16.Location = new System.Drawing.Point(50, 22);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(71, 15);
            this.label16.TabIndex = 22;
            this.label16.Text = "调整对象";
            // 
            // cbb_pid3
            // 
            this.cbb_pid3.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.cbb_pid3.Font = new System.Drawing.Font("幼圆", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.cbb_pid3.ForeColor = System.Drawing.SystemColors.Window;
            this.cbb_pid3.FormattingEnabled = true;
            this.cbb_pid3.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.cbb_pid3.Items.AddRange(new object[] {
            "P",
            "I",
            "D",
            "IMAX",
            "out_max"});
            this.cbb_pid3.Location = new System.Drawing.Point(135, 97);
            this.cbb_pid3.Name = "cbb_pid3";
            this.cbb_pid3.Size = new System.Drawing.Size(147, 23);
            this.cbb_pid3.TabIndex = 21;
            this.cbb_pid3.Text = "请选择";
            // 
            // cbb_pid2
            // 
            this.cbb_pid2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.cbb_pid2.Font = new System.Drawing.Font("幼圆", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.cbb_pid2.ForeColor = System.Drawing.SystemColors.Window;
            this.cbb_pid2.FormattingEnabled = true;
            this.cbb_pid2.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.cbb_pid2.Items.AddRange(new object[] {
            "x",
            "y",
            "z",
            "-"});
            this.cbb_pid2.Location = new System.Drawing.Point(135, 58);
            this.cbb_pid2.Name = "cbb_pid2";
            this.cbb_pid2.Size = new System.Drawing.Size(147, 23);
            this.cbb_pid2.TabIndex = 20;
            this.cbb_pid2.Text = "请选择";
            // 
            // cbb_pid1
            // 
            this.cbb_pid1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.cbb_pid1.Font = new System.Drawing.Font("幼圆", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.cbb_pid1.ForeColor = System.Drawing.SystemColors.Window;
            this.cbb_pid1.FormattingEnabled = true;
            this.cbb_pid1.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.cbb_pid1.Items.AddRange(new object[] {
            "angle",
            "gyro",
            "height",
            "speed",
            "fly_min",
            "attitude"});
            this.cbb_pid1.Location = new System.Drawing.Point(135, 19);
            this.cbb_pid1.Name = "cbb_pid1";
            this.cbb_pid1.Size = new System.Drawing.Size(147, 23);
            this.cbb_pid1.TabIndex = 19;
            this.cbb_pid1.Text = "请选择";
            this.cbb_pid1.SelectedIndexChanged += new System.EventHandler(this.comboBox4_SelectedIndexChanged);
            // 
            // Receive_TextBox
            // 
            this.Receive_TextBox.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.Receive_TextBox.Font = new System.Drawing.Font("幼圆", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Receive_TextBox.ForeColor = System.Drawing.SystemColors.Window;
            this.Receive_TextBox.Location = new System.Drawing.Point(546, 3);
            this.Receive_TextBox.Multiline = true;
            this.Receive_TextBox.Name = "Receive_TextBox";
            this.Receive_TextBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.Receive_TextBox.Size = new System.Drawing.Size(325, 233);
            this.Receive_TextBox.TabIndex = 3;
            this.Receive_TextBox.TextChanged += new System.EventHandler(this.Receive_TextBox_TextChanged);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button2.Font = new System.Drawing.Font("幼圆", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button2.ForeColor = System.Drawing.SystemColors.Window;
            this.button2.Location = new System.Drawing.Point(566, 242);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(85, 30);
            this.button2.TabIndex = 4;
            this.button2.Text = "清空接收";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // lab_xout
            // 
            this.lab_xout.AutoSize = true;
            this.lab_xout.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.lab_xout.Font = new System.Drawing.Font("幼圆", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lab_xout.ForeColor = System.Drawing.SystemColors.Window;
            this.lab_xout.Location = new System.Drawing.Point(182, 134);
            this.lab_xout.Name = "lab_xout";
            this.lab_xout.Size = new System.Drawing.Size(39, 15);
            this.lab_xout.TabIndex = 0;
            this.lab_xout.Text = "xout";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label5.Font = new System.Drawing.Font("幼圆", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label5.ForeColor = System.Drawing.SystemColors.Window;
            this.label5.Location = new System.Drawing.Point(182, 173);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(39, 15);
            this.label5.TabIndex = 7;
            this.label5.Text = "yout";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label6.Font = new System.Drawing.Font("幼圆", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label6.ForeColor = System.Drawing.SystemColors.Window;
            this.label6.Location = new System.Drawing.Point(182, 212);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(39, 15);
            this.label6.TabIndex = 8;
            this.label6.Text = "zout";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label7.Font = new System.Drawing.Font("幼圆", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label7.ForeColor = System.Drawing.SystemColors.Window;
            this.label7.Location = new System.Drawing.Point(3, 18);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(39, 15);
            this.label7.TabIndex = 9;
            this.label7.Text = "Roll";
            // 
            // txb_xout
            // 
            this.txb_xout.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.txb_xout.Font = new System.Drawing.Font("幼圆", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txb_xout.ForeColor = System.Drawing.SystemColors.Window;
            this.txb_xout.Location = new System.Drawing.Point(252, 131);
            this.txb_xout.Name = "txb_xout";
            this.txb_xout.Size = new System.Drawing.Size(100, 24);
            this.txb_xout.TabIndex = 11;
            // 
            // txb_yout
            // 
            this.txb_yout.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.txb_yout.Font = new System.Drawing.Font("幼圆", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txb_yout.ForeColor = System.Drawing.SystemColors.Window;
            this.txb_yout.Location = new System.Drawing.Point(252, 170);
            this.txb_yout.Name = "txb_yout";
            this.txb_yout.Size = new System.Drawing.Size(100, 24);
            this.txb_yout.TabIndex = 12;
            // 
            // txb_zout
            // 
            this.txb_zout.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.txb_zout.Font = new System.Drawing.Font("幼圆", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txb_zout.ForeColor = System.Drawing.SystemColors.Window;
            this.txb_zout.Location = new System.Drawing.Point(252, 209);
            this.txb_zout.Name = "txb_zout";
            this.txb_zout.Size = new System.Drawing.Size(100, 24);
            this.txb_zout.TabIndex = 13;
            // 
            // txb_roll
            // 
            this.txb_roll.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.txb_roll.Font = new System.Drawing.Font("幼圆", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txb_roll.ForeColor = System.Drawing.SystemColors.Window;
            this.txb_roll.Location = new System.Drawing.Point(67, 15);
            this.txb_roll.Name = "txb_roll";
            this.txb_roll.Size = new System.Drawing.Size(100, 24);
            this.txb_roll.TabIndex = 14;
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Controls.Add(this.txb_defyaw);
            this.panel1.Controls.Add(this.txb_defpitch);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label23);
            this.panel1.Controls.Add(this.txb_defheight);
            this.panel1.Controls.Add(this.txb_defroll);
            this.panel1.Controls.Add(this.label22);
            this.panel1.Controls.Add(this.label21);
            this.panel1.Controls.Add(this.tbx_accz);
            this.panel1.Controls.Add(this.txb_iout);
            this.panel1.Controls.Add(this.txb_pout);
            this.panel1.Controls.Add(this.label24);
            this.panel1.Controls.Add(this.label25);
            this.panel1.Controls.Add(this.label26);
            this.panel1.Controls.Add(this.txb_fly_enabled);
            this.panel1.Controls.Add(this.txb_dout);
            this.panel1.Controls.Add(this.fly_enabled);
            this.panel1.Controls.Add(this.label20);
            this.panel1.Controls.Add(this.txb_thr);
            this.panel1.Controls.Add(this.txb_speedz);
            this.panel1.Controls.Add(this.txb_yaw);
            this.panel1.Controls.Add(this.txb_pitch);
            this.panel1.Controls.Add(this.label12);
            this.panel1.Controls.Add(this.label13);
            this.panel1.Controls.Add(this.label14);
            this.panel1.Controls.Add(this.label15);
            this.panel1.Controls.Add(this.txb_height);
            this.panel1.Controls.Add(this.txb_gz);
            this.panel1.Controls.Add(this.txb_gy);
            this.panel1.Controls.Add(this.txb_gx);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.label10);
            this.panel1.Controls.Add(this.label11);
            this.panel1.Controls.Add(this.button5);
            this.panel1.Controls.Add(this.txb_roll);
            this.panel1.Controls.Add(this.txb_zout);
            this.panel1.Controls.Add(this.txb_yout);
            this.panel1.Controls.Add(this.txb_xout);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.lab_xout);
            this.panel1.Controls.Add(this.button2);
            this.panel1.Controls.Add(this.Receive_TextBox);
            this.panel1.Location = new System.Drawing.Point(308, 188);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(880, 296);
            this.panel1.TabIndex = 0;
            // 
            // tbx_accz
            // 
            this.tbx_accz.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.tbx_accz.Font = new System.Drawing.Font("幼圆", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tbx_accz.ForeColor = System.Drawing.SystemColors.Window;
            this.tbx_accz.Location = new System.Drawing.Point(67, 209);
            this.tbx_accz.Name = "tbx_accz";
            this.tbx_accz.Size = new System.Drawing.Size(100, 24);
            this.tbx_accz.TabIndex = 42;
            // 
            // txb_iout
            // 
            this.txb_iout.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.txb_iout.Font = new System.Drawing.Font("幼圆", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txb_iout.ForeColor = System.Drawing.SystemColors.Window;
            this.txb_iout.Location = new System.Drawing.Point(440, 55);
            this.txb_iout.Name = "txb_iout";
            this.txb_iout.Size = new System.Drawing.Size(100, 24);
            this.txb_iout.TabIndex = 41;
            // 
            // txb_pout
            // 
            this.txb_pout.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.txb_pout.Font = new System.Drawing.Font("幼圆", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txb_pout.ForeColor = System.Drawing.SystemColors.Window;
            this.txb_pout.Location = new System.Drawing.Point(440, 16);
            this.txb_pout.Name = "txb_pout";
            this.txb_pout.Size = new System.Drawing.Size(100, 24);
            this.txb_pout.TabIndex = 40;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label24.Font = new System.Drawing.Font("幼圆", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label24.ForeColor = System.Drawing.SystemColors.Window;
            this.label24.Location = new System.Drawing.Point(3, 212);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(47, 15);
            this.label24.TabIndex = 38;
            this.label24.Text = "Accel";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label25.Font = new System.Drawing.Font("幼圆", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label25.ForeColor = System.Drawing.SystemColors.Window;
            this.label25.Location = new System.Drawing.Point(371, 58);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(39, 15);
            this.label25.TabIndex = 37;
            this.label25.Text = "iout";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label26.Font = new System.Drawing.Font("幼圆", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label26.ForeColor = System.Drawing.SystemColors.Window;
            this.label26.Location = new System.Drawing.Point(371, 19);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(39, 15);
            this.label26.TabIndex = 36;
            this.label26.Text = "pout";
            // 
            // txb_fly_enabled
            // 
            this.txb_fly_enabled.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.txb_fly_enabled.Font = new System.Drawing.Font("幼圆", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txb_fly_enabled.ForeColor = System.Drawing.SystemColors.Window;
            this.txb_fly_enabled.Location = new System.Drawing.Point(252, 253);
            this.txb_fly_enabled.Name = "txb_fly_enabled";
            this.txb_fly_enabled.Size = new System.Drawing.Size(100, 24);
            this.txb_fly_enabled.TabIndex = 35;
            // 
            // txb_dout
            // 
            this.txb_dout.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.txb_dout.Font = new System.Drawing.Font("幼圆", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txb_dout.ForeColor = System.Drawing.SystemColors.Window;
            this.txb_dout.Location = new System.Drawing.Point(440, 94);
            this.txb_dout.Name = "txb_dout";
            this.txb_dout.Size = new System.Drawing.Size(100, 24);
            this.txb_dout.TabIndex = 34;
            // 
            // fly_enabled
            // 
            this.fly_enabled.AutoSize = true;
            this.fly_enabled.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.fly_enabled.Font = new System.Drawing.Font("幼圆", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.fly_enabled.ForeColor = System.Drawing.SystemColors.Window;
            this.fly_enabled.Location = new System.Drawing.Point(183, 256);
            this.fly_enabled.Name = "fly_enabled";
            this.fly_enabled.Size = new System.Drawing.Size(55, 15);
            this.fly_enabled.TabIndex = 33;
            this.fly_enabled.Text = "Flying";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label20.Font = new System.Drawing.Font("幼圆", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label20.ForeColor = System.Drawing.SystemColors.Window;
            this.label20.Location = new System.Drawing.Point(371, 97);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(39, 15);
            this.label20.TabIndex = 32;
            this.label20.Text = "dout";
            // 
            // txb_thr
            // 
            this.txb_thr.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.txb_thr.Font = new System.Drawing.Font("幼圆", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txb_thr.ForeColor = System.Drawing.SystemColors.Window;
            this.txb_thr.Location = new System.Drawing.Point(67, 253);
            this.txb_thr.Name = "txb_thr";
            this.txb_thr.Size = new System.Drawing.Size(100, 24);
            this.txb_thr.TabIndex = 31;
            // 
            // txb_speedz
            // 
            this.txb_speedz.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.txb_speedz.Font = new System.Drawing.Font("幼圆", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txb_speedz.ForeColor = System.Drawing.SystemColors.Window;
            this.txb_speedz.Location = new System.Drawing.Point(67, 170);
            this.txb_speedz.Name = "txb_speedz";
            this.txb_speedz.Size = new System.Drawing.Size(100, 24);
            this.txb_speedz.TabIndex = 30;
            // 
            // txb_yaw
            // 
            this.txb_yaw.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.txb_yaw.Font = new System.Drawing.Font("幼圆", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txb_yaw.ForeColor = System.Drawing.SystemColors.Window;
            this.txb_yaw.Location = new System.Drawing.Point(67, 94);
            this.txb_yaw.Name = "txb_yaw";
            this.txb_yaw.Size = new System.Drawing.Size(100, 24);
            this.txb_yaw.TabIndex = 29;
            // 
            // txb_pitch
            // 
            this.txb_pitch.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.txb_pitch.Font = new System.Drawing.Font("幼圆", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txb_pitch.ForeColor = System.Drawing.SystemColors.Window;
            this.txb_pitch.Location = new System.Drawing.Point(67, 55);
            this.txb_pitch.Name = "txb_pitch";
            this.txb_pitch.Size = new System.Drawing.Size(100, 24);
            this.txb_pitch.TabIndex = 28;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label12.Font = new System.Drawing.Font("幼圆", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label12.ForeColor = System.Drawing.SystemColors.Window;
            this.label12.Location = new System.Drawing.Point(3, 257);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(31, 15);
            this.label12.TabIndex = 27;
            this.label12.Text = "Thr";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label13.Font = new System.Drawing.Font("幼圆", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label13.ForeColor = System.Drawing.SystemColors.Window;
            this.label13.Location = new System.Drawing.Point(3, 173);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(47, 15);
            this.label13.TabIndex = 26;
            this.label13.Text = "Speed";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label14.Font = new System.Drawing.Font("幼圆", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label14.ForeColor = System.Drawing.SystemColors.Window;
            this.label14.Location = new System.Drawing.Point(3, 97);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(31, 15);
            this.label14.TabIndex = 25;
            this.label14.Text = "Yaw";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label15.Font = new System.Drawing.Font("幼圆", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label15.ForeColor = System.Drawing.SystemColors.Window;
            this.label15.Location = new System.Drawing.Point(3, 58);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(47, 15);
            this.label15.TabIndex = 24;
            this.label15.Text = "Pitch";
            // 
            // txb_height
            // 
            this.txb_height.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.txb_height.Font = new System.Drawing.Font("幼圆", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txb_height.ForeColor = System.Drawing.SystemColors.Window;
            this.txb_height.Location = new System.Drawing.Point(67, 130);
            this.txb_height.Name = "txb_height";
            this.txb_height.Size = new System.Drawing.Size(100, 24);
            this.txb_height.TabIndex = 23;
            // 
            // txb_gz
            // 
            this.txb_gz.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.txb_gz.Font = new System.Drawing.Font("幼圆", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txb_gz.ForeColor = System.Drawing.SystemColors.Window;
            this.txb_gz.Location = new System.Drawing.Point(252, 94);
            this.txb_gz.Name = "txb_gz";
            this.txb_gz.Size = new System.Drawing.Size(100, 24);
            this.txb_gz.TabIndex = 22;
            // 
            // txb_gy
            // 
            this.txb_gy.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.txb_gy.Font = new System.Drawing.Font("幼圆", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txb_gy.ForeColor = System.Drawing.SystemColors.Window;
            this.txb_gy.Location = new System.Drawing.Point(252, 55);
            this.txb_gy.Name = "txb_gy";
            this.txb_gy.Size = new System.Drawing.Size(100, 24);
            this.txb_gy.TabIndex = 21;
            // 
            // txb_gx
            // 
            this.txb_gx.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.txb_gx.Font = new System.Drawing.Font("幼圆", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txb_gx.ForeColor = System.Drawing.SystemColors.Window;
            this.txb_gx.Location = new System.Drawing.Point(252, 16);
            this.txb_gx.Name = "txb_gx";
            this.txb_gx.Size = new System.Drawing.Size(100, 24);
            this.txb_gx.TabIndex = 20;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label8.Font = new System.Drawing.Font("幼圆", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label8.ForeColor = System.Drawing.SystemColors.Window;
            this.label8.Location = new System.Drawing.Point(3, 133);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(55, 15);
            this.label8.TabIndex = 19;
            this.label8.Text = "Height";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label9.Font = new System.Drawing.Font("幼圆", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label9.ForeColor = System.Drawing.SystemColors.Window;
            this.label9.Location = new System.Drawing.Point(183, 97);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(55, 15);
            this.label9.TabIndex = 18;
            this.label9.Text = "Gyro_z";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label10.Font = new System.Drawing.Font("幼圆", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label10.ForeColor = System.Drawing.SystemColors.Window;
            this.label10.Location = new System.Drawing.Point(183, 58);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(55, 15);
            this.label10.TabIndex = 17;
            this.label10.Text = "Gyro_y";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label11.Font = new System.Drawing.Font("幼圆", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label11.ForeColor = System.Drawing.SystemColors.Window;
            this.label11.Location = new System.Drawing.Point(183, 19);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(55, 15);
            this.label11.TabIndex = 16;
            this.label11.Text = "Gyro_x";
            // 
            // panel3
            // 
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel3.Controls.Add(this.panel9);
            this.panel3.Controls.Add(this.panel7);
            this.panel3.Controls.Add(this.panel6);
            this.panel3.Location = new System.Drawing.Point(308, 13);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(880, 171);
            this.panel3.TabIndex = 11;
            // 
            // panel7
            // 
            this.panel7.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel7.Controls.Add(this.btn_right);
            this.panel7.Controls.Add(this.btn_back);
            this.panel7.Controls.Add(this.btn_ahead);
            this.panel7.Controls.Add(this.btn_start_stop);
            this.panel7.Controls.Add(this.btn_left);
            this.panel7.Location = new System.Drawing.Point(-2, -2);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(228, 171);
            this.panel7.TabIndex = 17;
            this.panel7.Tag = "";
            // 
            // btn_right
            // 
            this.btn_right.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btn_right.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btn_right.Font = new System.Drawing.Font("幼圆", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btn_right.ForeColor = System.Drawing.Color.White;
            this.btn_right.Location = new System.Drawing.Point(154, 62);
            this.btn_right.Name = "btn_right";
            this.btn_right.Size = new System.Drawing.Size(67, 102);
            this.btn_right.TabIndex = 10;
            this.btn_right.Text = "→";
            this.btn_right.UseVisualStyleBackColor = false;
            this.btn_right.Click += new System.EventHandler(this.btn_right_Click);
            // 
            // btn_back
            // 
            this.btn_back.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btn_back.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btn_back.Font = new System.Drawing.Font("幼圆", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btn_back.ForeColor = System.Drawing.Color.White;
            this.btn_back.Location = new System.Drawing.Point(3, 107);
            this.btn_back.Name = "btn_back";
            this.btn_back.Size = new System.Drawing.Size(152, 57);
            this.btn_back.TabIndex = 9;
            this.btn_back.Text = "↓";
            this.btn_back.UseVisualStyleBackColor = false;
            this.btn_back.Click += new System.EventHandler(this.btn_back_Click);
            // 
            // btn_ahead
            // 
            this.btn_ahead.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btn_ahead.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btn_ahead.Font = new System.Drawing.Font("幼圆", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btn_ahead.ForeColor = System.Drawing.Color.White;
            this.btn_ahead.Location = new System.Drawing.Point(76, 3);
            this.btn_ahead.Name = "btn_ahead";
            this.btn_ahead.Size = new System.Drawing.Size(145, 59);
            this.btn_ahead.TabIndex = 8;
            this.btn_ahead.Text = "↑";
            this.btn_ahead.UseVisualStyleBackColor = false;
            this.btn_ahead.Click += new System.EventHandler(this.btn_ahead_Click);
            // 
            // btn_start_stop
            // 
            this.btn_start_stop.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btn_start_stop.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btn_start_stop.Font = new System.Drawing.Font("幼圆", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btn_start_stop.ForeColor = System.Drawing.Color.White;
            this.btn_start_stop.Location = new System.Drawing.Point(76, 62);
            this.btn_start_stop.Name = "btn_start_stop";
            this.btn_start_stop.Size = new System.Drawing.Size(79, 45);
            this.btn_start_stop.TabIndex = 7;
            this.btn_start_stop.Text = "S";
            this.btn_start_stop.UseVisualStyleBackColor = false;
            this.btn_start_stop.Click += new System.EventHandler(this.btn_start_stop_Click);
            // 
            // btn_left
            // 
            this.btn_left.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btn_left.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btn_left.Font = new System.Drawing.Font("幼圆", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btn_left.ForeColor = System.Drawing.Color.White;
            this.btn_left.Location = new System.Drawing.Point(3, 3);
            this.btn_left.Name = "btn_left";
            this.btn_left.Size = new System.Drawing.Size(75, 104);
            this.btn_left.TabIndex = 2;
            this.btn_left.Text = "←";
            this.btn_left.UseVisualStyleBackColor = false;
            this.btn_left.Click += new System.EventHandler(this.btn_left_Click);
            // 
            // panel6
            // 
            this.panel6.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel6.Controls.Add(this.btn_CW);
            this.panel6.Controls.Add(this.btn_ACW);
            this.panel6.Location = new System.Drawing.Point(232, -3);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(216, 175);
            this.panel6.TabIndex = 8;
            // 
            // btn_CW
            // 
            this.btn_CW.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btn_CW.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btn_CW.Font = new System.Drawing.Font("幼圆", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btn_CW.ForeColor = System.Drawing.Color.White;
            this.btn_CW.Location = new System.Drawing.Point(107, 3);
            this.btn_CW.Name = "btn_CW";
            this.btn_CW.Size = new System.Drawing.Size(102, 162);
            this.btn_CW.TabIndex = 16;
            this.btn_CW.Text = "C.W";
            this.btn_CW.UseVisualStyleBackColor = false;
            this.btn_CW.Click += new System.EventHandler(this.btn_CW_Click);
            // 
            // btn_ACW
            // 
            this.btn_ACW.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btn_ACW.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btn_ACW.Font = new System.Drawing.Font("幼圆", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btn_ACW.ForeColor = System.Drawing.Color.White;
            this.btn_ACW.Location = new System.Drawing.Point(3, 3);
            this.btn_ACW.Name = "btn_ACW";
            this.btn_ACW.Size = new System.Drawing.Size(98, 162);
            this.btn_ACW.TabIndex = 15;
            this.btn_ACW.Text = "A.C.W";
            this.btn_ACW.UseVisualStyleBackColor = false;
            this.btn_ACW.Click += new System.EventHandler(this.btn_ACW_Click);
            // 
            // panel5
            // 
            this.panel5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel5.Controls.Add(this.chart1);
            this.panel5.Location = new System.Drawing.Point(9, 490);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(1179, 268);
            this.panel5.TabIndex = 12;
            // 
            // chart1
            // 
            this.chart1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.chart1.BorderlineColor = System.Drawing.SystemColors.ActiveCaption;
            this.chart1.BorderSkin.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.chart1.BorderSkin.PageColor = System.Drawing.Color.WhiteSmoke;
            chartArea1.AxisX.MajorGrid.Enabled = false;
            chartArea1.AxisX.MajorGrid.LineColor = System.Drawing.SystemColors.ActiveCaption;
            chartArea1.AxisX.MajorTickMark.Enabled = false;
            chartArea1.AxisX.ScaleView.Position = 0D;
            chartArea1.AxisX.ScrollBar.ButtonStyle = System.Windows.Forms.DataVisualization.Charting.ScrollBarButtonStyles.SmallScroll;
            chartArea1.AxisY2.IsStartedFromZero = false;
            chartArea1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            chartArea1.BorderColor = System.Drawing.Color.White;
            chartArea1.BorderDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.Solid;
            chartArea1.IsSameFontSizeForAllAxes = true;
            chartArea1.Name = "ChartArea1";
            this.chart1.ChartAreas.Add(chartArea1);
            this.chart1.Cursor = System.Windows.Forms.Cursors.AppStarting;
            legend1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            legend1.Font = new System.Drawing.Font("幼圆", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            legend1.ForeColor = System.Drawing.Color.White;
            legend1.IsTextAutoFit = false;
            legend1.Name = "Legend1";
            legend1.TitleBackColor = System.Drawing.SystemColors.ActiveCaption;
            this.chart1.Legends.Add(legend1);
            this.chart1.Location = new System.Drawing.Point(23, 18);
            this.chart1.Name = "chart1";
            series1.ChartArea = "ChartArea1";
            series1.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series1.Font = new System.Drawing.Font("幼圆", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            series1.LabelBackColor = System.Drawing.SystemColors.ActiveCaption;
            series1.LabelBorderColor = System.Drawing.SystemColors.ActiveCaption;
            series1.LabelForeColor = System.Drawing.Color.White;
            series1.Legend = "Legend1";
            series1.Name = "L_U";
            series2.ChartArea = "ChartArea1";
            series2.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series2.Font = new System.Drawing.Font("幼圆", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            series2.LabelBackColor = System.Drawing.SystemColors.ActiveCaption;
            series2.LabelBorderColor = System.Drawing.SystemColors.ActiveCaption;
            series2.LabelForeColor = System.Drawing.Color.White;
            series2.Legend = "Legend1";
            series2.Name = "R_U";
            series3.ChartArea = "ChartArea1";
            series3.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series3.Font = new System.Drawing.Font("幼圆", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            series3.LabelBackColor = System.Drawing.SystemColors.ActiveCaption;
            series3.LabelBorderColor = System.Drawing.SystemColors.ActiveCaption;
            series3.LabelForeColor = System.Drawing.Color.White;
            series3.Legend = "Legend1";
            series3.Name = "L_D";
            series4.ChartArea = "ChartArea1";
            series4.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series4.Font = new System.Drawing.Font("幼圆", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            series4.LabelBackColor = System.Drawing.SystemColors.ActiveCaption;
            series4.LabelBorderColor = System.Drawing.SystemColors.ActiveCaption;
            series4.LabelForeColor = System.Drawing.Color.White;
            series4.Legend = "Legend1";
            series4.Name = "R_D";
            this.chart1.Series.Add(series1);
            this.chart1.Series.Add(series2);
            this.chart1.Series.Add(series3);
            this.chart1.Series.Add(series4);
            this.chart1.Size = new System.Drawing.Size(866, 231);
            this.chart1.TabIndex = 1;
            this.chart1.Text = "chart2";
            // 
            // panel8
            // 
            this.panel8.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel8.Controls.Add(this.btn_h_down);
            this.panel8.Controls.Add(this.btn_h_up);
            this.panel8.Location = new System.Drawing.Point(764, 13);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(253, 171);
            this.panel8.TabIndex = 17;
            // 
            // btn_h_down
            // 
            this.btn_h_down.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btn_h_down.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btn_h_down.Font = new System.Drawing.Font("幼圆", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btn_h_down.ForeColor = System.Drawing.Color.White;
            this.btn_h_down.Location = new System.Drawing.Point(3, 85);
            this.btn_h_down.Name = "btn_h_down";
            this.btn_h_down.Size = new System.Drawing.Size(243, 79);
            this.btn_h_down.TabIndex = 16;
            this.btn_h_down.Text = "DOWN";
            this.btn_h_down.UseVisualStyleBackColor = false;
            this.btn_h_down.Click += new System.EventHandler(this.btn_h_down_Click);
            // 
            // btn_h_up
            // 
            this.btn_h_up.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btn_h_up.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btn_h_up.Font = new System.Drawing.Font("幼圆", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btn_h_up.ForeColor = System.Drawing.Color.White;
            this.btn_h_up.Location = new System.Drawing.Point(3, 3);
            this.btn_h_up.Name = "btn_h_up";
            this.btn_h_up.Size = new System.Drawing.Size(243, 79);
            this.btn_h_up.TabIndex = 15;
            this.btn_h_up.Text = "UP";
            this.btn_h_up.UseVisualStyleBackColor = false;
            this.btn_h_up.Click += new System.EventHandler(this.btn_h_up_Click);
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button5.Font = new System.Drawing.Font("幼圆", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button5.ForeColor = System.Drawing.SystemColors.Window;
            this.button5.Location = new System.Drawing.Point(758, 242);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(85, 30);
            this.button5.TabIndex = 15;
            this.button5.Text = "停止刷新";
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // panel9
            // 
            this.panel9.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel9.Location = new System.Drawing.Point(708, -2);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(170, 171);
            this.panel9.TabIndex = 18;
            // 
            // txb_defyaw
            // 
            this.txb_defyaw.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.txb_defyaw.Font = new System.Drawing.Font("幼圆", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txb_defyaw.ForeColor = System.Drawing.SystemColors.Window;
            this.txb_defyaw.Location = new System.Drawing.Point(440, 254);
            this.txb_defyaw.Name = "txb_defyaw";
            this.txb_defyaw.Size = new System.Drawing.Size(100, 24);
            this.txb_defyaw.TabIndex = 57;
            // 
            // txb_defpitch
            // 
            this.txb_defpitch.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.txb_defpitch.Font = new System.Drawing.Font("幼圆", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txb_defpitch.ForeColor = System.Drawing.SystemColors.Window;
            this.txb_defpitch.Location = new System.Drawing.Point(440, 213);
            this.txb_defpitch.Name = "txb_defpitch";
            this.txb_defpitch.Size = new System.Drawing.Size(100, 24);
            this.txb_defpitch.TabIndex = 55;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label4.Font = new System.Drawing.Font("幼圆", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label4.ForeColor = System.Drawing.SystemColors.Window;
            this.label4.Location = new System.Drawing.Point(371, 257);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(55, 15);
            this.label4.TabIndex = 56;
            this.label4.Text = "defYaw";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label23.Font = new System.Drawing.Font("幼圆", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label23.ForeColor = System.Drawing.SystemColors.Window;
            this.label23.Location = new System.Drawing.Point(371, 137);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(79, 15);
            this.label23.TabIndex = 50;
            this.label23.Text = "defHeight";
            // 
            // txb_defheight
            // 
            this.txb_defheight.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.txb_defheight.Font = new System.Drawing.Font("幼圆", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txb_defheight.ForeColor = System.Drawing.SystemColors.Window;
            this.txb_defheight.Location = new System.Drawing.Point(440, 134);
            this.txb_defheight.Name = "txb_defheight";
            this.txb_defheight.Size = new System.Drawing.Size(100, 24);
            this.txb_defheight.TabIndex = 51;
            // 
            // txb_defroll
            // 
            this.txb_defroll.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.txb_defroll.Font = new System.Drawing.Font("幼圆", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txb_defroll.ForeColor = System.Drawing.SystemColors.Window;
            this.txb_defroll.Location = new System.Drawing.Point(440, 174);
            this.txb_defroll.Name = "txb_defroll";
            this.txb_defroll.Size = new System.Drawing.Size(100, 24);
            this.txb_defroll.TabIndex = 54;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label22.Font = new System.Drawing.Font("幼圆", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label22.ForeColor = System.Drawing.SystemColors.Window;
            this.label22.Location = new System.Drawing.Point(371, 177);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(63, 15);
            this.label22.TabIndex = 52;
            this.label22.Text = "defRoll";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label21.Font = new System.Drawing.Font("幼圆", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label21.ForeColor = System.Drawing.SystemColors.Window;
            this.label21.Location = new System.Drawing.Point(371, 216);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(71, 15);
            this.label21.TabIndex = 53;
            this.label21.Text = "defPitch";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(1193, 763);
            this.Controls.Add(this.panel8);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = "UV_Control_v3";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel7.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).EndInit();
            this.panel8.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox comboBox3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button btn_setting;
        private System.Windows.Forms.TextBox Receive_TextBox;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label lab_xout;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txb_xout;
        private System.Windows.Forms.TextBox txb_yout;
        private System.Windows.Forms.TextBox txb_zout;
        private System.Windows.Forms.TextBox txb_roll;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button btn_start_stop;
        private System.Windows.Forms.Button btn_left;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart1;
        private System.Windows.Forms.ComboBox cbb_pid3;
        private System.Windows.Forms.ComboBox cbb_pid2;
        private System.Windows.Forms.ComboBox cbb_pid1;
        private System.Windows.Forms.TextBox txb_thr;
        private System.Windows.Forms.TextBox txb_speedz;
        private System.Windows.Forms.TextBox txb_yaw;
        private System.Windows.Forms.TextBox txb_pitch;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox txb_height;
        private System.Windows.Forms.TextBox txb_gz;
        private System.Windows.Forms.TextBox txb_gy;
        private System.Windows.Forms.TextBox txb_gx;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox Transmit_TextBox;
        private System.Windows.Forms.TextBox txb_fly_enabled;
        private System.Windows.Forms.TextBox txb_dout;
        private System.Windows.Forms.Label fly_enabled;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Button enter_setting;
        private System.Windows.Forms.Button btn_para_set_ok;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Button btn_CW;
        private System.Windows.Forms.Button btn_ACW;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Button btn_h_down;
        private System.Windows.Forms.Button btn_h_up;
        private System.Windows.Forms.Button btn_ahead;
        private System.Windows.Forms.Button btn_right;
        private System.Windows.Forms.Button btn_back;
        private System.Windows.Forms.TextBox tbx_accz;
        private System.Windows.Forms.TextBox txb_iout;
        private System.Windows.Forms.TextBox txb_pout;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.TextBox txb_defyaw;
        private System.Windows.Forms.TextBox txb_defpitch;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TextBox txb_defheight;
        private System.Windows.Forms.TextBox txb_defroll;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Panel panel9;
    }
}

