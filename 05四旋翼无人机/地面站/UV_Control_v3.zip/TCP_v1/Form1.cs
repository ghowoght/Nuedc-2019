﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;
using System.Windows.Forms.DataVisualization.Charting;

//v3 
//使用多核编程，提升数据处理速度
//2019.5.31

namespace TCP_v1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            TextBox.CheckForIllegalCrossThreadCalls = false;
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        Thread threadWatch = null; //负责监听客户端的线程
        Socket socketWatch = null;  //负责监听客户端的套接字     


        private void Form1_Load(object sender, EventArgs e)
        {
            chart1.ChartAreas[0].AxisX.IntervalAutoMode = IntervalAutoMode.VariableCount;

            DateTime time = DateTime.Now;
            chart1.ChartAreas[0].AxisX.LabelStyle.Format = "HH:mm:ss";
            chart1.ChartAreas[0].AxisX.ScaleView.Size = 10;
            chart1.ChartAreas[0].AxisX.ScrollBar.IsPositionedInside = true;
            chart1.ChartAreas[0].AxisX.ScrollBar.Enabled = true;
            chart1.ChartAreas[0].AxisX.MajorGrid.Interval = 0.5;
            chart1.ChartAreas[0].AxisX.LabelAutoFitStyle = LabelAutoFitStyles.None;
            //2.设置适应全部数据点
            chart1.ChartAreas[0].AxisX.IntervalAutoMode = IntervalAutoMode.VariableCount;
            //3.设置当前X轴Label的双行显示格式 = 关闭
            chart1.ChartAreas[0].AxisX.LabelStyle.IsStaggered = false;
            //4.设置X轴不从0开始
            chart1.ChartAreas[0].AxisX.IsStartedFromZero = false;
            chart1.ChartAreas[0].AxisX.ScrollBar.IsPositionedInside = false;//设置滚动条是在外部显示

            chart1.ChartAreas[0].AxisY.Maximum = 60;



            chart1.Series[0].MarkerColor = Color.Red;
            chart1.Series[0].LabelForeColor = Color.Red;
            chart1.Series[0].XValueType = ChartValueType.Auto;

        }

        int i = 0;
        private void ChartShow(float a, float b, float c, float d)
        {
            if (chart1.InvokeRequired)
            {
                InvokeCallback x = new InvokeCallback(ChartShow);
                this.Invoke(x, new object[] { a, b, c, d });

            }
            else
            {
                chart1.Series[0].Points.AddXY(DateTime.Now.ToString("HH:mm:ss"), a);
                chart1.Series[1].Points.AddXY(DateTime.Now.ToString("HH:mm:ss"), b);
                chart1.Series[2].Points.AddXY(DateTime.Now.ToString("HH:mm:ss"), c);
                chart1.Series[3].Points.AddXY(DateTime.Now.ToString("HH:mm:ss"), d);
                i++;
                if (i > 9)
                    chart1.ChartAreas[0].AxisX.ScaleView.Position = i - 9;

            }

        }
        private delegate void InvokeCallback(float a, float b, float c, float d);


        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                //定义一个套接字用于监听客户端发来的信息  包含3个参数(IP4寻址协议,流式连接,TCP协议)
                socketWatch = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                //服务端发送信息 需要1个IP地址和端口号
                IPAddress ipaddress = IPAddress.Parse(this.comboBox1.Text.Trim()); //获取文本框输入的IP地址
                //将IP地址和端口号绑定到网络节点endpoint上 
                IPEndPoint endpoint = new IPEndPoint(ipaddress, int.Parse(this.comboBox2.Text.Trim())); //获取文本框上输入的端口号
                //监听绑定的网络节点
                socketWatch.Bind(endpoint);
                //将套接字的监听队列长度限制为20
                socketWatch.Listen(20);
                //创建一个监听线程 
                threadWatch = new Thread(WatchConnecting);
                //将窗体线程设置为与后台同步
                threadWatch.IsBackground = true;
                //启动线程
                threadWatch.Start();
                //启动线程后 txtMsg文本框显示相应提示
                Receive_TextBox.AppendText("开始监听客户端传来的信息!" + "\r\n");
                //this.button1.Enabled = false;
            }
            catch (Exception ex)
            {
                Receive_TextBox.AppendText("服务端启动服务失败!" + "\r\n");
                this.button1.Enabled = true;
            }
        }

        //创建一个负责和客户端通信的套接字 
        Socket socConnection = null;

        /// <summary>
        /// 监听客户端发来的请求
        /// </summary>
        private void WatchConnecting()
        {
            while (true)  //持续不断监听客户端发来的请求
            {
                socConnection = socketWatch.Accept();

                Receive_TextBox.AppendText("客户端连接成功! " + "\r\n");
                //创建一个通信线程 
                ParameterizedThreadStart pts = new ParameterizedThreadStart(ServerRecMsg);
                Thread thr = new Thread(pts);
                thr.IsBackground = true;
                //启动线程
                thr.Start(socConnection);
            }
        }

        /// <summary>
        /// 发送信息到客户端的方法
        /// </summary>
        /// <param name="sendMsg">发送的字符串信息</param>
        private void ServerSendMsg(string sendMsg)
        {
            try
            {
                //将输入的字符串转换成 机器可以识别的字节数组
                byte[] arrSendMsg = Encoding.UTF8.GetBytes(sendMsg);
                //向客户端发送字节数组信息
                socConnection.Send(arrSendMsg);
                //将发送的字符串信息附加到文本框txtMsg上
                //Receive_TextBox.AppendText(sendMsg + "\r\n");
            }
            catch (Exception ex)
            {
                MessageBox.Show("" + ex);
                Receive_TextBox.AppendText("客户端已断开连接,无法发送信息！" + "\r\n");
            }
        }

        bool refreshFlag = true;

        /// <summary>
        /// 接收客户端发来的信息 
        /// </summary>
        /// <param name="socketClientPara">客户端套接字对象</param>
        private void ServerRecMsg(object socketClientPara)
        {
            Socket socketServer = socketClientPara as Socket;
            while (true)
            {
                //创建一个内存缓冲区 其大小为1024*1024字节  即1M
                byte[] arrServerRecMsg = new byte[1024 * 1024];
                try
                {
                    //将接收到的信息存入到内存缓冲区,并返回其字节数组的长度
                    int length = socketServer.Receive(arrServerRecMsg);
                    //将机器接受到的字节数组转换为人可以读懂的字符串
                    string strSRecMsg = Encoding.ASCII.GetString(arrServerRecMsg, 0, length);
                    //将发送的字符串信息附加到文本框txtMsg上  

                    //string strSRecMsg = Encoding.ASCII.GetString(arrServerRecMsg,0,length);//Encoding.UTF8.GetString(arrServerRecMsg, 0, length);
                    //Encoding.ASCII.
                    cmdCope(strSRecMsg,length);


                    if (data1.Count != 0)
                    {
                        ChartShow(data1.Dequeue(), data2.Dequeue(), data3.Dequeue(), data4.Dequeue());
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("" + ex);
                    Receive_TextBox.AppendText("客户端已断开连接！" + "\r\n");
                    break;
                }
            }
        }
        float[,] data = new float[10,10];
        private void cmdCope(string cmd,int length)
        {
            
            if (cmd.Equals(""))// || cmd[length - 2] != '\r' || cmd[length - 1] != '\n')
            {
                return;
            }
            Receive_TextBox.AppendText(cmd);
            if (cmd[0] == 0xAA && cmd[1] == 0xAA)
            {
                if (cmd[2] == 0x01)        //角速度
                {
                    data[0, 0] = (cmd[3] << 8 + cmd[4]) / 100.0f;
                    data[0, 1] = (cmd[5] << 8 + cmd[6]) / 100.0f;
                    data[0, 2] = (cmd[7] << 8 + cmd[8]) / 100.0f;
                }
                else if (cmd[2] == 0x02)   //姿态
                {
                    data[1, 0] = (cmd[3] << 8 + cmd[4]) / 100.0f;
                    data[1, 1] = (cmd[5] << 8 + cmd[6]) / 100.0f;
                    data[1, 2] = (cmd[7] << 8 + cmd[8]) / 100.0f;
                    data[1, 3] = cmd[9];
                }
                else if (cmd[2] == 0x04)   //位置
                {
                    data[2, 0] = (cmd[3] << 8 + cmd[4]) / 100.0f;
                    data[2, 1] = (cmd[5] << 8 + cmd[6]) / 100.0f;
                    data[2, 2] = (cmd[7] << 8 + cmd[8]);
                }
                else if (cmd[2] == 0x08)   //姿态PID输出
                {
                    data[3, 0] = (cmd[3] << 8 + cmd[4]) / 100.0f;
                    data[3, 1] = (cmd[5] << 8 + cmd[6]) / 100.0f;
                    data[3, 2] = (cmd[7] << 8 + cmd[8]) / 100.0f;
                }
                else if (cmd[2] == 0x10)   //位置PID输出
                {
                    data[4, 0] = (cmd[3] << 8 + cmd[4]) / 100.0f;
                    data[4, 1] = (cmd[5] << 8 + cmd[6]) / 100.0f;
                    data[4, 2] = (cmd[7] << 8 + cmd[8]) / 100.0f;
                }
                else if (cmd[2] == 0x20)   //预设值
                {
                    data[5, 0] = (cmd[3] << 8 + cmd[4]) / 100.0f;
                    data[5, 1] = (cmd[5] << 8 + cmd[6]) / 100.0f;
                    data[5, 2] = (cmd[7] << 8 + cmd[8]) / 100.0f;
                    data[5, 3] = (cmd[9] << 8 + cmd[10]) / 100.0f;
                }
                else if (cmd[2] == 0x40)   //预设值
                {
                    data[6, 0] = (cmd[3] << 8 + cmd[4]) / 100.0f;
                    data[6, 1] = (cmd[5] << 8 + cmd[6]) / 100.0f;
                    data[6, 2] = (cmd[7] << 8 + cmd[8]) / 100.0f;
                    data[6, 3] = (cmd[9] << 8 + cmd[10]) / 100.0f;
                }
            }
            else
            {
                Receive_TextBox.AppendText(cmd.ToString());
            }
            return;
        }
        Queue<float> data1 = new Queue<float>(50);
        Queue<float> data2 = new Queue<float>(50);
        Queue<float> data3 = new Queue<float>(50);
        Queue<float> data4 = new Queue<float>(50);

        private void Status_Refresh()
        {
            txb_roll.Text = data[0, 0].ToString();
            txb_pitch.Text = data[0, 1].ToString();
            txb_yaw.Text = data[0, 2].ToString();
        }
        private void Position_Refresh()
        {
            txb_height.Text = data[1, 0].ToString();
            txb_speedz.Text = data[1, 1].ToString();
            txb_thr.Text = data[1, 2].ToString();
        }
        private void Gyro_Refresh()
        {
            txb_gx.Text = data[2, 0].ToString();
            txb_gy.Text = data[2, 1].ToString();
            txb_gz.Text = data[2, 2].ToString();
        }
        private void Posture_PID_Refresh()
        {
            txb_xout.Text = data[3, 0].ToString();
            txb_yout.Text = data[3, 1].ToString();
            txb_zout.Text = data[3, 2].ToString();
        }
        private void Position_PID_Refresh()
        {
            txb_pout.Text = data[4, 0].ToString();
            txb_iout.Text = data[4, 1].ToString();
            txb_dout.Text = data[4, 2].ToString();
        }
        private void Def_Refresh()
        {
            txb_defroll.Text = data[5, 0].ToString();
            txb_defpitch.Text = data[5, 1].ToString();
            txb_defyaw.Text = data[5, 2].ToString();
            txb_defheight.Text = data[5, 3].ToString();
        }




        /// <summary>
        /// 快捷键 Enter 发送信息
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void txtSendMsg_KeyDown(object sender, KeyEventArgs e)
        {

        }

        /// <summary>
        /// 获取本地IPv4地址
        /// </summary>
        /// <returns></returns>
        public IPAddress GetLocalIPv4Address()
        {
            IPAddress localIpv4 = null;
            //获取本机所有的IP地址列表
            IPAddress[] IpList = Dns.GetHostAddresses(Dns.GetHostName());
            //循环遍历所有IP地址
            foreach (IPAddress IP in IpList)
            {
                //判断是否是IPv4地址
                if (IP.AddressFamily == AddressFamily.InterNetwork)
                {
                    localIpv4 = IP;
                }
                else
                {
                    continue;
                }
            }
            return localIpv4;
        }

        /// <summary>
        /// 获取本地IP事件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnGetLocalIP_Click(object sender, EventArgs e)
        {
            //接收IPv4的地址
            IPAddress localIP = GetLocalIPv4Address();
            //赋值给文本框
            this.comboBox1.Text = localIP.ToString();

        }

        private void Receive_TextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Receive_TextBox.Text = "";
        }

        private void button14_Click(object sender, EventArgs e)
        {
            ServerSendMsg("Xs/");
        }

        private void button5_Click(object sender, EventArgs e)   //刷新按键
        {
            refreshFlag = !refreshFlag;
            if (refreshFlag)
            {
                button5.Text = "停止刷新";
                
            }
            else
            {
                button5.Text = "开始刷新";
            }
        }

        private void comboBox4_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btn_setting_Click(object sender, EventArgs e)
        {
            StringBuilder str = new StringBuilder();
            str.Append("P");
            switch (cbb_pid1.Text)
            {
                case "angle": str.Append("a"); break;
                case "gyro": str.Append("g"); break;
                case "height": str.Append("h"); break;
                case "speed": str.Append("s"); break;
                case "fly_min": str.Append("f"); break;
                case "attitude": str.Append("A"); break;
                default: MessageBox.Show("Error!"); return;
            }
            switch (cbb_pid2.Text)
            {
                case "x": str.Append("0"); break;
                case "y": str.Append("1"); break;
                case "z": str.Append("2"); break;
                case "-": case "请选择": str.Append("-"); break;
                default: MessageBox.Show("Error!"); return;
            }
            switch (cbb_pid3.Text)
            {
                case "P": str.Append("p"); break;
                case "I": str.Append("i"); break;
                case "D": str.Append("d"); break;
                case "out_max": str.Append("M"); break;
                case "IMAX": str.Append("m"); break;
                case "请选择": str.Append("-"); break;
                default: MessageBox.Show("Error!"); return;
            }
            string[] split = this.Transmit_TextBox.Text.Trim().Split(new char[] { '.' });
            
            if (split.Length == 2)
            {
                int int_len = split[0].Count<char>();
                int float_len = split[1].Count<char>();
                str.Append((int_len + float_len).ToString() + int_len.ToString() + split[0] + split[1] + "/");
                //str.Append(split[0] + split[1] + "/");
                ServerSendMsg(str.ToString());
            }
            else
            {
                MessageBox.Show("Error!");
            }

        }

        private void enter_setting_Click(object sender, EventArgs e)
        {
            ServerSendMsg("P/");
        }

        private void btn_para_set_ok_Click(object sender, EventArgs e)
        {
            ServerSendMsg("OK/");
        }

        private void btn_left_Click(object sender, EventArgs e)
        {
            ServerSendMsg("C0+/");
        }

        private void btn_ahead_Click(object sender, EventArgs e)
        {
            ServerSendMsg("C1-/");
        }

        private void btn_right_Click(object sender, EventArgs e)
        {
            ServerSendMsg("C0-/");
        }

        private void btn_back_Click(object sender, EventArgs e)
        {
            ServerSendMsg("C1+/");
        }

        private void btn_start_stop_Click(object sender, EventArgs e)
        {
            ServerSendMsg("S/");
        }

        private void btn_ACW_Click(object sender, EventArgs e)
        {
            ServerSendMsg("C2+/");
        }

        private void btn_CW_Click(object sender, EventArgs e)
        {
            ServerSendMsg("C2-/");
        }

        private void btn_h_up_Click(object sender, EventArgs e)
        {
            ServerSendMsg("C3+/");
        }

        private void btn_h_down_Click(object sender, EventArgs e)
        {
            ServerSendMsg("C3-/");
        }

        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if (keyData == Keys.Up)
            {
                ServerSendMsg("C1-/");
            }
            if (keyData == Keys.Down)
            {
                ServerSendMsg("C1+/");
            }
            if (keyData == Keys.Left)
            {
                ServerSendMsg("C0+/");
            }
            if (keyData == Keys.Right)
            {
                ServerSendMsg("C0-/");
            }
            if (keyData == Keys.W)
            {
                ServerSendMsg("C3+/");
            }
            if (keyData == Keys.S)
            {
                ServerSendMsg("C3-/");
            }
            if (keyData == Keys.A)
            {
                ServerSendMsg("C2+/");
            }
            if (keyData == Keys.D)
            {
                ServerSendMsg("C2-/");
            }
            if (keyData == Keys.Enter)
            {
                ServerSendMsg("S/");
            }

            return base.ProcessCmdKey(ref msg, keyData);
        }
    }
    
}
