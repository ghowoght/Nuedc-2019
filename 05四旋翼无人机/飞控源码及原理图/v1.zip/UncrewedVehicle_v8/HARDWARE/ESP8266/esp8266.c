#include "esp8266.h"

void ESP8266_Init(void)
{
//	printf("+++");
//	delay_ms(500);
//	printf("AT+CWMODE=3\r\n");
//	delay_ms(500);
//	printf("AT+RST\r\n");
//	delay_ms(6000);

//	printf("AT+CWJAP=\"WLF-STF-AL00\",\"12345678\"\r\n");
//	delay_ms(6000);
//	printf("AT+CIPSTART=\"TCP\",\"10.103.144.39\",8090\r\n");
//	delay_ms(1000);
	
//	printf("AT+CWJAP=\"GHOWOGHT\",\"12345678\"\r\n");
//	delay_ms(6000);
	
//	printf("AT+CIPSTART=\"TCP\",\"192.168.43.108\",8090\r\n");
//	delay_ms(2000);

//	printf("AT+SAVETRANSLINK=1,\"192.168.43.108\",8090\r\n");
//	delay_ms(5000);

//	printf("AT+CIPMODE=1\r\n");
//	delay_ms(500);
//	printf("AT+CIPSEND\r\n");
//	delay_ms(500);

	printf("OK\r\n");
}
