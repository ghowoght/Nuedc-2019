/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  ** This notice applies to any and all portions of this file
  * that are not between comment pairs USER CODE BEGIN and
  * USER CODE END. Other portions of this file, whether 
  * inserted by the user or by software development tools
  * are owned by their respective copyright owners.
  *
  * COPYRIGHT(c) 2019 STMicroelectronics
  *
  * Redistribution and use in source and binary forms, with or without modification,
  * are permitted provided that the following conditions are met:
  *   1. Redistributions of source code must retain the above copyright notice,
  *      this list of conditions and the following disclaimer.
  *   2. Redistributions in binary form must reproduce the above copyright notice,
  *      this list of conditions and the following disclaimer in the documentation
  *      and/or other materials provided with the distribution.
  *   3. Neither the name of STMicroelectronics nor the names of its contributors
  *      may be used to endorse or promote products derived from this software
  *      without specific prior written permission.
  *
  * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
  * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
  * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
  * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
  * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
  * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
  * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
  *
  ******************************************************************************
  */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H__
#define __MAIN_H__

/* Includes ------------------------------------------------------------------*/

/* USER CODE BEGIN Includes */

#include "sys.h"
#include "mpu6050.h"

#include "control.h"
#include "IOI2C.h"
#include "scheduler.h"
#include "esp8266.h"
#include "SINS.h"

/* USER CODE END Includes */

/* Private define ------------------------------------------------------------*/

/* ########################## Assert Selection ############################## */
/**
  * @brief Uncomment the line below to expanse the "assert_param" macro in the 
  *        HAL drivers code
  */
/* #define USE_FULL_ASSERT    1U */

/* USER CODE BEGIN Private defines */
extern float q0,q1,q2,q3;														//��Ԫ��
extern float Pitch,Roll,Yaw;												//��̬��						����ֵ
extern float Height;																//�߶�							����ֵ
extern float Gyro_x,Gyro_y,Gyro_z;									//������ٶ�				����ֵ
extern float Accel_x,Accel_y,Accel_z;								//����Ǽ��ٶ�			����ֵ
extern float Gra_Accel;															//�������ٶ�
extern float Speed_z;																//Z���ٶ�						����ֵ
extern float defPitch,defRoll,defYaw;   						//��̬��						Ԥ��ֵ
extern float defHeight;															//�߶�							Ԥ��ֵ
extern float defGyro_x,defGyro_y,defGyro_z;					//������ٶ�				Ԥ��ֵ
extern float defSpeed_z;														//Z���ٶ�						Ԥ��ֵ
extern int	 throttle;															//����ֵ
extern int	 fly_enabled;														//�Ƿ���������
extern float ref_x,ref_y,ref_z;											//������Ч����

extern int 	 L_U,R_U,L_D,R_D;
extern float x_out,y_out,z_out;

extern float tim_offset;														//ʱ��У��ϵ��

extern char  cmd[20];																//�����
extern int 	 cmdFlag;																//�������־λ
extern u8 	 cmd_data[4];														//���ڽ�������
extern int 	 para_setFlag;													//�������ñ�־λ
extern int	 is_takeoff_flag;												//�Ƿ���ɣ� ���߶ȴ���40cmʱ���ñ�־��1
extern int 	 fixed_flag;														//����ģʽ
extern int 	 ultra_flag;														//�������ɼ���ɱ�־
typedef struct
{
	float P;
	float pout;
	
	float I;
	float IMAX;
	float iout;
	
	float D;
	float dout;
	
	float OUT;
	
	int error;
	int Last_error;	
}PID;

/* USER CODE END Private defines */

#ifdef __cplusplus
 extern "C" {
#endif
void _Error_Handler(char *, int);

#define Error_Handler() _Error_Handler(__FILE__, __LINE__)
#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H__ */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
