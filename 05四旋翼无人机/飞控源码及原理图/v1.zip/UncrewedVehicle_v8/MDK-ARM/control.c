#include "control.h"
#include "mpu6050.h"
#include "math.h"

#define ROLL		0
#define PITCH		1
#define YAW			2
#define GYRO_X	0
#define GYRO_Y	1
#define GYRO_Z	2

#define TOANGLE 0.06103f    //�����ٶ�ת��Ϊ�Ƕ�ֵ��4000/65536

#define T				0.01f
#define PI			3.14f

#define FILTER_NUM 		10					//�����˲������С

float Pitch,Roll,Yaw;												//��̬��						����ֵ
float Height;																//�߶�							����ֵ
float Gyro_x,Gyro_y,Gyro_z;									//������ٶ�				����ֵ
float Accel_x,Accel_y,Accel_z;							//����Ǽ��ٶ�			����ֵ
float Gra_Accel;														//�������ٶ�
float Speed_z=0;														//Z���ٶ�						����ֵ		
float defPitch,defRoll,defYaw;							//��̬��						Ԥ��ֵ
float defHeight;														//�߶�							Ԥ��ֵ
float defGyro_x,defGyro_y,defGyro_z;				//������ٶ�				Ԥ��ֵ
float defSpeed_z;														//Z���ٶ�						Ԥ��ֵ
float ref_x,ref_y,ref_z;										//������Ч����
int	  throttle=0.0;													//����ֵ						��0~300��
int		enable_fly_min=5200;									//ʹ���ת������С�趨ֵ
int   landing_pwm=60;											  //���䲹��

float angle_out_max[]	={80.0,80.0,80.0};					//�ǶȻ������ֵ
float gyro_out_max[]	={30.0,30.0,20.0};					//���ٶȻ������ֵ
float height_out_max  =50.0;											//�����⻷�������ֵ
float speed_z_out_max =100.0;											//�����ڻ��������ֵ

float tim_offset=5.0/3.714;

typedef struct
{
	int l_u;
	int r_u;
	int l_d;
	int r_d;
}PWM;

PWM pwm;

PID gyro_pid[3];				//�ڻ�PID 
PID angle_pid[3];				//�⻷PID
PID height_pid;					//�����⻷PID
PID speed_pid;					//�����ڻ�PID
/**********************�⻷PID**********************
Ԥ��ֵ	��Ԥ����̬��defPitch,defRoll,defYaw
					���û��趨��
��  ��	��������̬��Pitch,Roll,Yaw
��  ��	��������ٶ�Ԥ��ֵ
***************************************************/
/**********************�ڻ�PID**********************
Ԥ��ֵ	��Ԥ����ٶ�defGyro_x,defGyro_y,defGyro_z
					���⻷���ֵ��
��  ��	������������ٶ�Gyro_x,Gyro_y,Gyro_z
��  ��	����·PWM������ֵ
***************************************************/

void PID_Init(void)
{
	defPitch									=0.0;
	defRoll										=0.0;
	defYaw										=0.0;
	defHeight									=50.0;		//Ԥ��߶�
	
	/*�⻷PID����*/
	angle_pid[0].P						=2.0;
	angle_pid[0].I						=0.0;
	angle_pid[0].D						=0.0;
	angle_pid[0].IMAX					=0.0;
	angle_pid[0].iout					=0.0;
	angle_pid[0].OUT					=0.0;
	angle_pid[0].error				=0.0;
	angle_pid[0].Last_error		=0.0;
	
	angle_pid[1].P						=2.0;
	angle_pid[1].I						=0.0;
	angle_pid[1].D						=0.0;
	angle_pid[1].IMAX					=0.0;
	angle_pid[1].iout					=0.0;
	angle_pid[1].OUT					=0.0;
	angle_pid[1].error				=0.0;
	angle_pid[1].Last_error		=0.0;
	
	angle_pid[2].P						=6.0;
	angle_pid[2].I						=0.0;
	angle_pid[2].D						=4.0;
	angle_pid[2].IMAX					=0.0;
	angle_pid[2].iout					=0.0;
	angle_pid[2].OUT					=0.0;
	angle_pid[2].error				=0.0;
	angle_pid[2].Last_error		=0.0;
	
	/*�ڻ�PID����*/
	gyro_pid[0].P							=0.24;
	gyro_pid[0].I							=0.00;
	gyro_pid[0].D							=0.35;
	gyro_pid[0].IMAX					=2.0;
	gyro_pid[0].iout					=0.0;
	gyro_pid[0].OUT						=0.0;
	gyro_pid[0].error					=0.0;
	gyro_pid[0].Last_error		=0.0;
	
	gyro_pid[1].P							=0.24;
	gyro_pid[1].I							=0.00;
	gyro_pid[1].D							=0.35;
	gyro_pid[1].IMAX					=2.0;
	gyro_pid[1].iout					=0.0;
	gyro_pid[1].OUT						=0.0;
	gyro_pid[1].error					=0.0;
	gyro_pid[1].Last_error		=0.0;
	
	gyro_pid[2].P							=0.14;
	gyro_pid[2].I							=0.02;
	gyro_pid[2].D							=0.08;
	gyro_pid[2].IMAX					=5.0;
	gyro_pid[2].iout					=0.0;
	gyro_pid[2].OUT						=0.0;
	gyro_pid[2].error					=0.0;
	gyro_pid[2].Last_error		=0.0;
		
	/*����PID�⻷����*/
	height_pid.P							=0.2;//=0.2;
	height_pid.I							=0.0;//=0.00;
	height_pid.D							=0.6;//=0.6;
	height_pid.IMAX						=5.0;
	height_pid.iout						=0.0;
	height_pid.OUT						=0.0;
	height_pid.error					=0.0;
	height_pid.Last_error			=0.0;
	
	/*����PID�ڻ�����*/
	speed_pid.P								=0.4;
	speed_pid.I								=0.0;
	speed_pid.D								=0.15;
	speed_pid.IMAX						=10.0;
	speed_pid.iout						=0.0;
	speed_pid.OUT							=0.0;
	speed_pid.error						=0.0;
	speed_pid.Last_error			=0.0;
}

/*�����ʷ���*/
void PID_Clear_Out(void)  
{
	/*�⻷PID����*/
	int i=0;
	for(i=0;i<3;i++)
	{
		angle_pid[i].iout					=0.0;
		angle_pid[i].OUT					=0.0;
		angle_pid[i].error				=0.0;
		angle_pid[i].Last_error		=0.0;
	}
	/*�ڻ�PID����*/
	for(i=0;i<3;i++)
	{
		gyro_pid[i].iout					=0.0;
		gyro_pid[i].OUT						=0.0;
		gyro_pid[i].error					=0.0;
		gyro_pid[i].Last_error		=0.0;
	}
	/*����PID�⻷����*/
	height_pid.iout							=0.0;
	height_pid.OUT							=0.0;
	height_pid.error						=0.0;
	height_pid.Last_error				=0.0;

	/*����PID�ڻ�����*/
	speed_pid.iout							=0.0;
	speed_pid.OUT								=0.0;
	speed_pid.error							=0.0;
	speed_pid.Last_error				=0.0;

}	


/*ʹ���˻�����ƽ��*/
void Control(void)    //x Roll / y Pitch / z Yaw
{
	int i = 0;
	float angle[] = { Roll, Pitch, Yaw };
	float defAngle[] = { defRoll, defPitch, defYaw };
	
	/*�⻷PID*/
	for (i = 0; i < 3; i++)
	{
			angle_pid[i].error = angle[i] - defAngle[i];
			angle_pid[i].pout = angle_pid[i].P * angle_pid[i].error;
			angle_pid[i].iout += angle_pid[i].I * angle_pid[i].error;
			angle_pid[i].iout = GetMxMi(angle_pid[i].iout, angle_pid[i].IMAX, -angle_pid[i].IMAX);
			angle_pid[i].dout = angle_pid[i].D * (angle_pid[i].error - angle_pid[i].Last_error);
			angle_pid[i].Last_error = angle_pid[i].error;
			angle_pid[i].OUT = angle_pid[i].pout + angle_pid[i].iout + angle_pid[i].dout;
			angle_pid[i].OUT = GetMxMi(angle_pid[i].OUT, angle_out_max[i], -angle_out_max[i]);
	}
	
	float gyro[] = { Gyro_x, Gyro_y, Gyro_z };
	float defGyro[] = { angle_pid[ROLL].OUT, angle_pid[PITCH].OUT, -angle_pid[YAW].OUT };
	
//	float gyro[] = { Gyro_x, Gyro_y, Gyro_z };
//	float defGyro[] = { defGyro_x, defGyro_y, defGyro_z };

	/*�ڻ�PID*/
	for (i = 0; i < 3; i++)
	{
			gyro_pid[i].error = gyro[i] - defGyro[i];
			gyro_pid[i].pout = gyro_pid[i].P * gyro_pid[i].error;
			gyro_pid[i].iout += gyro_pid[i].I * gyro_pid[i].error;
			gyro_pid[i].iout = GetMxMi(gyro_pid[i].iout, gyro_pid[i].IMAX, -gyro_pid[i].IMAX);
			gyro_pid[i].dout = gyro_pid[i].D * (gyro_pid[i].error - gyro_pid[i].Last_error);
			gyro_pid[i].Last_error = gyro_pid[i].error;
			gyro_pid[i].OUT = gyro_pid[i].pout + gyro_pid[i].iout + gyro_pid[i].dout;
			gyro_pid[i].OUT = GetMxMi(gyro_pid[i].OUT, gyro_out_max[i],-gyro_out_max[i]);
	}
	
	pwm.l_u=throttle-gyro_pid[GYRO_X].OUT+gyro_pid[GYRO_Y].OUT-gyro_pid[GYRO_Z].OUT+enable_fly_min;
	pwm.r_u=throttle+gyro_pid[GYRO_X].OUT+gyro_pid[GYRO_Y].OUT+gyro_pid[GYRO_Z].OUT+enable_fly_min;
	pwm.l_d=throttle-gyro_pid[GYRO_X].OUT-gyro_pid[GYRO_Y].OUT+gyro_pid[GYRO_Z].OUT+enable_fly_min;
	pwm.r_d=throttle+gyro_pid[GYRO_X].OUT-gyro_pid[GYRO_Y].OUT-gyro_pid[GYRO_Z].OUT+enable_fly_min;
	
	L_U=throttle-gyro_pid[GYRO_X].OUT+gyro_pid[GYRO_Y].OUT-gyro_pid[GYRO_Z].OUT;
	R_U=throttle+gyro_pid[GYRO_X].OUT+gyro_pid[GYRO_Y].OUT+gyro_pid[GYRO_Z].OUT;
	L_D=throttle-gyro_pid[GYRO_X].OUT-gyro_pid[GYRO_Y].OUT+gyro_pid[GYRO_Z].OUT;
	R_D=throttle+gyro_pid[GYRO_X].OUT-gyro_pid[GYRO_Y].OUT-gyro_pid[GYRO_Z].OUT;
	
	
//	static int last_fly_flag=0;
	if(fly_enabled==1)   //�������У�
	{
		Set_PWM(pwm.l_u,pwm.r_u,pwm.l_d,pwm.r_d);
	}
	else if(fly_enabled==0)
	{
		defYaw=Yaw;
		Landing();
		PID_Clear_Out();
	}
	else
	{
		defYaw=Yaw;
		Close_Motor();
		PID_Clear_Out();
	}
}

float ABS(float x)
{
	return x>0?x:-x;
}

/*������������ֵ*/
void HeightControl(void)
{
	height_pid.error = defHeight - Height;
	height_pid.error = GetMxMi(height_pid.error,300,-300);
	height_pid.pout = height_pid.P * height_pid.error;
	if(ABS(height_pid.error)<=15)   //���ַ���
		height_pid.iout += height_pid.I * height_pid.error;
	height_pid.iout = GetMxMi(height_pid.iout, height_pid.IMAX, -height_pid.IMAX);
	height_pid.dout = height_pid.D * (height_pid.error - height_pid.Last_error);
	height_pid.Last_error = height_pid.error;
	height_pid.OUT = height_pid.pout + height_pid.iout + height_pid.dout;
	height_pid.OUT = GetMxMi(height_pid.OUT, height_out_max, -height_out_max);
	
	if(fixed_flag==1)
	{
		defSpeed_z=height_pid.OUT;
	}
	else
	{
		defSpeed_z=0;
	}
	
	speed_pid.error = defSpeed_z - Speed_z;
	speed_pid.pout = speed_pid.P * speed_pid.error;
	if(ABS(speed_pid.error)<=50)
		speed_pid.iout += speed_pid.I * speed_pid.error;
	speed_pid.iout = GetMxMi(speed_pid.iout, speed_pid.IMAX, -speed_pid.IMAX);
	speed_pid.dout = speed_pid.D * (speed_pid.error - speed_pid.Last_error);
	speed_pid.Last_error = speed_pid.error;
	speed_pid.OUT = speed_pid.pout + speed_pid.iout + speed_pid.dout;
	speed_pid.OUT = GetMxMi(speed_pid.OUT, speed_z_out_max, -speed_z_out_max);
	
	throttle=speed_pid.OUT;
}

//int gyro_x_offset=-97;
//int gyro_y_offset=-30;
//int gyro_z_offset=6;    //���ٶ�У��ֵ(green)
int gyro_x_offset=-8;
int gyro_y_offset=29;
int gyro_z_offset=-3;    //���ٶ�У��ֵ(red)
/*�����˲�*/
void Get_Gyro(void)
{
	static int cnt=0;
	u8 buffer[6];
	static int x[FILTER_NUM]={0},y[FILTER_NUM]={0},z[FILTER_NUM]={0};
	int sum_x=0;
	int sum_y=0;
	int sum_z=0;
	int i=0;
	
	/*У������*/
	IICreadBytes(devAddr,MPU6050_RA_GYRO_XOUT_H,6,buffer);
	
	x[cnt]=(int16_t)((buffer[0]<<8)+buffer[1])-gyro_x_offset;
	y[cnt]=(int16_t)((buffer[2]<<8)+buffer[3])-gyro_y_offset;
	z[cnt]=(int16_t)((buffer[4]<<8)+buffer[5])-gyro_z_offset;
	
	cnt=(cnt>=FILTER_NUM-1?0:cnt+1);
	for(i=0;i<FILTER_NUM;i++)
	{
		sum_x+=x[i];
		sum_y+=y[i];
		sum_z+=z[i];
	}
	Gyro_x=(float)sum_x/(float)FILTER_NUM;
	Gyro_y=(float)sum_y/(float)FILTER_NUM;
	Gyro_z=(float)sum_z/(float)FILTER_NUM;
	
	Gyro_x*=TOANGLE;        //ת��Ϊ�Ƕ�
	Gyro_y*=TOANGLE;
	Gyro_z*=TOANGLE;
	
//	u8 buffer[6];
//	IICreadBytes(devAddr,MPU6050_RA_GYRO_XOUT_H,6,buffer);
//	Gyro_x=(int16_t)((buffer[0]<<8)+buffer[1]);
//	Gyro_y=(int16_t)((buffer[2]<<8)+buffer[3]);
//	Gyro_z=(int16_t)((buffer[4]<<8)+buffer[5]);
}


//int acce_x_offset=0;
//int acce_y_offset=0;
//int acce_z_offset=0;    //���ٶ�У��ֵ(green)
int acce_x_offset=0;
int acce_y_offset=0;
int acce_z_offset=0;    //���ٶ�У��ֵ(red)
s16 x[FILTER_NUM]={0};
s16 y[FILTER_NUM]={0};
s16 z[FILTER_NUM]={0};
float accel_mpu=0;
float accel_mms2=0;
float accel_offset=0;
float ultra_speed=0;
void Get_Speed_Z(void)
{
	static int cnt=0;
	u8 buffer[6];
	int sum_x=0;
	int sum_y=0;
	int sum_z=0;
	int i=0;
	float ratio=0.80;
	float lpf_ratio=0.80;
	static float lastHeight=0;
	static float lastSpeed=0;
	/*�����˲�*/
	/*У������*/
	IICreadBytes(devAddr,MPU6050_RA_ACCEL_XOUT_H,6,buffer);
	x[cnt]=(int16_t)((buffer[0]<<8)+buffer[1])-acce_x_offset;
	y[cnt]=(int16_t)((buffer[2]<<8)+buffer[3])-acce_y_offset;
	z[cnt]=(int16_t)((buffer[4]<<8)+buffer[5])-acce_z_offset;
	cnt=(cnt>=FILTER_NUM-1?0:cnt+1);
	for(i=0;i<FILTER_NUM;i++)
	{
		sum_x+=x[i];
		sum_y+=y[i];
		sum_z+=z[i];
	}
//	Accel_x=(float)sum_x/(float)FILTER_NUM/16384.0*980;
//	Accel_y=(float)sum_y/(float)FILTER_NUM/16384.0*980;
//	Accel_z=(float)sum_z/(float)FILTER_NUM/16384.0*980;
	Accel_x=(float)sum_x/(float)FILTER_NUM;
	Accel_y=(float)sum_y/(float)FILTER_NUM;
	Accel_z=(float)sum_z/(float)FILTER_NUM;
	
	accel_mpu+=(1/(1+1/(20*PI*T)))*
							((ref_x*Accel_x+ref_y*Accel_y+ref_z*Accel_z-16384)-accel_mpu);
	
	accel_mms2=(accel_mpu/16384.0f)*10000+accel_offset;
	accel_offset=0.4f*T*((Speed_z-lastSpeed)/T-accel_mms2);  //���ٶȲ���
//	ultra_speed=(Height-lastHeight)/T;
	ultra_speed+=(1/(1+1/(8*PI*T)))*((Height-lastHeight)/T-ultra_speed);
	
	Speed_z+=(1/(1+1/(1.0f*PI*T)))*(ultra_speed-Speed_z);
	
//	Speed_z=(1-ratio)*(Speed_z+(Accel_z-Gra_Accel)*0.01)+ratio*(Height-lastHeight)/0.01;
//	Speed_z=lpf_ratio*lastSpeed+(1-lpf_ratio)*Speed_z;  //��ͨ�˲�

	lastHeight=Height;
	lastSpeed=Speed_z;
	
////	u8 buffer[2];
////	IICreadBytes(devAddr,MPU6050_RA_ACCEL_ZOUT_H,2,buffer);
////	Accel_z=(int16_t)((buffer[0]<<8)+buffer[1]);
////	Accel_z=Accel_z/16384.0;
}
/*��ȡ�������ٶ� ��λ��cm/s2*/
void Get_Gra_Accel(void)
{
	u8 buffer[2];
	int sum_z=0;
	int i=0;
	
	/*У������*/
	for(i=0;i<FILTER_NUM*20;i++)
	{
		IICreadBytes(devAddr,MPU6050_RA_ACCEL_ZOUT_H,2,buffer);
		sum_z+=(int16_t)((buffer[0]<<8)+buffer[1])-acce_z_offset;
		delay_ms(10);
	}
	
	Gra_Accel=(float)sum_z/(float)FILTER_NUM/20.0;
//	for(i=0;i<FILTER_NUM;i++)
//	{
//		z[i]=Gra_Accel;
//	}
	printf("gravity accel set complete: %.2f\r\n",Gra_Accel);
}

/*�����˲�*/
void Get_Height(void)
{
	static int cnt=0;
	static int value[FILTER_NUM]={0};
	int sum=0;
	int i=0;
	float distance=0.0;
	PCout(8)=1;
	delay_us(20);
	PCout(8)=0;
	TIM8->CNT=0;
	while(PCin(9)==0&&TIM8->CNT<1000);
	TIM8->CNT=0;
	while(PCin(9)==1&&TIM8->CNT<10000);
	distance=TIM8->CNT*tim_offset;
//	if(distance>10&&distance<200)   //����ͻ��ֵ
	{
		value[cnt]=TIM8->CNT*tim_offset;
	}
	cnt=(cnt>=FILTER_NUM-1?0:cnt+1);
	for(i=0;i<FILTER_NUM;i++)
	{
		sum+=value[i];
	}
	Height=(float)sum/(float)FILTER_NUM*0.017;
}

void Set_PWM(int l_u,int r_u,int l_d,int r_d)
{
	TIM1->CCR4=l_u;    	//����
	TIM1->CCR3=r_u;			//����
	TIM1->CCR2=l_d;			//����
	TIM1->CCR1=r_d;			//����
}

float GetMxMi(float x,float max,float min)   //�޷�
{
	return x>max?max:(x<min?min:x);
}

void Unlock(void)
{
	Set_PWM(5000,5000,5000,5000);
	PEout(1)=0;
	PEout(2)=1;
	PEout(3)=1;
	delay_ms(5000);
	PEout(1)=1;
	PEout(2)=0;
	PEout(3)=1;
}

void Landing(void)
{
//	Set_PWM(enable_fly_min,enable_fly_min,enable_fly_min,enable_fly_min);

	fixed_flag=0;
	PEout(1)=0;
	PEout(2)=1;
	PEout(3)=1;
	if(Height<20)
	{
		fly_enabled=-1;  //�رյ��
	}
	else 
	{
		Set_PWM(pwm.l_u-landing_pwm,pwm.r_u-landing_pwm,pwm.l_d-landing_pwm,pwm.r_d-landing_pwm);
	}
}
void Close_Motor(void)
{
	Set_PWM(5000,5000,5000,5000);
}

/**
  * @brief  �����ڽ��յ����ַ�������ת��Ϊ����������
  * @param  start_num ��ʼλ��
	*					len				���ݳ���
	*					int_len		��������
  * @retval ת�����
  */
float data_trans(int start_num,int len,int int_len)
{
	float data=0.0;
	for(;len>0;len--)
	{
		data+=(cmd[start_num+len-1]-48)*pow(10.0,-len+int_len);
	}
	return data;
}


/*���������*/
static float add_increment[4]={0.0,0.0,0.0,50.0};		//����
static float step_value=10.0;                          //����ֵ
void Cmd_Handle(void)
{
	//500ms���һ�ο�����
	static int clear_cnt=0;
	if(clear_cnt++>=10)
	{
		add_increment[0]=0;
		add_increment[1]=0;
		clear_cnt=0;
	}
	if(fly_enabled!=1)
	{
		add_increment[2]=defYaw/2.0;  //����ǰƫ����ƫ����Ԥ��ֵ
	}
//		add_increment[3]=0;

	if(para_setFlag)    //�����������ģʽ
	{
		while(para_setFlag)
		{
			Set_Para();
		}
		return;
	}
	if(cmdFlag)
	{
		if(cmd[0]=='C')						//�˶����� Ctrl
		{
			switch(cmd[2])
			{
				case '+':add_increment[cmd[1]-48]+=step_value;break;
				case '-':add_increment[cmd[1]-48]-=step_value;break;
			}
			add_increment[0]=GetMxMi(add_increment[0],10,-10);
			add_increment[1]=GetMxMi(add_increment[1],10,-10);
			add_increment[2]=GetMxMi(add_increment[2],20,-20);
			add_increment[3]=GetMxMi(add_increment[3],400,0);
			clear_cnt=0;
		}
		else if(cmd[0]=='S')   // Start & Stop
		{
			if(fly_enabled==-1)
			{
				fly_enabled=1;   
			}
			else
			{
				fly_enabled=(fly_enabled+1)%2;
			}
			fixed_flag=1;			//��������ģʽ
		}
		else if(cmd[0]=='P')				//�������� Parameter
		{
			para_setFlag=1;
			fly_enabled=-1;          //�����رյ��
			
		}
		
		PEout(2)=~PEout(2);
		PEout(1)=~PEout(1);
		cmdFlag=0;
	}
	
	/*����������ֵ��Ԥ��ֵ*/
	defRoll		=add_increment[0]*3.0;
	defPitch	=add_increment[1]*1.0;
	defYaw		=add_increment[2]*2;
	defHeight	=add_increment[3];
}

void Set_Para(void) 
{
	
	if(cmdFlag)
	{
		float 			data				=0.0;
		if(cmd[0]=='P')						//ָ���ж�
		{
			int 				startNum		=6;
			int 				len					=cmd[4]-48;
			int 				int_len			=cmd[5]-48;
			data=data_trans(startNum,len,int_len);
			switch(cmd[1])
			{
				case 'a':
					switch(cmd[3])
					{
						case 'p':angle_pid[cmd[2]-48].P=data;printf("OK\r\n");break;
						case 'i':angle_pid[cmd[2]-48].I=data;printf("OK\r\n");break;
						case 'd':angle_pid[cmd[2]-48].D=data;printf("OK\r\n");break;
						case 'M':angle_out_max[cmd[2]-48]=data;printf("OK\r\n");break;
						case 'm':angle_pid[cmd[2]-48].IMAX=data;printf("OK\r\n");break;
						default:printf("Error\r\n");break;
					}
					break;
				case 'g':
					switch(cmd[3])
					{
						case 'p':gyro_pid[cmd[2]-48].P=data;printf("OK\r\n");break;
						case 'i':gyro_pid[cmd[2]-48].I=data;printf("OK\r\n");break;
						case 'd':gyro_pid[cmd[2]-48].D=data;printf("OK\r\n");break;
						case 'M':gyro_out_max[cmd[2]-48]=data;printf("OK\r\n");break;
						case 'm':gyro_pid[cmd[2]-48].IMAX=data;printf("OK\r\n");break;
						default:printf("Error\r\n");break;
					}
					break;
				case 'h':
					switch(cmd[3])
					{
						case 'p':height_pid.P=data;printf("OK\r\n");break;
						case 'i':height_pid.I=data;printf("OK\r\n");break;
						case 'd':height_pid.D=data;printf("OK\r\n");break;
						case 'M':height_out_max=data;printf("OK\r\n");break;
						case 'm':height_pid.IMAX=data;printf("OK\r\n");break;
						default:printf("Error\r\n");break;
					}
					break;
				case 's':
					switch(cmd[3])
					{
						case 'p':speed_pid.P=data;printf("OK\r\n");break;
						case 'i':speed_pid.I=data;printf("OK\r\n");break;
						case 'd':speed_pid.D=data;printf("OK\r\n");break;
						case 'M':speed_z_out_max=data;printf("OK\r\n");break;
						case 'm':speed_pid.IMAX=data;printf("OK\r\n");break;
						default:printf("Error\r\n");break;
					}
					break;
				case 'f':enable_fly_min=data+5200;printf("OK\r\n");break;     //����
				case 'A':							//��̬��������
					switch(cmd[2])
					{
						case '0':defRoll=data;printf("OK\r\n");break;
						case '1':defPitch=data;printf("OK\r\n");break;
						case '2':defYaw=data;printf("OK\r\n");break;
						case '-':defHeight=data;printf("OK\r\n");break;
						default:printf("Error\r\n");break;
					}
					break;
				default:printf("Error\r\n");break;
			}
			printf("%.3f\r\n",data);
		}
		else if(cmd[0]=='O'&&cmd[1]=='K')
		{
			para_setFlag=0;
			printf("parameter set OK\r\n");
		}
		else 
		{
			printf("Error\r\n");
		}
		PEout(2)=~PEout(2);
		PEout(1)=~PEout(1);
		cmdFlag=0;
	}
	
	
}

void Data_Return(void)
{
//	static int i=0;
//	if(i==0)
//	{
//		printf("1 %.2f %.2f %.2f %d\r\n",x_out,y_out,z_out,throttle);
////		printf("1 %.2f %.2f %.2f\r\n",gyro_pid[0].OUT,gyro_pid[1].OUT,gyro_pid[2].OUT);

//	}
//	else if(i==1)
//	{
////		printf("2 %6.2f %6.2f %6.2f %d\r\n",Roll,Pitch,Yaw,enable_fly_min-5200);
//		printf("2 %.2f %.2f %.2f %.2f\r\n",defRoll,defPitch,defYaw,defHeight);
//	}
//	else if(i==2)
//	{
//		printf("3 %.2f %.2f %.2f\r\n",Gyro_x,Gyro_y,Gyro_z);
//	}
//	else if(i==3)
//	{
////		printf("4 %7.4f %7.2f %d %4.2f \r\n",Accel_z,Speed_z,fly_enabled,TIM6->CNT/100.0*tim_offset);
//		printf("4 %.2f %.2f %d %.2f\r\n\r\n",Height,Speed_z,fly_enabled,TIM6->CNT/100.0*tim_offset);
//	}
//	i=(i+1)%4;
	
	
//	static int i=0;
//	if(i==0)
//	{
//		printf("1 %6.2f %6.2f %6.2f %d\r\n",angle_pid[0].OUT,angle_pid[1].OUT,angle_pid[2].OUT,throttle);
//		printf("1 %6.2f %6.2f %6.2f\r\n",gyro_pid[0].OUT,gyro_pid[1].OUT,gyro_pid[2].OUT);

//	}
//	else if(i==1)
//	{
//		printf("2 %6.2f %6.2f %6.2f %d\r\n",Roll,Pitch,Yaw,enable_fly_min-5200);
//		printf("2 %6.2f %6.2f %6.2f %6.2f\r\n",defRoll,defPitch,defYaw,defHeight);
//	}
//	else if(i==2)
//	{
//		printf("3 %6.2f %6.2f %6.2f\r\n",Gyro_x,Gyro_y,Gyro_z);
//	}
//	else if(i==3)
//	{
////		printf("4 %7.4f %7.2f %d %4.2f \r\n",Accel_z,Speed_z,fly_enabled,TIM6->CNT/100.0*tim_offset);
//		printf("4 %6.2f %6.2f %d %4.2f\r\n\r\n",Height,Speed_z,fly_enabled,TIM6->CNT/100.0*tim_offset);
//	}
//	i=(i+1)%4;
//	i=3;
/**************************************************/

//	printf("1 %6.2f %6.2f %6.2f %d\r\n",angle_pid[0].OUT,angle_pid[1].OUT,angle_pid[2].OUT,throttle);
//	printf("1 %6.2f %6.2f %6.2f\r\n",gyro_pid[0].OUT,gyro_pid[1].OUT,gyro_pid[2].OUT);
//	printf("2 %6.2f %6.2f %6.2f %d\r\n",Roll,Pitch,Yaw,enable_fly_min-5200);
//	printf("3 %6.2f %6.2f %6.2f\r\n",Gyro_x,Gyro_y,Gyro_z);
	printf("4 %6.2f %6.2f %4d %6.2f %d\r\n",Height,Speed_z,throttle,defSpeed_z,fly_enabled);
	printf("5 %6.2f %6.2f %6.2f %6.2f\r\n\r\n",defRoll,defPitch,defYaw,defHeight);
//	printf("%7.2f,%7.2f,%7.2f\r\n",Accel_z,Height,Speed_z);
//	printf("1 %4.2f\r\n",TIM6->CNT/100.0*tim_offset);

//	printf("%6.2f %6.2f %6.2f\r\n",Accel_x,Accel_y,Accel_z);
//	printf("accel:%7.2f height:%7.2f speed:%7.2f\r\n",Accel_z,Height,Speed_z);

//	printf("%6.2f %6.2f\r\n",Height,Speed_z);

//	printf("3 %6.2f %6.2f %6.2f\r\n1 %6.2f %6.2f %6.2f %d\r\n4 %6.2f %6.2f %d %4.2f\r\n",Gyro_x,Gyro_y,Gyro_z,angle_pid[0].OUT,angle_pid[1].OUT,angle_pid[2].OUT,throttle,Height,Speed_z,fly_enabled,TIM6->CNT/100.0*tim_offset);

	
}



