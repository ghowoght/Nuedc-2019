#include "sys.h"


void PID_Init(void);
void Control(void);
void HeightControl(void);
void Get_Gyro(void);
void Get_Speed_Z(void);
void Get_Height(void);
void Set_PWM(int l_u,int r_u,int l_d,int r_d);
void Unlock(void);
float GetMxMi(float x,float max,float min);   //�޷�
void Landing(void);
void Cmd_Handle(void);
void Set_Para(void);
void Data_Return(void);
void PID_Clear_Out(void);
float data_trans(int start_num,int len,int int_len);
void Get_Gra_Accel(void);
void Fixed_Height(void);
void Read_Distance_Uart(void);
void Close_Motor(void);
float GetMxMi(float x,float max,float min);

