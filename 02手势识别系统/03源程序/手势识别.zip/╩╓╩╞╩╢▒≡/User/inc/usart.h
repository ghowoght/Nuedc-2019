#include "sys.h"

void uart_init(u32 bound);



