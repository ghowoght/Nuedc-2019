
void ADC_Configuration(void);

extern float Real_Current ;


