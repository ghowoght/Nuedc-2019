#include "sys.h"	 								  

extern float filter_ch0(void);
extern float filter_ch1(void);
extern float filter_ch2(void);
extern float filter_ch3(void);
