#include "filter.h"
#include "delay.h"
#include "FDC2X14.h"
#define R 12

char ratio[R]={1,2,3,4,5,6,7,8,9,10,11,12}; //code����Ϊ��Ȩϵ���������ڳ���洢��

char ratiosum=1+2+3+4+5+6+7+8+9+10+11+12;

float filter_ch0( )

{
	char count;
	float value_buff[R];
	float sum=0;
	for(count=0;count<R;count++)
		{	
			value_buff[count]=FDC2X14ReadCH(1);
			delay_us(1);
		}

	for(count=0;count<R;count++)

		sum+=value_buff[count]*ratio[count];
		return (sum/ratiosum);

}
float filter_ch1( )

{
	char count;
	float value_buff[R];
	float sum=0;
	for(count=0;count<R;count++)
		{	
			value_buff[count]=FDC2X14ReadCH(2);
			delay_us(1);
		}

	for(count=0;count<R;count++)
		sum+=value_buff[count]*ratio[count];
		return(sum/ratiosum);

}

float filter_ch2( )

{
	char count;
	float value_buff[R];
	float sum=0;
	for(count=0;count<R;count++)
		{	
			value_buff[count]=FDC2X14ReadCH(3);
			delay_us(1);
		}

	for(count=0;count<R;count++)
		sum+=value_buff[count]*ratio[count];
		return(sum/ratiosum);

}

float filter_ch3( )

{
	char count;
	float value_buff[R];
	float sum=0;
	for(count=0;count<R;count++)
		{	
			value_buff[count]=FDC2X14ReadCH(4);
			delay_us(1);
		}

	for(count=0;count<R;count++)
		sum+=value_buff[count]*ratio[count];
		return(sum/ratiosum);

}



