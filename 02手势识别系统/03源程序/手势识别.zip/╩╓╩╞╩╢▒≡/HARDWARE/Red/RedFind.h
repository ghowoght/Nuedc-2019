#include "sys.h"	 
#include "stm32f10x.h"
#include "control.h"

#define RightRed PAin(0)
#define LeftRed PAin(1)
#define Go_Straight() Motor_Control(3000,0)
#define Go_Back() Motor_Control(-3000,0)
#define Turn_Right() Motor_Control(4000,-4000)
#define Turn_Left() Motor_Control(4000,4000)
#define Stop_Move() Motor_Control(0,0)
#define Direction_Reverse() Motor_Control(0,2000);


#define Direct_Go_Straight() Motor_Control(1500,0)
#define Direct_Go_Back() Motor_Control(-1500,0)
#define Direct2_Turn_Right() Motor_Control(0,-2200)
#define Direct2_Turn_Left() Motor_Control(0,2200)

//#define Direct_Go_Straight() Motor_Control(3000,0)
//#define Direct_Go_Back() Motor_Control(-3000,0)
//#define Direct_Turn_Right() Motor_Control(0,-1500)
//#define Direct_Turn_Left() Motor_Control(0,1500)

void Red_Init(void);
void SearchRun(void);

