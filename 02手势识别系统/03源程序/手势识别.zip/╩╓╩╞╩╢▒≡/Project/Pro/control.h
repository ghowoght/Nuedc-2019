#include "sys.h"

void Key(void);
void TIM4_IRQHandler(void);
void TIM3_IRQHandler(void);
