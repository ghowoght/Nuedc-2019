#include "sys.h"

void KNN_GetData(void);

void Select_Mini(void);
int Distance(int n);
int KNN_Judge(void);

int Train_KNN_Judge(void)  ;
int Train_Distance(int n);
void Train_Select_Mini(void) ;
