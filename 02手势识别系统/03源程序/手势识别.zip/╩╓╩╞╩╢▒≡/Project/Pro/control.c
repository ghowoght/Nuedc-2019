#include "sys.h"
#include "string.h"
 

void TIM4_IRQHandler()
{
	if(TIM_GetITStatus(TIM4 ,  TIM_IT_Update) != RESET)
	{	
		if(Mode==1)
		{
			if(Vice_Mode!=0&&IsSaved==0)
			{
					KNN_GetData();
			}
			if(IsCompleted==1)
			{
				Get_Data();
				train_judge=Train_KNN_Judge()+1;
			}
			
		}
		/**************************************/
		if(Mode==2)
		{			
			if(IsJudged==0)
			{
				Get_Data();
				Judge=KNN_Judge()+1;
			}
			
		}


		
		TIM_ClearITPendingBit(TIM4 ,  TIM_IT_Update);
	}
}

void TIM3_IRQHandler()
{
	if(TIM_GetITStatus(TIM3 ,  TIM_IT_Update) != RESET)
	{
		Key();
		oled_show();
		TIM_ClearITPendingBit(TIM3 ,  TIM_IT_Update);
	}
}


/*************************************************/
void Key(void)
{	
	u8 tmp;
	int long_press;
	
	long_press=Long_Press();
	tmp=click_N_Double(10);   
	
	if(0==Mode)
	{
		if(tmp==2)
		{
			Mode++;
			OLED_Clear();
		}
	}
	/************************************************************/
	else if(Mode==1)				//Training
	{
		if(Mode==1&&Vice_Mode==0&&long_press==1)
		{
			debug_mode=1;
			
		}
		if(Mode==1&&Vice_Mode!=0&&long_press==1)
		{
			Get_Data();
			IsSaved=0;
			Show_Mode=1;			//��������
			OLED_Clear();		
		}
		if(tmp==1&&IsCompleted==0)
		{
			Show_Mode=0;
			if(Vice_Mode==9)
				IsCompleted=1;
			Vice_Mode++;
			if(Vice_Mode>24)
				IsCompleted=1;
			OLED_Clear();
		}		
		if(tmp==1&&IsCompleted==1)
		{
			Show_Mode=0;
			OLED_Clear();
		}
		
		else if(tmp==2)
		{
			Mode=2;
			Vice_Mode=0;
			OLED_Clear();
		}
	}
	/*******************************************************/
	else if(Mode==2)
	{
		if(tmp==1)
		{
			IsJudged=!IsJudged;
			OLED_Clear();
		}
		else if(tmp==2)
		{
			Mode=1;
			Vice_Mode=0;
			IsCompleted=0;
			OLED_Clear();
		}
	}
}


void TIM2_IRQHandler()
{
	static int n=0;
	static int m=0;
	static int q=0,p=0;
	int left;
	int right;
	int bias;
	static int t; //��ֵ���ִ���
	if(TIM_GetITStatus(TIM2 ,  TIM_IT_Update) != RESET)
	{
//		if(TIM_GetITStatus(TIM2 ,  TIM_IT_Update) != RESET)
//	{
//			Get_Data();
//			debug_mode=1;
		if(RealTech!=0)
		{
			Get_Data();
			right=FDC2X14ReadCH(1);
			left=FDC2X14ReadCH(2);
			bias=right-left;//(left[n]>right[n]?(left[n]-right[n]):(right[n]-left[n]));
			if(n<10&&bias>60&&t==0)
			{
				t++;
			}
			if(t!=0)
				n++;
			if(n>10)
			{
				n=0;
				t=0;
			}
			if(n>0&&n<10&&bias<-60&&t==1)
			{
				if(Vice_Mode==0)
					Mode=(Mode==1?2:1);
				else train_mode=(train_mode==1?2:1);
				if(Mode==1)
				{
					if(train_mode==1)
						Vice_Mode=1;
					else if(train_mode==2)
						Vice_Mode=10;
				}
				t=2;
				n=0;
				m++;
				OLED_Clear();
			}
/************************����****************************/
			
			m=(m>10?0:m+1);
			
/********************************************************/
			if(Mode==1)
			{
				{
					if(FDC2X14ReadCH(1)>790)
					{
						q++;
						if(q>5)
						{
							Vice_Mode++;
							q=0;
							m=0;
							OLED_Clear();
						}
					}
					else q=0;
				}
			}
	/*******************************/
			else if(Mode==2)
			{
				if(m!=0)
				{
					if(FDC2X14ReadCH(1)>790)
					{
						p++;
						if(p>5)
						{
							IsJudged=!IsJudged;
							p=0;
							m=0;
							OLED_Clear();
						}
					}
					else p=0;
				}
			}
				
		
		TIM_ClearITPendingBit(TIM2 ,  TIM_IT_Update);
	}
}
}
