#include "oled.h"
#include "sys.h"

unsigned char i;          //��������
unsigned char Send_Count; //������Ҫ���͵����ݸ���
float Vol;
/**************************************************************************
�������ܣ�OLED��ʾ
��ڲ�������
����  ֵ����
**************************************************************************/
void oled_show(void)
{
			if(Mode==1)         		 OLED_ShowString(30,5,"Training");
			else if(Mode==2)         OLED_ShowString(30,5,"  Judge  ");
	
	/*********************************************************************/
	if(Mode==1)		
	{
		OLED_ShowNumber(90,0,train_mode,3,12);
		if(IsCompleted==0)
		{
		switch(Vice_Mode)
			{
				case 1:OLED_ShowString(30,30," Stone_1   ");break;
				case 2:OLED_ShowString(30,30," Stone_2   ");break;
				case 3:OLED_ShowString(30,30," Stone_3   ");break;
				case 4:OLED_ShowString(30,30,"Scissors_1 ");break;
				case 5:OLED_ShowString(30,30,"Scissors_2 ");break;
				case 6:OLED_ShowString(30,30,"Scissors_3 ");break;
				case 7:OLED_ShowString(30,30," Cloth_1   ");break;
				case 8:OLED_ShowString(30,30," Cloth_2   ");break;
				case 9:OLED_ShowString(30,30," Cloth_3   ");break;
				case 10:OLED_ShowString(30,30,"  One_1   ");break;
				case 11:OLED_ShowString(30,30,"  One_2   ");break;
				case 12:OLED_ShowString(30,30,"  One_3   ");break;
				case 13:OLED_ShowString(30,30,"  Two_1   ");break;
				case 14:OLED_ShowString(30,30,"  Two_2   ");break;
				case 15:OLED_ShowString(30,30,"  Two_3   ");break;
				case 16:OLED_ShowString(30,30," Three_1  ");break;
				case 17:OLED_ShowString(30,30," Three_2  ");break;
				case 18:OLED_ShowString(30,30," Three_3  ");break;
				case 19:OLED_ShowString(30,30,"  Four_1  ");break;
				case 20:OLED_ShowString(30,30,"  Four_2  ");break;
				case 21:OLED_ShowString(30,30,"  Four_3  ");break;
				case 22:OLED_ShowString(30,30,"  Five_1  ");break;		
				case 23:OLED_ShowString(30,30,"  Five_2  ");break;		
				case 24:OLED_ShowString(30,30,"  Five_3  ");break;		
				case 25:OLED_ShowString(30,30," Start Judge");break;
			  default:OLED_ShowString(20,30,"Select Item");break;	
			}
		}
			else 
			{
				OLED_ShowString(20,20,"Gesture is: ");
		switch(train_judge)
			{
				case 1:OLED_ShowString(30,30," Stone   ");break;
				case 2:OLED_ShowString(30,30,"Scissors ");break;
				case 3:OLED_ShowString(30,30," Cloth   ");break;
				case 4:OLED_ShowString(30,30,"  One    ");break;
				case 5:OLED_ShowString(30,30,"  Two    ");break;
				case 6:OLED_ShowString(30,30," Three   ");break;
				case 7:OLED_ShowString(30,30,"  Four   ");break;
				case 8:OLED_ShowString(30,30,"  Five   ");break;
				case 9:OLED_ShowString(30,30,"  NaN   ");break;				
			  default:OLED_ShowString(20,30,"");break;	
			}
			}
		}
	/***********************************************************/
	if(Mode==2)
	{
		OLED_ShowString(20,20,"Gesture is: ");
		switch(Judge)
			{
				case 1:OLED_ShowString(30,30," Stone   ");break;
				case 2:OLED_ShowString(30,30,"Scissors ");break;
				case 3:OLED_ShowString(30,30," Cloth   ");break;
				case 4:OLED_ShowString(30,30,"  One    ");break;
				case 5:OLED_ShowString(30,30,"  Two    ");break;
				case 6:OLED_ShowString(30,30," Three   ");break;
				case 7:OLED_ShowString(30,30,"  Four   ");break;
				case 8:OLED_ShowString(30,30,"  Five   ");break;	
				case 9:OLED_ShowString(30,30,"  NaN   ");break;				
			  default:OLED_ShowString(20,30,"");break;	
			}
		}
	if(Show_Mode==0)
	{
		OLED_ShowNumber(0,40,FDC2X14ReadCH(1),8,12);
		OLED_ShowNumber(70,40,FDC2X14ReadCH(2),8,12);
		OLED_ShowNumber(0,50,FDC2X14ReadCH(3),8,12);
//		OLED_ShowNumber(70,50,FDC2X14ReadCH(4),8,12);
	}
	else 			//��ʾ��һ�βɼ���knn����
	{
		OLED_ShowNumber(0,0,data_number+1,3,12);
		OLED_ShowNumber(0,40,knn_data[data_number][0],8,12);
		OLED_ShowNumber(70,40,knn_data[data_number][1],8,12);
		OLED_ShowNumber(0,50,knn_data[data_number][2],8,12);
		OLED_ShowNumber(70,50,knn_data[data_number][3],8,12);
	}
		OLED_Refresh_Gram();				
}

void OLED_DrawPoint_Shu(u8 x,u8 y,u8 t)
{ 
	 u8 i=0;
  OLED_DrawPoint(x,y,t);
	OLED_DrawPoint(x,y,t);
	  for(i = 0;i<8; i++)
  {
      OLED_DrawPoint(x,y+i,t);
  }
}

//������ʾһ�ε�����
void oled_show_once(void)
{		
	
		OLED_ShowString(30,0," Welcome     ");
		OLED_ShowString(0,15,"Double Click ");
		OLED_ShowString(0,30,"to Continue  ");


		OLED_Refresh_Gram();	
}
