#ifndef __SHOW_H
#define __SHOW_H
#include "sys.h"

void oled_show(void);
void OLED_DrawPoint_Shu(u8 x,u8 y,u8 t);
void oled_show_once(void);
#endif
