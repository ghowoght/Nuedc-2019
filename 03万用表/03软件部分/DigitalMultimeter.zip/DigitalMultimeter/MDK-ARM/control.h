#include "sys.h"

////����һ	B��B13	A��B14	INH��B15
//#define openSwit1X0Y0			PBout(15)=0;PBout(13)=0;PBout(14)=0
//#define openSwit1X1Y1			PBout(15)=0;PBout(13)=0;PBout(14)=1
//#define openSwit1X2Y2			PBout(15)=0;PBout(13)=1;PBout(14)=0
//#define openSwit1X3Y3			PBout(15)=0;PBout(13)=1;PBout(14)=1
//#define closeSwit1				PBout(15)=1

//���ض�	B��C5		A��C6		INH��C8
#define openSwit2X0Y0			PCout(8)=0;PCout(5)=0;PCout(6)=0
#define openSwit2X1Y1			PCout(8)=0;PCout(5)=0;PCout(6)=1
#define openSwit2X2Y2			PCout(8)=0;PCout(5)=1;PCout(6)=0
#define openSwit2X3Y3			PCout(8)=0;PCout(5)=1;PCout(6)=1
#define closeSwit2				PCout(8)=1

////������	B��B9		A��B8		INH��C9
//#define openSwit3X0Y0			PCout(9)=0;PBout(9)=0;PBout(8)=0
//#define openSwit3X1Y1			PCout(9)=0;PBout(9)=0;PBout(8)=1
//#define openSwit3X2Y2			PCout(9)=0;PBout(9)=1;PBout(8)=0
//#define openSwit3X3Y3			PCout(9)=0;PBout(9)=1;PBout(8)=1
//#define closeSwit3				PCout(9)=1


