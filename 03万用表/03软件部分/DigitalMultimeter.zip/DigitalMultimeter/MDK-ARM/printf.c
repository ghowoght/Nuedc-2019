#include "printf.h"

void UART1_Printf(void)
{
	uartFlag=1;
	if(value!=0)
	{
//		printf("%.6f %d\n",value,freCount);
		printf("%.3f \n",value);
	}
//	printf("innerAD : %.6f\n",(double)(ad1*3.3f/4096));
}	

void UART2_Printf(void)
{
	uartFlag=2;
	if(value!=0)
	{
		printf("ADS1118 : %.6f\n",value);
	}
//	printf("innerAD : %.6f\n",(double)(ad1*3.3f/4096));
	
}
