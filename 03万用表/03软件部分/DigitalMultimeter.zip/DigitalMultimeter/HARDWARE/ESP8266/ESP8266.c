#include "esp8266.h"

void ESP_Init()
{
	OLED_ShowString(30,00," Initial...");
	OLED_Refresh_Gram();
	uartFlag=1;
	
//	printf("AT+CWJAP=\"GHOWOGHT\",\"12345678\"\r\n");
//	HAL_Delay(10000);
	
	
	
//	printf("+++");
//	HAL_Delay(500);
//	printf("AT+SAVETRANSLINK=1,\"192.168.43.108\",9000\r\n");
//	HAL_Delay(5000);
//	printf("AT+CWMODE=3\r\n");
//	HAL_Delay(500);
//	printf("AT+RST\r\n");
//	HAL_Delay(10000);
//	
//	printf("AT+CWJAP=\"WLF-STF-AL00\",\"12345678\"\r\n");
//	HAL_Delay(6000);
//	printf("AT+CIPSTART=\"TCP\",\"10.126.102.20\",8090\r\n");
//	HAL_Delay(1000);
//	printf("AT+CWJAP=\"GHOWOGHT\",\"12345678\"\r\n");
//	HAL_Delay(10000);
//	printf("AT+CIPSTART=\"TCP\",\"192.168.43.108\",9000\r\n");
//	HAL_Delay(4000);
//	
//	printf("AT+CIPMODE=1\r\n");
//	HAL_Delay(500);
//	printf("AT+CIPSEND\r\n");
	HAL_Delay(500);
	printf("OK");
}
