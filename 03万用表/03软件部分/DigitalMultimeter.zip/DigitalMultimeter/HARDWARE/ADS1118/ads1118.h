#include "sys.h"

#define ADS1118_CS_1 PCout(0)
#define ADS1118_CS_2 PAout(6)

//Operational status/single-shot conversion start
#define     CONFIG_BIT_OS       (1<<15)
//MUX[2:0]: Input multiplexer configuration
#define     CONFIG_BIT_MUX      (7<<12)
//PGA[2:0]: Programmable gain amplifier configuration
#define     CONFIG_BIT_PGA      (7<<9)
//MODE: Device operating mode
#define     CONFIG_BIT_MODE     (1<<8)
//DR[2:0]: Data rate
#define     CONFIG_BIT_DR       (7<<5)
//TS_MODE: Temperature sensor mode
#define     CONFIG_BIT_TS_MODE  (1<<4)
//PULL_UP_EN: Pull-up enable
#define     CONFIG_BIT_PULLUP_EN    (1<<3)
//NOP: No operation
#define     CONFIG_BIT_NOP      (3<<1)
//CNV_RDY_FL: Conversion ready flag
#define     CONFIG_BIT_CNV_RDY_FL   (1<<0)

//6.144V / 128SPS
#define AINPN_0_GND		0xC183
#define AINPN_1_GND		0xD183
#define AINPN_2_GND		0xE183
#define AINPN_3_GND		0xF183
#define AINPN_0_1			0x8383
#define AINPN_0_3			0x9383
#define AINPN_1_3			0xA383
#define AINPN_2_3			0xB383

//256mV / 64SPS
#define _0_GND		0xCB63
#define _1_GND		0xDB63
#define _2_GND		0xEB63
#define _3_GND		0xFB63

#define SPS64			0x8163


uint32_t SPI2_RW_Reg(uint16_t CofigReg);
uint32_t SPI3_RW_Reg(uint16_t CofigReg);

