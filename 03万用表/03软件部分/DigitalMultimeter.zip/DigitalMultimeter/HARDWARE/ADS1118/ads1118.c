#include "ads1118.h"
#include "control.h"
#include "math.h"

typedef union
{
    //uint8_t Data_MSB  :8;
    //uint8_t   Data_LSB    :8;
    struct
    {
        volatile uint8_t    CNV_RDY_FL  :1;   //low
        volatile uint8_t    NOP         :2;
        volatile uint8_t    PULLUP      :1;
        volatile uint8_t    TS_MODE     :1;
        volatile uint8_t    DR          :3;
        volatile uint8_t    MODE        :1;
        volatile uint8_t    PGA         :3;
        volatile uint8_t    MUX         :3;
        volatile uint8_t    OS          :1;   //high
    } stru;
    volatile uint16_t word;

} ADS_InitTypeDef;
typedef enum
{
    CONVERING = 0x0,
    SINGLE_CONVER = 0x1
} ADS_OS_TypeDef;
typedef enum
{
    _AINPN_0_1 = 0x0,
    _AINPN_0_3 =   0x1,
    _AINPN_1_3 =   0x2,
    _AINPN_2_3 =   0x3,
    _AINPN_0_GND=  0x4,
    _AINPN_1_GND=  0x5,
    _AINPN_2_GND=  0x6,
    _AINPN_3_GND=  0x7
} ADS_MUX_TypeDef;
typedef enum
{
    PGA_6144 = 0x0,
    PGA_4096 = 0x1,
    PGA_2048 = 0x2,
    PGA_1024 = 0x3,
    PGA_512 = 0x4,
    PGA_256 = 0x5
} ADS_PGA_TypeDef;
typedef enum
{
    CONTIOUS  =  0x0,
    SINGLE_SHOT = 0x1
} ADS_MODE_TypeDef;
typedef enum
{
    DR_8_SPS   =   0x0,
    DR_16_SPS  =   0x1,
    DR_32_SPS  =   0x2,
    DR_64_SPS  =   0x3,
    DR_128_SPS =   0x4,
    DR_250_SPS =   0x5,
    DR_475_SPS =   0x6,
    DR_860_SPS =   0x7
} ADS_DATARATE_TypeDef;
typedef enum
{
    ADC_MODE    =   0x0,
    TEMPERATURE_MODE =  0x1
} ADS_TSMODE_TypeDef;
typedef enum
{
    PULL_UP_DIS = 0x0,
    PULL_UP_EN  = 0x1
} ADS_PULL_TypeDef;

typedef enum
{
    DATA_VALID      = 0x1,
    DATA_INVALID    = 0x0
} ADS_NOP_TypeDef;
typedef enum
{
    DATA_READY = 0x0,
    DATA_NREADY = 0x1
} ADS_RDY_TypeDef;




uint32_t SPI2_RW_Reg(uint16_t CofigReg)
{
	uint8_t data[4]={0};
	uint32_t Data;
	uint8_t TxData[]={(uint8_t)(CofigReg>>8),(uint8_t)CofigReg};
	SPI2_WriteReadByte(&TxData[0],&data[0]);
	SPI2_WriteReadByte(&TxData[1],&data[1]);
	SPI2_WriteReadByte(&TxData[0],&data[2]);
	SPI2_WriteReadByte(&TxData[1],&data[3]);
	Data=(data[0]<<24)|(data[1]<<16)|(data[2]<<8)|(data[3]&0xff);
	return Data;
}

uint32_t SPI3_RW_Reg(uint16_t CofigReg)
{
	uint8_t data[4]={0};
	uint32_t Data;
	uint8_t TxData[]={(uint8_t)(CofigReg>>8),(uint8_t)CofigReg};
	SPI3_WriteReadByte(&TxData[0],&data[0]);
	SPI3_WriteReadByte(&TxData[1],&data[1]);
	SPI3_WriteReadByte(&TxData[0],&data[2]);
	SPI3_WriteReadByte(&TxData[1],&data[3]);
	Data=(data[0]<<24)|(data[1]<<16)|(data[2]<<8)|(data[3]&0xff);
	return Data;
}
void SPI2writeReg(uint16_t CofigReg)
{
	uint8_t TxData[]={(uint8_t)(CofigReg>>8),(uint8_t)CofigReg};
	SPI2_WriteByte(TxData[0]);
	SPI2_WriteByte(TxData[1]);
}

uint16_t SPI2readReg()
{
	uint8_t data[2];
	uint16_t Data;
	SPI2_ReadByte(&data[0]);
	SPI2_ReadByte(&data[1]);
	Data=(data[0]<<8)|(data[1]&0xff);
	return Data;
}

uint16_t SPI3readReg()
{
	uint8_t data[2];
	uint16_t Data;
	SPI3_ReadByte(&data[0]);
	SPI3_ReadByte(&data[1]);
	Data=(data[0]<<8)|(data[1]&0xff);
	return Data;
}

void Get_adsValue()
{
	ADS_InitTypeDef ADS_InitStructure;
	
	ADS_InitStructure.stru.OS         	= SINGLE_CONVER;
	ADS_InitStructure.stru.MUX 					= _AINPN_3_GND;
	ADS_InitStructure.stru.PGA        	= PGA_6144;
	ADS_InitStructure.stru.MODE 				= SINGLE_SHOT;
	ADS_InitStructure.stru.DR         	= DR_128_SPS;
	ADS_InitStructure.stru.TS_MODE      = ADC_MODE;                                 //ad mode
	ADS_InitStructure.stru.PULLUP       = PULL_UP_DIS;
	ADS_InitStructure.stru.NOP          = DATA_VALID;
	ADS_InitStructure.stru.CNV_RDY_FL 	= DATA_NREADY;
	
	printf("%.6f \n",Get_adsValue_0(ADS_InitStructure.word));
//	SPI2_RW_Reg(ADS_InitStructure.word); 
//	while(PCin(2));	
//	
//	adsValue=SPI2_RW_Reg(ADS_InitStructure.word);
//	printf("%.3f \n",(double)((adsValue&0xFFFF0000)>>16)*6.144*2/32767);
	
}

float Get_adsValue_0(uint16_t word)
{

	SPI3_RW_Reg(word);                                                   //write 0x8583 to ads1118  ,twice 
	while(PCin(11));                        //loop until DOUT/DRDY set low
	
	adsValue=SPI3_RW_Reg(word);
	return (double)((adsValue&0xFFFF0000)>>16)*6.144*2/32767;
	//UART1_Printf();
		
	
}

void Get_SR()
{
	ADS_InitTypeDef ADS_InitStructure;
	
	ADS_InitStructure.stru.OS         	= SINGLE_CONVER;
	ADS_InitStructure.stru.MUX 					= _AINPN_1_GND;
	ADS_InitStructure.stru.PGA        	= PGA_4096;
	ADS_InitStructure.stru.MODE 				= SINGLE_SHOT;
	ADS_InitStructure.stru.DR         	= DR_128_SPS;
	ADS_InitStructure.stru.TS_MODE      = ADC_MODE;                                 //ad mode
	ADS_InitStructure.stru.PULLUP       = PULL_UP_DIS;
	ADS_InitStructure.stru.NOP          = DATA_VALID;
	ADS_InitStructure.stru.CNV_RDY_FL 	= DATA_NREADY;
	
	SPI3_RW_Reg(ADS_InitStructure.word);                                                   //write 0x8583 to ads1118  ,twice 
	while(PCin(11));                        //loop until DOUT/DRDY set low
	
	adsValue=SPI3_RW_Reg(ADS_InitStructure.word);
//	value=(double)((adsValue&0xFFFF0000)>>16)*4.096*2/32767*0.3125;
	value=(double)((adsValue&0xFFFF0000)>>16)*4.096*2/32767;
	r_value=value/0.016;
	printf("V:%.3f R:%.3f\n",value,r_value);
		
	
}

void Get_adsValue_1(uint16_t word)
{

	SPI2_RW_Reg(word);                                                   //write 0x8583 to ads1118  ,twice 
	while(PCin(2));                        //loop until DOUT/DRDY set low
	
	adsValue=SPI2_RW_Reg(word);
	value=(double)((adsValue&0xFFFF0000)>>16)*6.144*2/32767;
	//UART1_Printf();
		
	
}

void Get_adsValue_2(uint16_t word)
{
	SPI3_RW_Reg(word);                                                   //write 0x8583 to ads1118  ,twice 
	while(PCin(11));                        //loop until DOUT/DRDY set low
	
	adsValue=SPI3_RW_Reg(word);
	
	value=(double)((adsValue&0xFFFF0000)>>16)*6.144*2/32767;
//	UART1_Printf();

}

void Read_R(void)
{
	static float value1,value2,value3;
	const float V2=1.65;
	const float V3=1.65;
	const float V4=1.65;
	const float R2=465.5;
	const float R3=9983.18;
	const float R4=295.1;
	const float I=0.016;
	static int 	flag=0;

	if(flag==0)
	{
		Get_adsValue_1(AINPN_1_GND);
		value1=value;
//		printf("%.3f \n",value);
		value1=4*R2*(value1-V2)/(3.3-2*value1+2*V2);
		if(value1>500)
			value1=value1*0.9847+7.4064;			//���
		
		Get_adsValue_2(AINPN_3_GND);
		value3=value;
//		printf("%.3f \n",value);
		value3=4*R4*(value3-V4)/(3.3-2*value3+2*V4);
		if(value3<250)
			value3=0.0002*value3*value3+1.0564*value3+9.3098;
		else
			value3=0.9606*pow(value3,1.0295);
		flag=1;
	}
	else
	{
		Get_adsValue_1(AINPN_2_GND);
		value2=value;
//		printf("%.3f \n",value);
		value2=4*R3*(value2-V3)/(3.3-2*value2+2*V3);
		if(value2<6000)
			value2=value2*0.9915-62.681;
		else
			value2=value2*0.9829+32.398;
		
//		Get_adsValue_2(SPS64);
//		value4=value;
//		value4=value4/I;
		
		flag=0;
	}
	
	if(value1>6000||value1<0)
	{
		if(value2>100000||value2<0)
		{
			if(value3>2000)
			{
				subMode=0;
			}
			else
			{
				r_value=value3;
				subMode=4;
			}
		}
		else 
		{
			r_value=value2;
			subMode=3;
		}
	}
	else 
	{
		r_value=value1;
		subMode=2;
	}
	
//	else 
//	{
//		r_value=value4;
//		subMode=1;
//	}

//	value4=4*R2*(value1-V2)/(3.3-2*value1+2*V2);
//	printf("%.3f %.3f %.3f \n",value1,value2,value3);
//	r_value=value2;
	printf("%.4f \n",r_value);
}

void Get_VD(void)
{
	ADS_InitTypeDef ADS_InitStructure;
	
	ADS_InitStructure.stru.OS         	= SINGLE_CONVER;
	ADS_InitStructure.stru.MUX 					= _AINPN_0_GND;
	ADS_InitStructure.stru.PGA        	= PGA_4096;
	ADS_InitStructure.stru.MODE 				= SINGLE_SHOT;
	ADS_InitStructure.stru.DR         	= DR_128_SPS;
	ADS_InitStructure.stru.TS_MODE      = ADC_MODE;                                 //ad mode
	ADS_InitStructure.stru.PULLUP       = PULL_UP_DIS;
	ADS_InitStructure.stru.NOP          = DATA_VALID;
	ADS_InitStructure.stru.CNV_RDY_FL 	= DATA_NREADY;
	
	SPI2_RW_Reg(ADS_InitStructure.word);                                                   //write 0x8583 to ads1118  ,twice 
	while(PCin(2));                        //loop until DOUT/DRDY set low
	
	adsValue=SPI2_RW_Reg(ADS_InitStructure.word);
	v_d_value=(double)((adsValue&0xFFFF0000)>>16)*4.096*2/32767;
	printf("%.6f \n",v_d_value);
	
	
	
}

void Get_Vrms_LF(void)
{
	ADS_InitTypeDef ADS_InitStructure;
	
	ADS_InitStructure.stru.OS         	= SINGLE_CONVER;
	ADS_InitStructure.stru.MUX 					= _AINPN_0_GND;
	ADS_InitStructure.stru.PGA        	= PGA_2048;
	ADS_InitStructure.stru.MODE 				= SINGLE_SHOT;
	ADS_InitStructure.stru.DR         	= DR_128_SPS;
	ADS_InitStructure.stru.TS_MODE      = ADC_MODE;                                 //ad mode
	ADS_InitStructure.stru.PULLUP       = PULL_UP_DIS;
	ADS_InitStructure.stru.NOP          = DATA_VALID;
	ADS_InitStructure.stru.CNV_RDY_FL 	= DATA_NREADY;
	
	SPI3_RW_Reg(ADS_InitStructure.word);                                                   //write 0x8583 to ads1118  ,twice 
	while(PCin(11));                        //loop until DOUT/DRDY set low
	
	adsValue=SPI3_RW_Reg(ADS_InitStructure.word);
	value=(double)((adsValue&0xFFFF0000)>>16)*2.048*2/32767;
	printf("%.6f \n",value);
	
}

void Get_Vrms_HF(void)
{
	ADS_InitTypeDef ADS_InitStructure;
	
	ADS_InitStructure.stru.OS         	= SINGLE_CONVER;
	ADS_InitStructure.stru.MUX 					= _AINPN_2_GND;
	ADS_InitStructure.stru.PGA        	= PGA_2048;
	ADS_InitStructure.stru.MODE 				= SINGLE_SHOT;
	ADS_InitStructure.stru.DR         	= DR_128_SPS;
	ADS_InitStructure.stru.TS_MODE      = ADC_MODE;                                 //ad mode
	ADS_InitStructure.stru.PULLUP       = PULL_UP_DIS;
	ADS_InitStructure.stru.NOP          = DATA_VALID;
	ADS_InitStructure.stru.CNV_RDY_FL 	= DATA_NREADY;
	
	SPI3_RW_Reg(ADS_InitStructure.word);                                                   //write 0x8583 to ads1118  ,twice 
	while(PCin(11));                        //loop until DOUT/DRDY set low
	
	adsValue=SPI3_RW_Reg(ADS_InitStructure.word);
	v_rms_value=(double)((adsValue&0xFFFF0000)>>16)*2.048*2/32767;
	printf("%.6f \n",v_rms_value);
	
}

