#include "show.h"
#include "oled.h"
#include "math.h"

/**************************************************************************
�������ܣ�OLED��ʾ
��ڲ�������
����  ֵ����
*****Mode******
********1**����
********2**С����
********3**���
********4**����
********5**ֱ����ѹ
********6**������ѹ

**************************************************************************/
void oled_show(void)	
{
	if(oledFreshFlag==1)
	{
		OLED_Clear();
		oledFreshFlag=0;
	}
		if(Mode==1)
		{
			OLED_ShowString(30,00,"  Mode R  ");
			if(subMode==0)
			{
				OLED_ShowString(00,30,"      *****    ");
			}
			else
			{
				ShowSmallNum(r_value,10,30);
//			OLED_ShowNumber(00,30,r_value,4,14);
//			
//			OLED_ShowNumber(45,30,(int)(r_value*10000)%10000,6,14);
//			OLED_ShowString(35,30,".");
			OLED_ShowString(105,30,"om");
			}
		}
		else if(Mode==2)
		{
			OLED_ShowString(30,00,"  Mode SR  ");
			
//			OLED_ShowNumber(00,30,r_value,4,14);
//			
//			OLED_ShowNumber(45,30,(int)(r_value*10000)%10000,6,14);
//			OLED_ShowString(35,30,".");
			ShowSmallNum(r_value,10,30);
			OLED_ShowString(105,30,"om");
			
		}
		else if(Mode==3)
		{
			OLED_ShowString(30,00,"  Mode L  ");
			OLED_ShowString(105,30,"Hz");
			OLED_ShowNumber(35,30, freCount,8,14);

			ShowSmallNum(l_value,10,45);
			
//			OLED_ShowNumber(00,45,l_value,4,14);
//			OLED_ShowNumber(38,45,(int)(l_value*10000)%10000,5,14);
//			OLED_ShowString(35,45,".");
			OLED_ShowString(105,45,"uH");
			
		}
		else if(Mode==4)
		{
			OLED_ShowString(30,00,"  Mode C  ");
			OLED_ShowString(105,30,"Hz");
			OLED_ShowNumber(35,30, freCount,8,14);
			
			ShowSmallNum(c_value,10,45);
//			OLED_ShowNumber(00,45,c_value,4,14);
//			OLED_ShowNumber(38,45,(int)(c_value*10000)%10000,5,14);
//			OLED_ShowString(35,45,".");
			OLED_ShowString(105,45,"pF");
		}
		else if(Mode==5)
		{
			OLED_ShowString(30,00,"  Mode VD  ");
			ShowSmallNum(v_d_value,10,30);
//			OLED_ShowNumber(0,30,v_d_value,2,14);
//			OLED_ShowNumber(18,30,(int)(value*10000)%10000,5,14);
//			OLED_ShowString(15,30,".");
			OLED_ShowString(105,30,"V");
			
		}
		else if(Mode==6)
		{
			OLED_ShowString(30,00,"  Mode Vrms  ");
			ShowSmallNum(v_rms_value,10,30);
//			OLED_ShowNumber(0,30,v_rms_value,2,14);
//			OLED_ShowNumber(18,30,(int)(value*10000)%10000,5,14);
//			OLED_ShowString(15,30,".");
			OLED_ShowString(105,30,"V");
			
		}
		else oled_show_once();

//		//=============ˢ��=======================//
		OLED_Refresh_Gram();		
		
		
		
	}

void OLED_DrawPoint_Shu(u8 x,u8 y,u8 t)
{ 
	 u8 i=0;
  OLED_DrawPoint(x,y,t);
	OLED_DrawPoint(x,y,t);
	  for(i = 0;i<8; i++)
  {
      OLED_DrawPoint(x,y+i,t);
  }
}

//������ʾһ�ε�����
void oled_show_once(void)
{
//	ShowSmallNum(2,0,45);
	OLED_ShowString(0,00,"Double Click To");
	OLED_ShowString(0,15,"Select Mode...");
	OLED_ShowString(0,30,"Current Mode Is");
	OLED_ShowString(10,45,"    Init   ");
	OLED_Refresh_Gram();	
}

void ShowSmallNum(float num,u8 x,u8 y)
{
//	int flag=0;
//	num=5987.23;
	num*=10000;
	OLED_ShowNumber(x-10,y,num/pow(10,8),1,14);
	num=num-(int)(num/pow(10,8))*pow(10,8);	//2345678
	OLED_ShowNumber(x+0,y,num/pow(10,7),1,14);
	num=num-(int)(num/pow(10,7))*pow(10,7);	//2345678
	OLED_ShowNumber(x+10,y,num/pow(10,6),1,14);
	num=num-(int)(num/pow(10,6))*pow(10,6);	//345678
	OLED_ShowNumber(x+20,y,num/pow(10,5),1,14);
	num=num-(int)(num/pow(10,5))*pow(10,5);	//45678
	OLED_ShowNumber(x+30,y,num/pow(10,4),1,14);
	num=num-(int)(num/pow(10,4))*pow(10,4);	//5678
	OLED_ShowNumber(x+50,y,num/pow(10,3),1,14);
	num=num-(int)(num/pow(10,3))*pow(10,3);	//678
	OLED_ShowNumber(x+60,y,num/pow(10,2),1,14);
	num=num-(int)(num/pow(10,2))*pow(10,2);	//78
	OLED_ShowNumber(x+70,y,num/pow(10,1),1,14);
	num=num-(int)(num/pow(10,1))*pow(10,1);	//8
	OLED_ShowNumber(x+80,y,num,1,14);
	
	
	OLED_ShowString(x+40,y,".");
	OLED_Refresh_Gram();	
}
