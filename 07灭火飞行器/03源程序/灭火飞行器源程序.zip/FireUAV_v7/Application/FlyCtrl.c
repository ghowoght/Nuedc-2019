#include "FlyCtrl.h"
#include "Ano_DT.h"
#include "Drv_openmv.h"
#include "FcData.h"
#include "MotionCal.h"

#define MAX_RHO 	40
#define MAX_THETA 90

_fly_ct_st fly_ctrl;

//巡线结构体
_line_st fb_line;
_line_st exp_line = {0,0};

#include "FlightCtrl.h"
#include "IMU.h"
#include "LocCtrl.h"
#include "Parameter.h"
#include "Drv_openmv.h"
#include "Drv_Uart.h"

#include "UWB.h"

_vector2_st target_point;

_vector2_st uv_loc_of;	
_vector2_st uv_loc_uwb;
_vector2_st uv_loc;

patrol_st 	patrol;

rectangle_st rectangle = {0, 0, 0, 0, 0, 1.0, 0.0};

#define FIRE_AREA 15  			//火源半径 单位：像素
#define FIRE_TIME 2000      //灭火耗时 单位：ms


enum MAP
{
	A = 0,
	T1,
	T2,
	T3,
	T4,
	B,
	C,
	D,
	E,
};

enum DIR
{
	UP,
	DOWN,
	LEFT,
	RIGHT,
	UP_RIGHT,
	UP_LEFT,
	DOWN_RIGHT,
	DOWN_LEFT,
	NULL,
};
/*无人机巡逻状态移动方向表*/    
u8 patrol_dir_table[9][9] = {{NULL,			 RIGHT,			 RIGHT,			 UP_RIGHT, UP_RIGHT, UP,			NULL, NULL, NULL},
														 {LEFT,			 NULL,		   RIGHT,			 UP_RIGHT, UP,			 UP_LEFT, NULL, NULL, NULL},
														 {LEFT,			 LEFT,		   NULL,			 UP,			 UP_LEFT,  UP_LEFT, NULL, NULL, NULL},
														 {DOWN_LEFT, DOWN_LEFT,	 DOWN,			 NULL,		 LEFT,		 LEFT,		NULL, NULL, NULL},
														 {DOWN_LEFT, DOWN,			 DOWN_RIGHT, RIGHT,		 NULL,  	 LEFT,		NULL, NULL, NULL},
														 {DOWN,			 DOWN_RIGHT, DOWN_RIGHT, RIGHT,		 RIGHT,    NULL,		NULL, NULL, NULL},
														 {UP,				 UP,				 UP,				 UP,			 UP,			 UP,			NULL, NULL, NULL},
														 {LEFT,			 LEFT,			 LEFT,			 LEFT,		 LEFT,		 LEFT,		NULL, NULL, NULL},
														 {DOWN,			 DOWN,			 DOWN,			 DOWN,		 DOWN,		 DOWN,		NULL, NULL, NULL}};
#define VEL 70
_vector2_st move_table[] = {{	 0,  -VEL},{  0,  VEL},{ VEL,   0},{-VEL, 	  0},
														{-VEL, -VEL},{VEL, -VEL},{-VEL, VEL},{ VEL, VEL},{0, 0}};

//u8 map[4][4] = {{NULL,  E,  E, NULL},
//								{	  B, T4, T3, 		D},
//								{   A, T1, T2,   	D},
//								{NULL,  C,  C, NULL}};

enum FSM
{
	S0,
	S1,
	S2,
	S3,
	S4,
	S5,
	S6,
	S7,
};


#define MOTIONLESS_THRESHOLD  10
#define HOVER_TIME 				    15000  //悬停时间 单位：ms


/*巡逻任务*/
void Patrol_Task(u8 dT_ms)
{
	patrol.curr_area = area_judge(uv_loc.x,uv_loc.y,dT_ms);  //判断当前所处区域
	patrol.state		 = is_fire(dT_ms);    //当前区域是否有火源，有则进入灭火状态 
	
	/*巡逻状态*/
	if(patrol.state == PATROLING)  
	{
		ROM_GPIOPinWrite(GPIOF_BASE, GPIO_PIN_0, 0); //关闭激光
		
		u8 direction;
		if(patrol.curr_area != patrol.last_area)  //如果无人机飞至另一个区域
		{
			if(patrol.curr_area == patrol.next_area) //如果无人机进入了航线上的下一片区域
			{
				if(patrol.curr_area == T4 && patrol.last_area == T3)
				{
					patrol.times ++;
				}
				patrol.next_area = patrol.next_area % 4 +1; //在区域T1~T4间巡逻
				patrol.last_area = patrol.curr_area;
				patrol.online = 1;
			}
			else //否则偏移了原始航线,对原始航线进行标记，并返回航线
			{
				patrol.flag_area = patrol.last_area;
				patrol.online = 0;
			}
			direction = move_dir_judge(patrol.online);
		}
		else //继续沿原始航线前进
		{
			direction = patrol_dir_table[patrol.curr_area][patrol.next_area];
		}
		/*移动速度及方向赋值*/
		target_point.x = move_table[direction].x;
		target_point.y = move_table[direction].y;
	}
	/*灭火状态*/
	else if(patrol.state == PUTTING_OUT)  
	{
		ROM_GPIOPinWrite(GPIOF_BASE, GPIO_PIN_0, GPIO_PIN_0);  //打开激光
		
		if(patrol.isflag == 0)
		{
			patrol.flag_area = patrol.curr_area;  //标记当前区域
			
			patrol.fire_state = S1; //进入前往灭火状态
			
			patrol.isflag = 1;
		}
		/*灭火过程*/
		if(patrol.fire_state == S1) //在前往火源的途中
		{
			if(target_point.x < FIRE_AREA && target_point.y < FIRE_AREA) //当无人机进入火源正上方
			{
				patrol.fire_state = S2; //进入灭火状态
			}
		}
		else if(patrol.fire_state == S2)
		{
			static int cnt = 0;
			cnt += dT_ms;
			if(cnt >= FIRE_TIME)
			{
				cnt = 0;
				patrol.fire_state = S3;  //已经在火源上方悬停2s，进入S3模式
			}
			else
			{
				cnt = 0;
			}
		}
		else if(patrol.fire_state == S3)
		{
			patrol.num_of_fire ++;  //已灭火源数加一
			patrol.fire_state = S0;
		}
		
		target_point.x = True_X_coordinate_len;
		target_point.y = True_Y_coordinate_len;
		
	}
	
}

/*移动方向判定*/
u8 move_dir_judge(u8 online)
{
	if(online)
	{
		return patrol_dir_table[patrol.curr_area][patrol.next_area];  //进入航线中的下一个区域
	}
	else
	{
		return patrol_dir_table[patrol.curr_area][patrol.flag_area];  //返回标记区域
	}
}

u8 is_fire(u8 dT_ms)
{
	if(patrol.curr_area >= T1 && patrol.curr_area <= T4 )
	{
		return flag.target_loss ? 0 : 1;	
	}
	else return 0;
}

float map_divide_table[] = {50, 150, 250};
u8 membership_calc(float area_table[], float value)  //计算从属度
{
    uint8_t index = 0;
    uint8_t i = 0;
	  float ms[2];
	
		value = LIMIT(value, map_divide_table[0], map_divide_table[2]);
	
    for (i = 0; i < 2; i++)
    {
        if ((value >= area_table[i]) && (value < area_table[i + 1]))
        {
            float k1 = 1 / (area_table[i] - area_table[i + 1]);
            ms[0] = k1 * value - k1 * area_table[i + 1];

            float k2 = 1 / (area_table[i + 1] - area_table[i]);
            ms[1] = k2 * value - k2 * area_table[i];

            index = i;
        }
    }
    return ms[0] > ms[1] ? index : (index + 1);
}
u8 area_judge(u16 x,u16 y,u8 dT_ms)
{
	static int cnt;

	u8 curr_area = uwb_area;
	
	if(curr_area != patrol.curr_area)
	{
//		cnt += dT_ms;
//		if(cnt >= 1000)
//		{
//			cnt = 0;
//			return curr_area;
//		}
//		else return patrol.curr_area;
		cnt ++;
		if(cnt >= 25)
		{
			cnt = 0;
			return curr_area;
		}
		else return patrol.curr_area;
	}
	else 
	{
		cnt = 0;
		return patrol.curr_area;
	}
	
//	static int cnt;
//	static u8  last_area;
//	u8 curr_area[] = {membership_calc(map_divide_table,x)
//									 ,membership_calc(map_divide_table,y)};
//	
//	/*查询地图*/
//	if(map[curr_area[X]][curr_area[Y]] != patrol.curr_area 
//									&& map[curr_area[X]][curr_area[Y]] == last_area)
//	{
//		cnt += dT_ms;
//		if(cnt >= 1000) //如果进入另一个区域,并保持1s，则更新当前区域
//		{
//			cnt = 0;
//			return map[curr_area[X]][curr_area[Y]];
//		}
//		else  //否则返回原值，即继续保持原始区域值
//		{
//			last_area = map[curr_area[X]][curr_area[Y]];
//			return patrol.curr_area;			
//		}
//	}
//	else
//	{
//		cnt = 0;
//		return patrol.curr_area;
//	}
//	
	
}

void FlyCtrl_Task(u8 dT_ms)  //周期：20ms
{
	Loc_Cal_Task(dT_ms);
	static int state_cnt;

	static u8  state = S0;
	Get_obs_XY_coordinate(wcz_hei_fus.out,dT_ms);
	
//	if(flag.auto_take_off_land == AUTO_TAKE_OFF_FINISH) //如果已经起飞完成
	if(flag.flying == 1 && flag.auto_take_off_land == AUTO_TAKE_OFF_FINISH) 
	{
		
		{
//			target_point.x = 0;//True_X_coordinate_len;
//			target_point.y = 0;//True_Y_coordinate_len;
			/*
			 *垂直起飞
			 *达到起飞高度开始计时
			 *计时15s后前进
			 *开始巡逻
			 *
			 */
			if(state == S0 )  
			{
				target_point.x = 0;
				target_point.y = 0;
				
				if(wcz_hei_fus.out >= Ano_Parame.set.auto_take_off_height-5)
				{
					state = S1;   //起飞达到指定高度，进入悬停状态
				}
			}
			else if(state == S1)
			{
				state_cnt += dT_ms;
				
				target_point.x = 0;
				target_point.y = 0;
				
				if(state_cnt >= HOVER_TIME)
				{
					state = S2;  //悬停15s后，进入防区，开始巡逻
					state_cnt = 0;
					patrol.curr_area = A;
					patrol.next_area = T1;
				}
			}
			else if(state == S2) //巡逻
			{
				state_cnt += dT_ms;
				Patrol_Task(dT_ms);			
				
				if(patrol.times >= 1 || state_cnt >= 100000) //火已全部扑灭且无人机已从B处飞出防区区 或 已经飞行1s
				{
					state = S3;
					state_cnt = 0;
				}
				
			}
			else if(state == S3) // 从B处飞出
			{
//					patrol.curr_area = area_judge(uv_loc.x,uv_loc.y,dT_ms);  //判断当前所处区域

//					if(patrol.curr_area != T4)  //如果无人机已离开T4 //如果无人机进入E区
//					{
//							target_point.x = move_table[LEFT].x;
//							target_point.y = move_table[LEFT].y;
//					}
//					else //继续沿原始航线前进
//					{
//						target_point.x = move_table[UP].x;
//						target_point.y = move_table[UP].y;
//					}			
				patrol.curr_area = area_judge(uv_loc.x,uv_loc.y,dT_ms / 2); 
				if(patrol.curr_area != T4) 
				{
					target_point.x = move_table[patrol_dir_table[patrol.curr_area][T4]].x;
					target_point.y = move_table[patrol_dir_table[patrol.curr_area][T4]].y;
				}
				else  //无人机已经飞至T4区
				{
					state = S4;
				}				
			}
			else if(state == S4)
			{
				patrol.curr_area = area_judge(uv_loc.x,uv_loc.y,4 * dT_ms );  //判断当前所处区域

					if(patrol.curr_area != T4)  //如果无人机已离开T4 
					{
						if(patrol.curr_area == B)
						{
							u8 data = '3';
							Drv_Uart3SendBuf(&data, 1);  //切换openmv模式为寻找十字模式
							state = S5;
						}
						else if(patrol.curr_area == E)
						{
							target_point.x = move_table[LEFT].x;
							target_point.y = move_table[LEFT].y;
						}
						else
						{
							target_point.x = move_table[patrol_dir_table[patrol.curr_area][T4]].x;
							target_point.y = move_table[patrol_dir_table[patrol.curr_area][T4]].y;
						}
					}
					else //继续沿原始航线前进
					{
						target_point.x = move_table[UP].x;
						target_point.y = move_table[UP].y;
					}
			}
			else if(state == S5)
			{
				/*前进*/
				target_point.x = move_table[DOWN].x;
				target_point.y = move_table[DOWN].y;
				
//				if(rectangle.online == 1)
//				{
//					/*使无人机对准框的中心*/
//					rectangle.err = rectangle.exp_loc - rectangle.loc;
//					target_point.x = rectangle.Kp * rectangle.err + rectangle.Kd * (rectangle.err - rectangle.last_err);
//					rectangle.last_err = rectangle.err;
//					
//					state_cnt = 0;
//				}
//				else
				
				state_cnt += dT_ms;
				if(state_cnt >= 1500 || flag.target_loss == 0)
				{
					state_cnt = 0;
					state = S6;
				}
				
			}
			else if(state == S6)
			{
				target_point.x = True_X_coordinate_len;
				target_point.y = True_Y_coordinate_len;
		
				if(my_abs(target_point.x) < 2 * MOTIONLESS_THRESHOLD               
								&& my_abs(target_point.y) < 2 * MOTIONLESS_THRESHOLD)
				{
					state_cnt += dT_ms;
					if(state_cnt >= 100)
					{
						state = S7;
						state_cnt = 0;
					}
				}
				else 
				{
					state_cnt = 0;
				}
			}
			else if(state == S7)
			{
				one_key_land();
				state = S0;
			}
			
			/*位置控制*/
			Loc_2level_Ctrl(dT_ms);
			
			fly_ctrl.vel_cmps_ref[X] = loc_val_2[X].out;
			fly_ctrl.vel_cmps_ref[Y] = loc_val_2[Y].out;
		}
		
	}
	else 
	{
		FlyCtrlReset();
		state = S0;
		patrol.next_area = T1;
		patrol.curr_area = A;
	}		
		
	//数据处理坐标转换等,以解锁时候机头指向为参考
	if(flag.unlock_sta !=0)
	{
		//参考方向转世界坐标（本飞控为地理坐标）
		h2w_2d_trans(fly_ctrl.vel_cmps_ref,fly_ctrl.ref_dir,fly_ctrl.vel_cmps_w);
		//世界坐标（本飞控为地理坐标）转水平航向坐标。
		w2h_2d_trans(fly_ctrl.vel_cmps_w,imu_data.hx_vec,fly_ctrl.vel_cmps_h);
		//水平方向变化，Z不变
		fly_ctrl.vel_cmps_h[Z] = fly_ctrl.vel_cmps_w[Z] = fly_ctrl.vel_cmps_ref[Z];
		
//		fly_ctrl.vel_cmps_h[X] = fly_ctrl.vel_cmps_w[X] = fly_ctrl.vel_cmps_ref[X];
//		fly_ctrl.vel_cmps_h[Y] = fly_ctrl.vel_cmps_w[Y] = fly_ctrl.vel_cmps_ref[Y];
	}
	else
	{
		//记录机头指向为参考方向
		fly_ctrl.ref_dir[X] = imu_data.hx_vec[X];
		fly_ctrl.ref_dir[Y] = imu_data.hx_vec[Y];
		//
	}
}

void FlyCtrlReset()
{
	//
	for(u8 i = 0;i<4;i++)
	{
		if(i<4)
		{
			fly_ctrl.vel_cmps_ref[i] = 0;
			fly_ctrl.vel_cmps_w[i] = 0;
			fly_ctrl.vel_cmps_h[i] = 0;
		}
		else
		{
			fly_ctrl.yaw_pal_dps = 0;
		}
		
		fly_ctrl.exp_process_t_ms[i] = 0;
		fly_ctrl.fb_process_t_ms[i] = 0;
	}
	
}

/************************循迹控制**********************/

//循迹偏航控制参数
_PID_arg_st arg_yaw ; 

//循迹偏航控制参数
_PID_arg_st arg_rol ;

//循迹俯仰控制数据
_PID_val_st val_yaw;

//循迹俯仰控制数据
_PID_val_st val_rol;

void Track_Yaw_PID_Init(void)
{
	arg_yaw.kp = Ano_Parame.set.pid_track_yaw_level[KP];
	arg_yaw.ki = Ano_Parame.set.pid_track_yaw_level[KI];
	arg_yaw.kd_ex = Ano_Parame.set.pid_track_yaw_level[KD];
	arg_yaw.kd_fb =Ano_Parame.set.pid_track_yaw_level[KD];
	arg_yaw.k_ff = 0;
}

void Track_Roll_PID_Init(void)
{
	arg_rol.kp = Ano_Parame.set.pid_track_rol_level[KP];
	arg_rol.ki = Ano_Parame.set.pid_track_rol_level[KI];
	arg_rol.kd_ex = Ano_Parame.set.pid_track_rol_level[KD];
	arg_rol.kd_fb =Ano_Parame.set.pid_track_rol_level[KD];
	arg_rol.k_ff = 0;
}
/*
 *循迹偏航角控制
 *输入 ：直线倾斜角
 *输出 ：期望偏航角速度
 */
void Track_Yaw_Ctrl(float dT_ms)
{
	fb_line.theta = line.theta;
	
	PID_calculate( dT_ms*1e-3f,            //周期（单位：秒）
										0,				//前馈值
										exp_line.theta,				//期望值（设定值）
										fb_line.theta,			//反馈值（）
										&arg_yaw, //PID参数结构体
										&val_yaw,	//PID数据结构体
										5,//积分误差限幅
										50			//integration limit，积分限幅									
										 );
	val_yaw.out = LIMIT(val_yaw.out, - MAX_SPEED_YAW * 0.5, MAX_SPEED_YAW * 0.5);
}	

/*
 *循迹横滚角控制
 *输入 ：与直线的距离
 *输出 ：期望水平X方向速度
 */
void Track_Roll_Ctrl(float dT_ms)
{
	fb_line.rho = line.rho;

	PID_calculate( dT_ms*1e-3f,            //周期（单位：秒）
									0,				//前馈值
									exp_line.rho,				//期望值（设定值）
									fb_line.rho,			//反馈值（）
									&arg_rol, //PID参数结构体
									&val_rol,	//PID数据结构体
									5,//积分误差限幅
									50			//integration limit，积分限幅									
									 );
	val_rol.out = LIMIT(val_rol.out, - MAX_SPEED * 0.5, MAX_SPEED * 0.5);
}
