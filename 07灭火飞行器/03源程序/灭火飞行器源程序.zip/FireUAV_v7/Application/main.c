#include "sysconfig.h"
#include "Drv_Bsp.h"
#include "Scheduler.h"
#include "FcData.h"
#include "Drv_Uart.h"

int main(void)
{
	Drv_BspInit();
	
	flag.start_ok = 1;
	
//	ROM_GPIOPinWrite(GPIOF_BASE, GPIO_PIN_0, GPIO_PIN_0); 
	
	while(1)
	{
		//��ѯ���������
		Main_Task();
	}
}
