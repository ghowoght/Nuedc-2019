#ifndef DRV_ADC_H
#define DRV_ADC_H
#include "sysconfig.h"

extern float Voltage;

void Drv_AdcInit(void); 
void Drv_Adc0Trigger(void);

#endif

