#include "Drv_openmv.h"
#include "FcData.h"
#include "Math.h"
#include "math.h"
#include "Imu.h"

#include "KNN.h"

#include "Drv_Uart.h"


u8 openmv_datatemp[20];  //���յ������ݻ���

void OPENMV_GetOneByte(uint8_t data)
{
	static u8 state = 0;
	
	if(state == 0 && data == 'A')						//֡ͷ	
	{
		state = 1;
	}                                   
	else if(state == 1)								
	{                                   
		state = 2;                        
		openmv_datatemp[state] = data ;
	}                                   
	else if(state == 2 )									
	{                                   
		state = 3;                        
		openmv_datatemp[state] = data;
	}                                   																		                     
	else if(state == 3)			            
	{                                   
		state = 4;                        
		openmv_datatemp[state] = data ;
	}                                   
	else if(state == 4)			            
	{                                   
		state = 5;                        
		openmv_datatemp[state] = data ;
	}                                   
	else if(state == 5)			            
	{                                   
		state = 6;                        
		openmv_datatemp[state] = data ;
	}                               
	else if(state == 6)			         
	{                               
		state = 7;                   
		openmv_datatemp[state] = data ;
	}
	else if(state == 7)			         
	{                               
		                  
		openmv_datatemp[state] = data ;
		
		openmv_datatemp[0] = 0xAA;
		openmv_datatemp[1] = area;
		
//		Drv_Uart2SendBuf(openmv_datatemp,8);
		
		state = 0;  
	}
	else
	{
		state = 0;
	}
}

