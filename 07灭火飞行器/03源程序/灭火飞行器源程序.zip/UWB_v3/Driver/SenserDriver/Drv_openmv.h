#ifndef _DRV_OPENMV_H_
#define _DRV_OPENMV_H_

#include "sysconfig.h"

#define N1 8
/************************Ѱ�����***************************/
extern u16 openmv_X_coordinate;
extern u16 openmv_Y_coordinate;
extern u8 color_code_name;
extern float True_X_coordinate_len;
extern float True_Y_coordinate_len;


void OPENMV_GetOneByte(uint8_t data);
void OPENMV_DataAnl(uint8_t *data_buf);



enum
{
	TRACK_POINT = 0,
	TRACK_LINE,
};
extern u8 openmv_datatemp[20];


#endif
