#include "Drv_Timer.h"


void TA0_A_IRQHandler(void)
{
    
    ROM_TimerIntClear(TIMER0_BASE,TIMER_TIMA_TIMEOUT);
}


void Time0_A_Init(void)//Time0_A��ʼ������
{
    //
    // Enable the Timer0 peripheral
    //
    SysCtlPeripheralEnable(SYSCTL_PERIPH_TIMER0);
    ROM_TimerConfigure (TIMER0_BASE, TIMER_CFG_PERIODIC);
    ROM_TimerLoadSet (TIMER0_BASE, TIMER_A, SysCtlClockGet()/100); //100Hz
		ROM_TimerIntRegister(TIMER0_BASE,TIMER_A,TA0_A_IRQHandler);
	  ROM_IntEnable (INT_TIMER0A);	
    ROM_TimerIntEnable (TIMER0_BASE, TIMER_TIMA_TIMEOUT);
    ROM_TimerEnable (TIMER0_BASE, TIMER_A);
}