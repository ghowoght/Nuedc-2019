#include "timer.h"
#include "hw_ints.h"


void Time0_A_Init(void);


