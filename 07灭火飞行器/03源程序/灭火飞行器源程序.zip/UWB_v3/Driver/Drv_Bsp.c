#include "Drv_Bsp.h"
#include "Drv_RcIn.h"
#include "Drv_Spi.h"
#include "Drv_Led.h"
#include "Drv_Paramter.h"

#include "Drv_PwmOut.h"
#include "Drv_Adc.h"
#include "Drv_Uart.h"



static uint64_t SysRunTimeMs = 0;

void SysTick_Init(void )
{
	ROM_SysTickPeriodSet(ROM_SysCtlClockGet()/1000);
	ROM_SysTickIntEnable();
	ROM_SysTickEnable();
}
void SysTick_Handler(void)
{
	SysRunTimeMs++;
}
uint32_t GetSysRunTimeMs(void)
{
	return SysRunTimeMs;
}
uint32_t GetSysRunTimeUs(void)
{
	return SysRunTimeMs*1000 + (SysTick->LOAD - SysTick->VAL) * 1000 / SysTick->LOAD;
}

void MyDelayMs(u32 time)
{
	ROM_SysCtlDelay(80000 * time /3);
}

void Drv_PMW3901CSPinInit(void)
{
	ROM_SysCtlPeripheralEnable(PMW_CSPIN_SYSCTL);
	ROM_GPIOPinTypeGPIOOutput(PMW_CS_PORT,PMW_CS_PIN);
	ROM_GPIOPinWrite(PMW_CS_PORT, PMW_CS_PIN,PMW_CS_PIN);
}

void Drv_SenserCsPinInit(void)
{
	Drv_PMW3901CSPinInit();
	
	ROM_SysCtlPeripheralEnable(FLASH_CSPIN_SYSCTL);
	ROM_GPIOPinTypeGPIOOutput(FLASH_CS_PORT,FLASH_CS_PIN);
	ROM_GPIOPinWrite(FLASH_CS_PORT, FLASH_CS_PIN,FLASH_CS_PIN);
}

void Drv_BspInit(void)
{
	/*����ϵͳ��ƵΪ80M*/
	ROM_SysCtlClockSet(SYSCTL_SYSDIV_2_5 | SYSCTL_USE_PLL | SYSCTL_XTAL_16MHZ |SYSCTL_OSC_MAIN);
	/*�ж����ȼ��������*/
	NVIC_SetPriorityGrouping(0x03);
	/*�����������㵥Ԫ*/	
	ROM_FPULazyStackingEnable();
	ROM_FPUEnable();

	//�ƹ��ʼ��
	Dvr_LedInit();

//	//spiͨ�ų�ʼ��
//	Drv_Spi0Init();
//	Drv_SenserCsPinInit();

//	//��������ʼ��
//	Drv_PwmOutInit();
//	//ADC��ʼ��
//	Drv_AdcInit();
	//�δ�ʱ�ӳ�ʼ��
	SysTick_Init();	
	//���ڳ�ʼ��
	
	Drv_Uart5Init(500000);	//��UWB   RX:D6  TX:D7	����2
	Drv_Uart2Init(500000);	//�ӷɿ�  RX:C4	 TX:C5  ����4
	
	Drv_Uart3Init(115200);  //��openmv  RX:E4	 TX:E5

	
	Drv_Uart1Init(115200);	//USB���� / ң��
	
//	UARTStdioConfig(0, 9600, 80000000);
}




