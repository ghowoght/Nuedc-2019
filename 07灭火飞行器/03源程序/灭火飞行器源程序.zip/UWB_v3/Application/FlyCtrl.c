#include "FlyCtrl.h"
#include "Ano_DT.h"
#include "Drv_openmv.h"
#include "FcData.h"

#define MAX_RHO 	40
#define MAX_THETA 90

_fly_ct_st fly_ctrl;

//巡线结构体
_line_st fb_line;
_line_st exp_line = {0,0};

static u16 val, spd;

void FlyCtrlDataAnl(u8 *data)
{
	val = ((*(data+3))<<8) + (*(data+4));
	spd = ((*(data+5))<<8) + (*(data+6));	
	fly_ctrl.cmd_state[0] = *(data+2);
}

#include "FcData.h"
#include "FlightCtrl.h"
#include "IMU.h"
#include "LocCtrl.h"
#include "Parameter.h"

_vector2_st target_point;

static u8 cmd_take_off_f;
void FlyCtrl_Task(u8 dT_ms)  //周期：20ms
{
	if(flag.auto_take_off_land == AUTO_TAKE_OFF_FINISH) //如果已经起飞完成
	{
		if(flag.ctrl_mode==FOLLOW)
		{
			target_point.x= True_X_coordinate_len;
			target_point.y= True_Y_coordinate_len;
			
			Loc_2level_Ctrl(dT_ms);
			
			fly_ctrl.vel_cmps_ref[X] = loc_val_2[X].out;
			fly_ctrl.vel_cmps_ref[Y] = loc_val_2[Y].out;
		}
		else if(flag.ctrl_mode==TRACK)
		{			
			Track_Roll_Ctrl(dT_ms);
			Track_Yaw_Ctrl(dT_ms);			
			
			fly_ctrl.yaw_pal_dps = val_yaw.out;
			fly_ctrl.vel_cmps_ref[X] = val_rol.out;
			
			//前进速度赋值
			float rho_norm = fb_line.rho / MAX_RHO;  //归一化
			float theta_norm = fb_line.theta / MAX_THETA;
			float norm = rho_norm > theta_norm ? rho_norm : theta_norm;
			if(norm > 0.8)  //如果偏差过大
			{
				fly_ctrl.vel_cmps_ref[Y] = 0.0;
			}
			else if(norm > 0.4) 
			{
				fly_ctrl.vel_cmps_ref[Y] = MAX_SPEED * 0.05;
			}
			else if(norm > 0.1)
			{
				fly_ctrl.vel_cmps_ref[Y] = MAX_SPEED * 0.1;
			}
			else
			{
				fly_ctrl.vel_cmps_ref[Y] = MAX_SPEED * 0.2;
			}
		}
		else 
		{
			FlyCtrlReset();
		}
	}
	else 
	{
		FlyCtrlReset();
	}		
		
	//数据处理坐标转换等,以解锁时候机头指向为参考
	if(flag.unlock_sta !=0)
	{
//		//参考方向转世界坐标（本飞控为地理坐标）
//		h2w_2d_trans(fly_ctrl.vel_cmps_ref,fly_ctrl.ref_dir,fly_ctrl.vel_cmps_w);
//		//世界坐标（本飞控为地理坐标）转水平航向坐标。
//		w2h_2d_trans(fly_ctrl.vel_cmps_w,imu_data.hx_vec,fly_ctrl.vel_cmps_h);
//		//水平方向变化，Z不变
		fly_ctrl.vel_cmps_h[Z] = fly_ctrl.vel_cmps_w[Z] = fly_ctrl.vel_cmps_ref[Z];
		fly_ctrl.vel_cmps_h[X] = fly_ctrl.vel_cmps_w[X] = fly_ctrl.vel_cmps_ref[X];
		fly_ctrl.vel_cmps_h[Y] = fly_ctrl.vel_cmps_w[Y] = fly_ctrl.vel_cmps_ref[Y];
	}
	else
	{
		//记录机头指向为参考方向
		fly_ctrl.ref_dir[X] = imu_data.hx_vec[X];
		fly_ctrl.ref_dir[Y] = imu_data.hx_vec[Y];
		//
	}
}

void FlyCtrlReset()
{
	//
	cmd_take_off_f = 0;
	//
	for(u8 i = 0;i<4;i++)
	{
		if(i<4)
		{
			//
			fly_ctrl.vel_cmps_ref[i] = 0;
			fly_ctrl.vel_cmps_w[i] = 0;
			fly_ctrl.vel_cmps_h[i] = 0;
		}
		else
		{
			fly_ctrl.yaw_pal_dps = 0;
		}
		
		fly_ctrl.exp_process_t_ms[i] = 0;
		fly_ctrl.fb_process_t_ms[i] = 0;
	}
	
}

/************************循迹控制**********************/

//循迹偏航控制参数
_PID_arg_st arg_yaw ; 

//循迹偏航控制参数
_PID_arg_st arg_rol ;

//循迹俯仰控制数据
_PID_val_st val_yaw;

//循迹俯仰控制数据
_PID_val_st val_rol;

void Track_Yaw_PID_Init(void)
{
	arg_yaw.kp = Ano_Parame.set.pid_track_yaw_level[KP];
	arg_yaw.ki = Ano_Parame.set.pid_track_yaw_level[KI];
	arg_yaw.kd_ex = Ano_Parame.set.pid_track_yaw_level[KD];
	arg_yaw.kd_fb =Ano_Parame.set.pid_track_yaw_level[KD];
	arg_yaw.k_ff = 0;
}

void Track_Roll_PID_Init(void)
{
	arg_rol.kp = Ano_Parame.set.pid_track_rol_level[KP];
	arg_rol.ki = Ano_Parame.set.pid_track_rol_level[KI];
	arg_rol.kd_ex = Ano_Parame.set.pid_track_rol_level[KD];
	arg_rol.kd_fb =Ano_Parame.set.pid_track_rol_level[KD];
	arg_rol.k_ff = 0;
}
/*
 *循迹偏航角控制
 *输入 ：直线倾斜角
 *输出 ：期望偏航角速度
 */
void Track_Yaw_Ctrl(float dT_ms)
{
	fb_line.theta = line.theta;
	
	PID_calculate( dT_ms*1e-3f,            //周期（单位：秒）
										0,				//前馈值
										exp_line.theta,				//期望值（设定值）
										fb_line.theta,			//反馈值（）
										&arg_yaw, //PID参数结构体
										&val_yaw,	//PID数据结构体
										5,//积分误差限幅
										50			//integration limit，积分限幅									
										 );
	val_yaw.out = LIMIT(val_yaw.out, - MAX_SPEED_YAW * 0.5, MAX_SPEED_YAW * 0.5);
}	

/*
 *循迹横滚角控制
 *输入 ：与直线的距离
 *输出 ：期望水平X方向速度
 */
void Track_Roll_Ctrl(float dT_ms)
{
	fb_line.rho = line.rho;

	PID_calculate( dT_ms*1e-3f,            //周期（单位：秒）
									0,				//前馈值
									exp_line.rho,				//期望值（设定值）
									fb_line.rho,			//反馈值（）
									&arg_rol, //PID参数结构体
									&val_rol,	//PID数据结构体
									5,//积分误差限幅
									50			//integration limit，积分限幅									
									 );
	val_rol.out = LIMIT(val_rol.out, - MAX_SPEED * 0.5, MAX_SPEED * 0.5);
}


//#include "Math.h"
//void test(float dT_s)
//{
//	static float sp_x=0,sp_y=0,sp_z=0;
////	float accel_x = imu_data.x_vec[X] * imu_data.a_acc[X] + imu_data.x_vec[Z] * imu_data.a_acc[Z] + imu_data.x_vec[Z] * imu_data.a_acc[Z];

////	if(ABS(imu_data.w_acc[X])>20)
////		sp_z+=(imu_data.w_acc[X]>0?(imu_data.w_acc[X]-20):(imu_data.w_acc[X]+20))*dT_s;
//	sp_z+=981*fast_tan(imu_data.pit*3.1415926535/180.0);
////	UARTprintf("%d\r\n",(int)(sp_z));
//	UARTprintf("%d %d\r\n",(int)(981*fast_tan(imu_data.pit*3.1415936535/180)),(int)(imu_data.pit*100));
//	
//}