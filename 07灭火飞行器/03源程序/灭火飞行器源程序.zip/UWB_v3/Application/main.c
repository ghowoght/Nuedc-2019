#include "sysconfig.h"
#include "Drv_Bsp.h"
#include "KNN.h"
#include "Drv_Uart.h"
#include "Drv_openmv.h"

#include "stdio.h"

#ifdef __GNUC__
    #define PUTCHAR_PROTOTYPE int __io_putchar(int ch)
#else
    #define PUTCHAR_PROTOTYPE int fputc(int ch, FILE *f)
#endif /* __GNUC__ */
    PUTCHAR_PROTOTYPE
    {
        ROM_UARTCharPut(UART0_BASE, ch);
        return ch;
    }

    int fputs(const char *_ptr, register FILE *_fp)
    {
      unsigned int i, len;

      len = strlen(_ptr);

      for(i=0 ; i<len ; i++)
          ROM_UARTCharPut(UART0_BASE, (uint8_t) _ptr[i]);

      return len;
    }

u8 area;
int main(void)
{
	Drv_BspInit();
	
	static u8 last_area = 0;
	
	while(1)
	{
		if(knn.flag)
		{
			if(knn.data[0] < 1000 && knn.data[1] < 1000 && knn.data[2] < 1000
				&& knn.data[0] > 10 && knn.data[1] > 10 && knn.data[2] > 10)
			{
				area = knn_judge();
				
				if(last_area != area && area == 5 && area == 8)
				{
					u8 data = 0;
					Drv_Uart3SendBuf(&data,1);
				}
				last_area = area;
				
//				printf("%d,%d,%d\r\n",knn.data[0],knn.data[1],knn.data[2]);
				
//				Drv_Uart2SendBuf(data,2);
			openmv_datatemp[0] = 0xAA;
			openmv_datatemp[1] = area;
			
			Drv_Uart2SendBuf(openmv_datatemp,8);
				printf("%d\r\n",area);
			}
			knn.flag = 0;
		}
		
	}
}
