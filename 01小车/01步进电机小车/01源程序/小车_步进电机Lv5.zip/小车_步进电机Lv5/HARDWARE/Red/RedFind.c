#include "stm32f10x.h"
#include "sys.h"
#include "RedFind.h"
#include "delay.h"

void Red_Init(void)
{
		GPIO_InitTypeDef GPIO_InitStructure;

		RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA , ENABLE);
		GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1 | GPIO_Pin_2 | GPIO_Pin_3;
		GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
		GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
		GPIO_Init(GPIOA , &GPIO_InitStructure);
		GPIO_SetBits(GPIOA,GPIO_Pin_0|GPIO_Pin_1);			
}

void SearchRun(void)
{
	if(RightRed==0&&LeftRed==0)
	{
			Go_Straight();
	}
	else if(RightRed==1&&LeftRed==0)
	{
		while(RightRed==1&&LeftRed==0)
			Direct2_Turn_Right();
	}
	else if(RightRed==1&&LeftRed==1)
	{
			Go_Back();
	}
	if(RightRed==0&&LeftRed==1)
	{
		while(RightRed==0&&LeftRed==1)
			Direct2_Turn_Left();
	}
}

//void SearchRun(void)
//{
//	if(RightRed==0&&LeftRed==0)
//	{
//			Go_Straight();
//	}
//	else if(RightRed==1&&LeftRed==0)
//	{
//			Direct_Turn_Right();delay_ms(600);
//			Go_Straight();delay_ms(300);
//	}
//	else if(RightRed==1&&LeftRed==1)
//	{
//			Go_Back();
//	}
//	if(RightRed==0&&LeftRed==1)
//	{
//			Direct_Turn_Left();delay_ms(600);
//			Go_Straight();delay_ms(300);
//		}
//	}

	//void SearchRun(void)
//{
//	if(RightRed==0&&LeftRed==0)
//	{
//			Go_Straight();
//	}
//	else if(RightRed==1&&LeftRed==0)
//	{
//			Turn_Right();
//	}
//	else if(RightRed==1&&LeftRed==1)
//	{
//			Go_Back();
//	}
//	if(RightRed==0&&LeftRed==1)
//	{
//			Turn_Left();
//	}
//}

