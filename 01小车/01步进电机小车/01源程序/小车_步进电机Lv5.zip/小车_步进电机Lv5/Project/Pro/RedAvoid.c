#include "sys.h"	 
#include "stm32f10x.h"
#include "RedAvoid.h"
#include "RedFind.h"


void Red_AvoidRun()
{
	if(Distance<60)
	{
		Stop_Move();
		switch(Red_Direction_Judge())
		{
			case -1:Avoid_Turn_Left();break;
			case 0:Avoid_Direction_Reverse();break;
			case 1:Avoid_Turn_Right();break;
			default:Stop_Move();break;
		}
	}
	else 
	{
		if(Right_Avoid==0&&Left_Avoid==0)
			Go_Straight();
		else if(Right_Avoid==0&&Left_Avoid==1)
			Avoid_Mode2_Turn_Left();
		else if(Right_Avoid==1&&Left_Avoid==1)
			Go_Straight();
		else if(Right_Avoid==1&&Left_Avoid==0)
			Avoid_Mode2_Turn_Right();
	}
}

int Red_Direction_Judge()
{
	if(Right_Avoid==0&&Left_Avoid==0)
		return 2;
	else if(Right_Avoid==0&&Left_Avoid==1)
		return -1;
	else if(Right_Avoid==1&&Left_Avoid==1)
		return 0;
	else if(Right_Avoid==1&&Left_Avoid==0)
		return 1;
	else return 2;
}

