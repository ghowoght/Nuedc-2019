#include "sys.h"
#include "stm32f10x.h"
#include "control.h"
#include "motor.h"


void SteeringEngine_Init(void);
int Wave_Direction_Judge(void);
void Wave_AvoidRun(void);

