#include "sys.h"	 
#include "stm32f10x.h"
#include "control.h"

#define Right_Avoid PAin(2)
#define Left_Avoid PAin(3)

#define Avoid_Go_Straight() 				Motor_Control(1500,0)
#define Avoid_Go_Back() 						Motor_Control(-1500,0)
#define Avoid_Turn_Right() 					Motor_Control(1500,-1500)

#define Avoid_Turn_Left() 					Motor_Control(1500,1500)
#define Avoid_Mode2_Turn_Right() 		Motor_Control(1000,-300)
#define Avoid_Mode2_Turn_Left() 		Motor_Control(1000,300)
#define Avoid_Stop_Move() 					Motor_Control(0,0)
#define Avoid_Direction_Reverse() 	Motor_Control(0,1500);

void Red_AvoidRun(void);
int Red_Direction_Judge(void);
