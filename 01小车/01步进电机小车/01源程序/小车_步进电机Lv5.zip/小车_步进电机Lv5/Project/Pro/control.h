#ifndef __CONTROL_H
#define __CONTROL_H
#include "sys.h"
  
#define PI 3.14159265
#define FILTERING_TIMES  10
extern	int Balance_Pwm,Velocity_Pwm,Turn_Pwm;
int EXTI15_10_IRQHandler(void);
void Set_Pwm(int moto1,int moto2);
void Key(void);
void Xianfu_Pwm(void);
u8 Turn_Off(float angle, int voltage);
void Get_Angle(u8 way);
int myabs(int a);
void speed_filter(void);
int Mean_Filter(int moto1,int moto2);
u16  Linear_Conversion(int moto);
void  Get_Zhongzhi(void);
void  Find_CCD_Zhongzhi(void);
void Get_RC(void);
void Motor_Control(float velocity,float turn);
#endif
