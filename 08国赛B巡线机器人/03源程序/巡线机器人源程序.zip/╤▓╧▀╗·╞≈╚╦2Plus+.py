import sensor, image, time, utime, array, math, json, machine, os
import lcd
from pyb import UART,LED

THRESHOLD_1 = [(49,100,40,127,-61,127)]
THRESHOLD_2 =[(30, 0, -128, 127, -128, 127)]
THRESHOLD_3 = [(0,100)]
line_threshold = [(0, 25, -20, 20, -20, 20)]
up_roi   = [0,   0, 80, 15]#上采样区0
down_roi = [0,  55, 80, 15]#下采样区0
left_roi = [0,   0, 25, 60]#左采样区0
righ_roi = [55, 0,  25, 40]#右采样区0
utime.sleep_ms(1000)
LED(1).off()
LED(2).off()
LED(3).off()
sensor.reset()
sensor.set_pixformat(sensor.RGB565)

sensor.set_framesize(sensor.QVGA) #320*240
sensor.skip_frames(time = 2000)
sensor.set_auto_gain(False)
sensor.set_auto_whitebal(False)
sensor.set_brightness(-1)

lcd.init()

clock = time.clock()
uart = UART(3, 500000)
uart.init(500000, bits=8, parity=None, stop=1)

filename = '/01.txt'
f=open(filename,'r')
s = f.read()
thre = [int(i)for i in s.split(',')]
f.close()
thre_1 = [(thre[0],thre[1],thre[2],thre[3],thre[4],thre[5])]



class flag(object):
    work_mode = 1 #工作模式.默认是点检测，可以通过串口设置成其他模式
    state = 0
    shot_ok = 0
    enabled = 0

class para():
    cmd = 0
    index = 0

class Blob(object):
    ok = 0
    flag = 0
    x = 0
    y = 0
    pixels = 0
    num = 0

flag = flag()
Blob = Blob()
para = para()

colors = [(255,0,0),(255,0,0),(255,0,0),(255,0,0),(255,0,0),(255,0,0)]

#读取串口缓存
def uart_read_buf():
    if uart.any():
        para.cmd=uart.readchar()
        if para.cmd == 0:
            flag.work_mode = 3
        elif para.cmd == 1:
            para.index = (para.index + 1)% 6
        elif para.cmd == 2:
            thre[para.index] = thre[para.index] + 5
        elif para.cmd == 3:
            thre[para.index] = thre[para.index] - 5
        elif para.cmd == 4:
            flag.work_mode = 1
            f=open(filename,'w')
            f.write(str(thre[0])+','+str(thre[1])+','+str(thre[2])+','+str(thre[3])+','+str(thre[4])+','+str(thre[5]))
            f.close()
        elif para.cmd == 5:
            flag.enabled = 1  #开启openmv

        elif para.cmd == 6:
            flag.state = 1    #找黄色异物

        thre_1 = [(thre[0],thre[1],thre[2],thre[3],thre[4],thre[5])]


def uart_send_dot(x,y,state):   #转换发送格式 y在前x在后
    x0 = str(x %10)
    x1 = str((x %100)//10)
    x2 = str((x %1000)//100)
    x3 = str(x //1000)
    y0 = str(y %10)
    y1 = str((y %100)//10)
    y2 = str((y %1000)//100)
    y3 = str((y //1000))

    if(flag.enabled):
        uart.write('A'+str(state)+'0'+x3+x2+x1+x0+y3+y2+y1+y0)

#点检测函数
def check_blob(img):
    blobs = img.find_blobs(thre_1, merge=True, margin =5, pixels_threshold=200, area_threshold=200)
    if blobs:
        largest_blob = max(blobs, key=lambda b: b.pixels())
        if is_debug:
            img.draw_rectangle(largest_blob.rect())
            img.draw_cross(largest_blob.cx(), largest_blob.cy())
            img.draw_keypoints([(largest_blob.cx(), largest_blob.cy(), int(math.degrees(largest_blob.rotation())))], size=20)

        Blob.x = int(largest_blob.cx() * 10)
        Blob.y = int(largest_blob.cy() * 10)
        uart_send_dot(Blob.x,Blob.y,flag.state)
        print(Blob.x,Blob.y,largest_blob.area())
        flag.is_bar = 1
    else:
        uart_send_dot(9990,9990,5)
        print(9990,flag.state)





#杆检测函数
ROIS = {
    'down': (0, 200, 320, 40), # 横向取样-下方 1
    'middle': (0, 100, 320, 40), # 横向取样-中间 2
    'up': (0, 0, 320, 40), # 横向取样-上方 3
}

BLOB_MAX_WIDTH = 80 # 色块的最大宽度
BLOB_MIN_WIDTH = 12 # 色块的最小宽度
BLOB_MAX_HEIGHT = 40 # 色块的最大高度
BLOB_MIN_HEIGHT = 30 # 色块的最小宽度

IMG_WIDTH = 320

is_debug = False

def check_stick(img):
    global ROIS

    roi_blobs_result = {}  # 在各个ROI中寻找色块的结果记录
    for roi_direct in ROIS.keys():
        roi_blobs_result[roi_direct] = {
            'cx': -1,
            'cy': -1,
            'blob_flag': False
        }
    for roi_direct, roi in ROIS.items():
        blobs=img.find_blobs(line_threshold, roi=roi, merge=True, pixels_area=200)
        if len(blobs) == 0:
            continue

        largest_blob = max(blobs, key=lambda b: b.pixels())
        x,y,width,height = largest_blob[:4]

        if not(width >= BLOB_MIN_WIDTH and width <= BLOB_MAX_WIDTH and height >= BLOB_MIN_HEIGHT and height <= BLOB_MAX_HEIGHT):
            # 根据色块的宽度进行过滤
            continue

        roi_blobs_result[roi_direct]['cx'] = largest_blob.cx()
        roi_blobs_result[roi_direct]['cy'] = largest_blob.cy()
        roi_blobs_result[roi_direct]['blob_flag'] = True

        if is_debug:
            img.draw_rectangle((x,y,width, height), color=(255))
    rho = 0
    count = 0
    for roi_direct in ['up', 'down', 'middle']:
        if roi_blobs_result[roi_direct]['blob_flag']:
            rho += roi_blobs_result[roi_direct]['cx']
            count += 1
        else:
            rho += IMG_WIDTH / 2
    rho /= 3
    if count>=2:
        if(flag.state == 0):
            uart_send_dot(int(rho * 10),9990,flag.state)
        else:
            uart_send_dot(int(rho * 10),9990,5)
        print(rho)
        flag.is_stick = 1
    else:
        uart_send_dot(9990,9990,5)
        print(9990,flag.state)

def set_param(img):
    img.binary(thre_1)

    for i in range(0,6):
        if i == para.index:
            colors[i] = (0,255,0)
        else:
            colors[i] = (255,0,0)

    img.draw_string(80 + 20, 60 + 0,  'L', scale = 1,color = (255,0,0))
    img.draw_string(80 + 20, 60 + 10, 'A', scale = 1,color = (255,0,0))
    img.draw_string(80 + 20, 60 + 20, 'B', scale = 1,color = (255,0,0))

    img.draw_string(80 + 35, 60 + 0,  str(thre[0]), scale = 1,color=colors[0])
    img.draw_string(80 + 35, 60 + 10, str(thre[2]), scale = 1,color=colors[2])
    img.draw_string(80 + 35, 60 + 20, str(thre[4]), scale = 1,color=colors[4])
    img.draw_string(80 + 65, 60 + 0,  str(thre[1]), scale = 1,color=colors[1])
    img.draw_string(80 + 65, 60 + 10, str(thre[3]), scale = 1,color=colors[3])
    img.draw_string(80 + 65, 60 + 20, str(thre[5]), scale = 1,color=colors[5])

    lcd.display(img) # Take a picture and display the image.

flag.state = 1
flag.enabled = 0
cnt = 0
while(True):
    clock.tick()


    if(flag.work_mode != 3):
        if(flag.state == 0):#找第一根杆
            flag.work_mode = 1

        if(flag.state == 1):#找黄色异物
            if(cnt == 0):
                flag.work_mode = 1
            else:
                flag.work_mode = 2

        if(flag.state == 2):#找黄色异物
            flag.work_mode = 1

    if(flag.work_mode == 1):
        img = sensor.snapshot()
        check_stick(img)

    cnt = cnt + 1
    if(cnt == 5):
        cnt = 0

    elif(flag.work_mode == 2):
        img = sensor.snapshot()
        check_blob(img)

    elif(flag.work_mode == 3):
        img = sensor.snapshot()
        set_param(img)

    print(flag.enabled)

    uart_read_buf()

