#include "LocCtrl.h"
//#include "Drv_Gps.h"
#include "Imu.h"
#include "FlightCtrl.h"
#include "OF.h"
#include "Parameter.h"
#include "UWB.h"

#include "Drv_laser.h"
#include "Ano_OF_DecoFusion.h"
#include "Drv_UP_Flow.h"

//λ���ٶȻ����Ʋ���
_PID_arg_st loc_arg_1[2] ; 

//λ���ٶȻ���������
_PID_val_st loc_val_1[2] ; 

//λ���ٶȻ��������Ʋ���
_PID_arg_st loc_arg_1_fix[2] ; 

//λ���ٶȻ�������������
_PID_val_st loc_val_1_fix[2] ; 

static u8 mode_f[2];

/*λ���ٶȻ�PID������ʼ��*/
void Loc_1level_PID_Init()
{
	//GPS
	if(mode_f[1] == 2)
	{
		//normal
		loc_arg_1[X].kp = Ano_Parame.set.pid_gps_loc_1level[KP];//0.22f  ;
		loc_arg_1[X].ki = 0  ;
		loc_arg_1[X].kd_ex = 0.00f ;
		loc_arg_1[X].kd_fb = Ano_Parame.set.pid_gps_loc_1level[KD];
		loc_arg_1[X].k_ff = 0.02f;
		
		loc_arg_1[Y] = loc_arg_1[X];
		//fix	
		loc_arg_1_fix[X].kp = 0.0f  ;
		loc_arg_1_fix[X].ki = Ano_Parame.set.pid_gps_loc_1level[KI] ;
		loc_arg_1_fix[X].kd_ex = 0.00f;
		loc_arg_1_fix[X].kd_fb = 0.00f;
		loc_arg_1_fix[X].k_ff = 0.0f;
		
		loc_arg_1_fix[Y] = loc_arg_1_fix[X];	
	}
	//OF
	else if(mode_f[1] == 1)
	{
		//normal
		loc_arg_1[X].kp = Ano_Parame.set.pid_loc_1level[KP];//0.22f  ;
		loc_arg_1[X].ki = 0.0f  ;
		loc_arg_1[X].kd_ex = 0.00f ;
		loc_arg_1[X].kd_fb = Ano_Parame.set.pid_loc_1level[KD];
		loc_arg_1[X].k_ff = 0.02f;
		
		loc_arg_1[Y] = loc_arg_1[X];
		//fix	
		loc_arg_1_fix[X].kp = 0.0f  ;
		loc_arg_1_fix[X].ki = Ano_Parame.set.pid_loc_1level[KI] ;
		loc_arg_1_fix[X].kd_ex = 0.00f;
		loc_arg_1_fix[X].kd_fb = 0.00f;
		loc_arg_1_fix[X].k_ff = 0.0f;
		
		loc_arg_1_fix[Y] = loc_arg_1_fix[X];	
	}
	//UWB ��UWB AND OF
	else if(mode_f[1] == 3 || mode_f[1] == 4)
	{
		//normal
		loc_arg_1[X].kp = Ano_Parame.set.pid_loc_1level[KP];//0.22f  ;
		loc_arg_1[X].ki = 0.0f  ;
		loc_arg_1[X].kd_ex = 0.00f ;
		loc_arg_1[X].kd_fb = Ano_Parame.set.pid_loc_1level[KD];
		loc_arg_1[X].k_ff = 0.02f;
		
		loc_arg_1[Y] = loc_arg_1[X];
		//fix	
		loc_arg_1_fix[X].kp = 0.0f  ;
		loc_arg_1_fix[X].ki = Ano_Parame.set.pid_loc_1level[KI] ;
		loc_arg_1_fix[X].kd_ex = 0.00f;
		loc_arg_1_fix[X].kd_fb = 0.00f;
		loc_arg_1_fix[X].k_ff = 0.0f;
		
		loc_arg_1_fix[Y] = loc_arg_1_fix[X];			
	}
	//
	else
	{
		//null	
	}
	

}

/*���˻�λ���ں�������λ���ڻ�����*/
void Loc_Cal_Task(u8 dT_ms)
{	
	uv_loc.x += loc_ctrl_1.fb[X] * dT_ms * 1e-3;
	uv_loc.y += loc_ctrl_1.fb[Y] * dT_ms * 1e-3;
	
}

_loc_ctrl_st loc_ctrl_1;
static float fb_speed_fix[2];

float vel_fb_d_lpf[2];
float vel_fb_h[2],vel_fb_w[2];
float vel_fb_fix_w[2];
/*λ���ٶȻ�*/
void Loc_1level_Ctrl(u16 dT_ms,s16 *CH_N)
{
	static float loc_hand_exp_vel[2]={0};
	static unsigned short waite_gps_loc_cnt = 0;
	float ne_pos_control[2];
	unsigned char vel_diff = 5;
	float pos_ctrl_h_out[2];
	float pos_ctrl_w_out[2];

	//���й���
	if(switchs.of_flow_on && (!switchs.gps_on))
	{
		mode_f[1] = 1;
		if(mode_f[1] != mode_f[0])
		{
			Loc_1level_PID_Init();
			mode_f[0] = mode_f[1];
		}
		////
		loc_ctrl_1.exp[X] = fs.speed_set_h[X];
		loc_ctrl_1.exp[Y] = fs.speed_set_h[Y];
		//
		LPF_1_(5.0f,dT_ms*1e-3f,imu_data.h_acc[X],vel_fb_d_lpf[X]);
		LPF_1_(5.0f,dT_ms*1e-3f,imu_data.h_acc[Y],vel_fb_d_lpf[Y]);		

		/***********************/
		if(sens_hd_check.of_ok)  //��������
		{
			loc_ctrl_1.fb[X] = OF_DX2 + 0.03f *vel_fb_d_lpf[X];
			loc_ctrl_1.fb[Y] = OF_DY2 + 0.03f *vel_fb_d_lpf[Y];
			
			fb_speed_fix[0] = OF_DX2FIX;
			fb_speed_fix[1] = OF_DY2FIX;
		}
		else//sens_hd_check.of_df_ok  //�������
		{
			loc_ctrl_1.fb[X] = of_rdf.gnd_vel_est_h[X] + 0.03f *vel_fb_d_lpf[X];
			loc_ctrl_1.fb[Y] = of_rdf.gnd_vel_est_h[Y] + 0.03f *vel_fb_d_lpf[Y];
			
			fb_speed_fix[0] = of_rdf.gnd_vel_est_h[X];
			fb_speed_fix[1] = of_rdf.gnd_vel_est_h[Y];		
		}
		/***********************/
		
		for(u8 i =0;i<2;i++)
		{
			PID_calculate( dT_ms*1e-3f,            //���ڣ���λ���룩
										loc_ctrl_1.exp[i] ,				//ǰ��ֵ
										loc_ctrl_1.exp[i] ,				//����ֵ���趨ֵ��
										loc_ctrl_1.fb[i] ,			//����ֵ����
										&loc_arg_1[i], //PID�����ṹ��
										&loc_val_1[i],	//PID���ݽṹ��
										50,//��������޷�
										10 *flag.taking_off			//integration limit�������޷�
										 )	;	
			
			//fix
			PID_calculate( dT_ms*1e-3f,            //���ڣ���λ���룩
										loc_ctrl_1.exp[i] ,				//ǰ��ֵ
										loc_ctrl_1.exp[i] ,				//����ֵ���趨ֵ��
										fb_speed_fix[i] ,			//����ֵ����
										&loc_arg_1_fix[i], //PID�����ṹ��
										&loc_val_1_fix[i],	//PID���ݽṹ��
										50,//��������޷�
										10 *flag.taking_off			//integration limit�������޷�
										 )	;	
			
			loc_ctrl_1.out[i] = loc_val_1[i].out + loc_val_1_fix[i].out;	//(PD)+(I)	
		}		


	}
	//��̬ģʽ��ֱ���������ٶ�תΪ�Ƕȣ������Ƕȣ�
	else
	{
		mode_f[1] = 255;
		if(mode_f[1] != mode_f[0])
		{
			Loc_1level_PID_Init();
			mode_f[0] = mode_f[1];
		}
		////
		loc_ctrl_1.out[X] = (float)MAX_ANGLE/MAX_SPEED *fs.speed_set_h[X] ;
		loc_ctrl_1.out[Y] = (float)MAX_ANGLE/MAX_SPEED *fs.speed_set_h[Y] ;
	}
}

/*******************************λ���⻷*********************************/
/*λ�û�PID������ʼ��*/
void Loc_2level_PID_Init()
{
	loc_arg_2[X].kp = Ano_Parame.set.pid_loc_2level[KP];
	loc_arg_2[X].ki = Ano_Parame.set.pid_loc_2level[KI] ;
	loc_arg_2[X].kd_ex = Ano_Parame.set.pid_loc_2level[KD] ;
	loc_arg_2[X].kd_fb =Ano_Parame.set.pid_loc_2level[KD];
	loc_arg_2[X].k_ff = 0;
	
	loc_arg_2[Y].kp = Ano_Parame.set.pid_track_yaw_level[KP];
	loc_arg_2[Y].ki = Ano_Parame.set.pid_track_yaw_level[KI] ;
	loc_arg_2[Y].kd_ex = Ano_Parame.set.pid_track_yaw_level[KD] ;
	loc_arg_2[Y].kd_fb =Ano_Parame.set.pid_track_yaw_level[KD];
	loc_arg_2[Y].k_ff = 0;
}

_loc_ctrl_st loc_ctrl_2;
_vector2_st origin_point={0,0};

//λ�û����Ʋ���
_PID_arg_st loc_arg_2[2] ; 

//λ�û���������
_PID_val_st loc_val_2[2] ; 

int pos_exp[2];
int vel_exp[2];
#define MAX_VEL 100
#define MOVE_KP 0.5
//enum
//{
//    NB,
//    ZO,
//    PB,
//};
//enum
//{
//    P = 2,
//    I,
//    D,
//};
///*�����*/		     /*  E  EC  Kp  Ki  Kd */
//u8 rule_table[9][5]={{NB, NB, ZO, ZO, PB},
//										 {NB, ZO, ZO, ZO, ZO},
//										 {NB, PB, ZO, ZO, NB},
//													 
//										 {ZO, NB, PB, ZO, PB},
//										 {ZO, ZO, PB, ZO, ZO},
//										 {ZO, PB, PB, ZO, PB},
//														
//										 {PB, NB, ZO, ZO, NB},
//										 {PB, ZO, ZO, ZO, ZO},
//										 {PB, PB, ZO, ZO, PB}};
///*ģ��PID��������*/
//_PID_arg_st loc_arg_fuzzy[2];
//float E[2];
//float EC[2];
///*����ģ���Ӽ�*/
//float fuzzy_tab_e [7] = { -160, 0, 160 };   		//E ģ���Ӽ�
////float fuzzy_tab_ec[7] = { -320, 0, 320 };     	//ECģ���Ӽ�
//float fuzzy_tab_ec[7] = { -10, 0, 10 };     	//ECģ���Ӽ�
//float fuzzy_tab_kp[7] = { 0.9, 1.0, 1.1 };  //Kpģ���Ӽ�
//float fuzzy_tab_ki[7] = { 0.9, 1.0, 1.1 };  //Kiģ���Ӽ�
//float fuzzy_tab_kd[7] = { 0.9, 1.0, 1.1 };   //Kdģ���Ӽ�	

void Loc_2level_Ctrl(u16 dT_ms)
{
	pos_exp[X]=origin_point.x;
	pos_exp[Y]=origin_point.y;
	
	//��������ƶ��ٶ�
	s16 max_move_vel = MAX_VEL;
	
	//���������ƶ��ٶ�
	vel_exp[X] = MOVE_KP *(pos_exp[X] - target_point.x);
	vel_exp[X] = LIMIT(vel_exp[X],0,max_move_vel);
	
	vel_exp[Y] = MOVE_KP *(pos_exp[Y] - target_point.y);
	vel_exp[Y] = LIMIT(vel_exp[Y],0,max_move_vel);

	//PID��������
	if(pos_exp[X] - loc_ctrl_2.exp[X] <2)
	{
		vel_exp[X]=0;
	}
	if(pos_exp[Y] - loc_ctrl_2.exp[Y] <2)
	{
		vel_exp[Y]=0;
	}
	loc_ctrl_2.exp[X]+=vel_exp[X]*dT_ms;
	loc_ctrl_2.exp[X] = LIMIT(loc_ctrl_2.exp[X],loc_ctrl_2.fb[X]-200,loc_ctrl_2.fb[X]+200);

	loc_ctrl_2.exp[Y]+=vel_exp[Y]*dT_ms;
	loc_ctrl_2.exp[Y] = LIMIT(loc_ctrl_2.exp[X],loc_ctrl_2.fb[Y]-200,loc_ctrl_2.fb[Y]+200);
	
	loc_ctrl_2.fb[X] = target_point.x;
	loc_ctrl_2.fb[Y] = target_point.y;
	
//	for (int i = 0; i < 2; i++)
//	{
////			float e[] = {-150, -120, -100, -75, -30, -20, 0, 20, 35, 80, 100, 120, 150};	
////			float ec[] = {-9, -6, -3, -1, 0, 1, 3, 6, 9};	

//			/*ģ��PID*/
//			float ms_e[2];   //E������
//			float ms_ec[2];  //EC������
//			
//			u8 index[2];
//		
//			/*ģ����*/
//			E[i]  = loc_ctrl_2.exp[i] - loc_ctrl_2.fb[i];
//			EC[i] = E[i] - (loc_val_2[i].exp_old - loc_val_2[i].feedback_old);
//			E[i]  = LIMIT(E[i], fuzzy_tab_e[NB], fuzzy_tab_e[PB]);
//			EC[i] = LIMIT(EC[i], fuzzy_tab_ec[NB], fuzzy_tab_ec[PB]);

////			static u8 n=0,m=0;	
////			E[i] = e[n++];
////			EC[i] =ec[m++];
////			n%=13;
////			m%=9;
//			
//			/*���������Ȳ��ж�����*/
//			index[0] = CalcMembership(fuzzy_tab_e , E [i], ms_e );
//			index[1] = CalcMembership(fuzzy_tab_ec, EC[i], ms_ec);

//			/*��ѯ�����*/
//			float Fp = fuzzy_tab_kp[rule_table[3 * index[0] + index[1]][P]] * ms_e[0] * ms_ec[0]
//							 + fuzzy_tab_kp[rule_table[3 * (index[0] + 1) + index[1]][P]] * ms_e[1] * ms_ec[0]
//							 + fuzzy_tab_kp[rule_table[3 * index[0] + index[1] + 1][P]] * ms_e[0] * ms_ec[1]
//							 + fuzzy_tab_kp[rule_table[3 * (index[0] + 1) + index[1] + 1][P]] * ms_e[1] * ms_ec[1];

////			float Fi = fuzzy_tab_ki[rule_table[3 * index[0] + index[1]][I]] * ms_e[0] * ms_ec[0]
////							 + fuzzy_tab_ki[rule_table[3 * (index[0] + 1) + index[1]][I]] * ms_e[1] * ms_ec[0]
////							 + fuzzy_tab_ki[rule_table[3 * index[0] + index[1] + 1][I]] * ms_e[0] * ms_ec[1]
////							 + fuzzy_tab_ki[rule_table[3 * (index[0] + 1) + index[1] + 1][I]] * ms_e[1] * ms_ec[1];

//			float Fd = fuzzy_tab_kd[rule_table[3 * index[0] + index[1]][D]] * ms_e[0] * ms_ec[0]
//							 + fuzzy_tab_kd[rule_table[3 * (index[0] + 1) + index[1]][D]] * ms_e[1] * ms_ec[0]
//							 + fuzzy_tab_kd[rule_table[3 * index[0] + index[1] + 1][D]] * ms_e[0] * ms_ec[1]
//							 + fuzzy_tab_kd[rule_table[3 * (index[0] + 1) + index[1] + 1][D]] * ms_e[1] * ms_ec[1];
//			/*��ģ��*/
//			loc_arg_fuzzy[i].kp = loc_arg_2[i].kp * Fp;
////			loc_arg_fuzzy[i].ki = loc_arg_2[i].ki * Fi;
//			loc_arg_fuzzy[i].kd_ex = loc_arg_2[i].kd_ex * Fd;
//			loc_arg_fuzzy[i].kd_fb = loc_arg_2[i].kd_fb * Fd;
//			
////			UARTprintf("%d %d %d %d\r\n",(int)e[n-1],(int)ec[m-1],(int)(Fp*100),(int)(Fd*100));

//	}
	
	/*����PID*/	
	PID_calculate( dT_ms*1e-3f,            //���ڣ���λ���룩
									0,				//ǰ��ֵ
									loc_ctrl_2.exp[X],				//����ֵ���趨ֵ��
									loc_ctrl_2.fb[X],			//����ֵ����
									&loc_arg_2[X], //PID�����ṹ��
									&loc_val_2[X],	//PID���ݽṹ��
									50,//��������޷�
									10			//integration limit�������޷�									
									);
	PID_calculate( dT_ms*1e-3f,            //���ڣ���λ���룩
									0,				//ǰ��ֵ
									loc_ctrl_2.exp[Y],				//����ֵ���趨ֵ��
									loc_ctrl_2.fb[Y],			//����ֵ����
									&loc_arg_2[Y], //PID�����ṹ��
									&loc_val_2[Y],	//PID���ݽṹ��
									50,//��������޷�
									10			//integration limit�������޷�									
									);
	loc_val_2[X].out  = LIMIT(loc_val_2[X].out,-200,200);
	loc_val_2[Y].out  = LIMIT(loc_val_2[Y].out,-200,200);
	
}

///*���������Ⱥ���*/
//u8 CalcMembership(float area[], float value, float ms[])
//{
//    uint8_t index = 0;
//    uint8_t i = 0;
//    for (i = 0; i < PB; i++)
//    {
//        if ((value >= area[i]) && (value < area[i + 1]))
//        {
//            float k1 = 1 / (area[i] - area[i + 1]);
//            ms[0] = k1 * value - k1 * area[i + 1];

//            float k2 = 1 / (area[i + 1] - area[i]);
//            ms[1] = k2 * value - k2 * area[i];

//            index = i;
//        }
//    }
//    return index;
//}

