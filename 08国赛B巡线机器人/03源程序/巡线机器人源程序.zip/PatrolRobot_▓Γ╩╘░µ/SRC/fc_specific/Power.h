#ifndef _FC_POWER_H_
#define _FC_POWER_H_

#include "Drv_adc.h"

extern float Plane_Votage;

void Power_UpdateTask(u8 dT_ms);

#endif

