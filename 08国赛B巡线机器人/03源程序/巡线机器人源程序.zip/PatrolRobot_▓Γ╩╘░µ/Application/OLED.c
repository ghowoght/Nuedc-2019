#include "oled.h"

#include "Drv_oled.h"

#include "Sensor_Basic.h"
#include "Parameter.h"
#include "IMU.h"
#include "icm20602.h"
#include "MotorCtrl.h"
#include "Power.h"
#include "FlightCtrl.h"

#include "MotionCal.h"
#include "FlightDataCal.h"

#include "LocCtrl.h"
#include "FlyCtrl.h"

#include "Drv_openmv.h"
#include "FcData.h"

#include "UWB.h"

#include "Drv_laser.h"
#include "Ano_OF_DecoFusion.h"
#include "Drv_UP_Flow.h"

void OLED_Task(uint32_t dT_ms)
{
	static u8 task = 0;
	if(task != flag.task)
	{
		if(flag.task == 4)
		{
			OLED_Clear();
			
		}
		else
		{
			OLED_Clear();
			OLED_ShowString(0,0,"Voltage:");
			OLED_ShowString(0,1,"Yaw    :");
			OLED_ShowString(0,2,"Task   :");
			OLED_ShowString(0,3,"Alt    :");
			OLED_ShowString(0,4,"Dist   :");
			OLED_ShowString(0,5,"Target :");
		}
		task = flag.task;
	}
  
	if(flag.task == 4)
	{
		OLED_ShowNum(10, 0, parameter.param[0],5,15);
		OLED_ShowNum(60, 0, parameter.param[1],5,15);
		OLED_ShowNum(10, 1, parameter.param[2],5,15);
		OLED_ShowNum(60, 1, parameter.param[3],5,15);
		OLED_ShowNum(10, 2, parameter.param[4],5,15);
		OLED_ShowNum(60, 2, parameter.param[5],5,15);
		OLED_ShowNum(10, 3, parameter.param[6],5,15);
		OLED_ShowNum(60, 3, parameter.param[7],5,15);
		
		OLED_ShowNum(60, 5, parameter.index + 1,5,15);
		

	}
	
	else
	{
		if(flag.auto_take_off_land == AUTO_TAKE_OFF_NULL)  //ֻ����û���ʱ��ˢ����Ļ
		{
			/*����ˢ��*/
			static int cnt = 0;
			cnt = (cnt+1)%6;
			switch(cnt)
			{
				//Plane_Votage,wcz_hei_fus.out,ref_tof_height,imu_data.yaw,flag.task,openmv_point[1].x,uv_loc.x
				case 0: OLED_ShowFloat(60, 0, Plane_Votage,			 15);break;  //��ѹ
				case 1: OLED_ShowFloat(60, 1, imu_data.yaw,			 15);break;	 //ƫ��
				case 2: OLED_ShowFloat(60, 2, flag.task,  15);break;  //����
//				case 2: OLED_ShowFloat(60, 2, flag.target_loss,  15);break;
				case 3: OLED_ShowFloat(60, 3, wcz_hei_fus.out,	 15);break;  //�ںϸ߶�
	//			case 4: OLED_ShowFloat(60, 4, ref_tof_height,		 15);break;  //����߶�
				case 4: OLED_ShowFloat(60, 4, distance,		 15);break;  //����߶�
				case 5: OLED_ShowFloat(60, 5, real_point.x, 15);break;
				default:break;		
			}
		}
	}
}

