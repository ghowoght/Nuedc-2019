#ifndef _DRV_OPENMV_H_
#define _DRV_OPENMV_H_

#include "sysconfig.h"

#define N1 8

/************************Ѱ�����***************************/
extern u16 openmv_X_coordinate;
extern u16 openmv_Y_coordinate;
extern u8 color_code_name;
extern float True_X_coordinate_len;
extern float True_Y_coordinate_len;


void OPENMV_GetOneByte(uint8_t data);
void OPENMV_DataAnl(uint8_t *data_buf);

void OPMV_Data_Cal_Task(float fix_heigh,u8 dT_ms);

void OPMV_Param_Set(u8 cmd);
void OPMV_Shot(void);

void Close_OPMV_1(void);
void Open_OPMV_2(void);
	
#endif
