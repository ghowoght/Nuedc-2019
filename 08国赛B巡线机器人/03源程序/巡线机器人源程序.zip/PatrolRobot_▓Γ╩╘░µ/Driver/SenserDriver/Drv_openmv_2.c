#include "Drv_openmv_2.h"
#include "FcData.h"
#include "Math.h"
#include "math.h"
#include "Imu.h"
#include "Drv_Uart.h"
#include "Drv_slave.h"

u8 openmv2_datatemp[20];  //���յ������ݻ���

_vector2_st last_point2;

/*
 *openmv���ڽ��ս�����ʽ
 *
 *					1		  |		  2	  	|	  	3		  |	  	4		  ~			7		  |			 8		  ~	  	11	  	|	
 *				 
 *(Ѱ��) 	֡ͷ		  	ģʽ��	 		��ɫ����		  				X								   		  	Y 							
 *
 *(Ѳ��) 	֡ͷ				ģʽ				�ո�			 				 rho							  			theta 	 				 	
 *
 */

void OPENMV2_GetOneByte(uint8_t data)
{
	static u8 state = 0;
	
	if(state == 0 && data == 'A')						//֡ͷ	
	{
		state = 1;
		openmv2_datatemp[0] = data;
	}
	else if(state == 1)											//ģʽ
	{
		state = 2;
		openmv2_datatemp[1] = data - 48;
	}
	else if(state == 2 )											
	{
		state = 3;
		openmv2_datatemp[2] = data - 48;
	}
	
/*��һ������*/
	else if(state == 3)			
	{
		state = 4;
		openmv2_datatemp[3] = data - 48;
	}
	else if(state == 4)			
	{
		state = 5;
		openmv2_datatemp[4] = data - 48;
	}
	else if(state == 5)			
	{
		state = 6;
		openmv2_datatemp[5] = data - 48;
	}
	else if(state == 6)			
	{
		state = 7;
		openmv2_datatemp[6] = data - 48;
	}
	
/*�ڶ�������*/
	else if(state == 7)			
	{
		state = 8;
		openmv2_datatemp[7] = data - 48;
	}
	else if(state == 8)			
	{
		state = 9;
		openmv2_datatemp[8] = data - 48;
	}
	else if(state == 9)			
	{
		state = 10;
		openmv2_datatemp[9] = data - 48;
	}
	else if(state == 10)			
	{
		state = 0;
		openmv2_datatemp[10] = data - 48;
		OPENMV2_DataAnl(openmv2_datatemp);
	}
	else
		state = 0;
}


void OPENMV2_DataAnl(uint8_t *data_buf)
{
	u8 openmv_mode = openmv2_datatemp[1];  //ģʽ
	
	if(openmv_mode == FIND_YELLOW)
	{
		LED_ON();
	}
	else if(openmv_mode == FIND_A)
	{
		flag.ctrl_mode = FIND_A;
		
		LED_OFF();
	}
	else
	{
		LED_OFF();
	}
		
	openmv_point[0].x = openmv2_datatemp[3] * 1000 + openmv2_datatemp[4] * 100 
								 + openmv2_datatemp[5] * 10   + openmv2_datatemp[6];
	openmv_point[0].y = openmv2_datatemp[7] * 1000 + openmv2_datatemp[8] * 100 
								 + openmv2_datatemp[9] * 10   + openmv2_datatemp[10];
	
	openmv_point[0].x /= 10.0;							 
	openmv_point[0].y /= 10.0;
	
	if(openmv_point[0].x == 999 && openmv_point[0].y == 999)  //δ��⵽Ŀ��
	{
		flag.openmv_loss = 1;
		
		openmv_point[1].x = last_point2.x;							 
		openmv_point[1].y = last_point2.y;
	}
	else
	{			
		flag.openmv_loss = 0;
		
		openmv_point[1].x = openmv_point[0].x - 160;							 
		openmv_point[1].y = openmv_point[0].y - 120;
	}
}

