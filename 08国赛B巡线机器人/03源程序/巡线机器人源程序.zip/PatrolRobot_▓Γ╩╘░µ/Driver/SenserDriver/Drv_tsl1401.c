#include "Drv_tsl1401.h"
#include "FcData.h"
#include "Math.h"
#include "Imu.h"

_vector2_st tsl1401={0,0};

u8 tsl_datatemp[50];
u8 mode[2]={0};

void TSL_GetOneByte(uint8_t data)
{
	static u8 state = 0;
	
	if(state == 0 && data == 0xAA)						//֡ͷ	
	{
		state = 1;
		tsl_datatemp[0] = data;
	}
	else if(state == 1 && data == 0xAA)												//ģʽ
	{
		state = 2;
		tsl_datatemp[1] = data;
	}
	else if(state == 2 )											
	{
		state = 3;
		tsl_datatemp[2] = data;
	}
	else if(state == 3)			
	{
		state = 4;
		tsl_datatemp[3] = data;
	}
	else if(state == 4)			
	{
		state = 0;
		tsl_datatemp[4] = data;
		TSL_DataAnl(tsl_datatemp);
	}
	else
		state = 0;
}


void TSL_DataAnl(uint8_t *data_buf)
{
	mode[0]=tsl_datatemp[2];
	if(mode[0]!=mode[1])
	{
		flag.ctrl_mode==mode[0];
		mode[1]=mode[0];
	}
	tsl1401.x=(int)tsl_datatemp[3];
	tsl1401.y=(int)tsl_datatemp[4];
}
