#ifndef _DRV_TSL1401_H_
#define _DRV_TSL1401_H_

#include "sysconfig.h"
#include "FcData.h"

#define N1 8
/************************Ѱ�����***************************/
extern _vector2_st tsl1401;


void TSL_GetOneByte(uint8_t data);
void TSL_DataAnl(uint8_t *data_buf);

#endif
