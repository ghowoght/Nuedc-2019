#include "Drv_slave.h"
#include "FcData.h"

#include "Drv_openmv.h"
#include "FlightCtrl.h"
#include "Drv_Uart.h"

int distance = 0;

parameter_st parameter;

u8 Drv_Slave_Init(void)
{
	return 1;
}

/*
1			2						3
0xAA	openmvģʽ	����
*/

u8 slave_datatemp[20];
void Slave_GetOneByte(u8 data)
{
	static u8 state = 0;
	
	if(state == 0 && data == 0xAA)						//֡ͷ	
	{
		slave_datatemp[state] = data;
		state ++;
	}
	else if(state == 1)											
	{
		slave_datatemp[state] = data;
		state ++;
	}
	else if(state == 2 )								
	{
		slave_datatemp[state] = data;
		state ++;
	}
	else if(state == 3 )								
	{
		slave_datatemp[state] = data;
		state ++;
	}
	else if(state == 4 )								
	{
		slave_datatemp[state] = data;
		state ++;
	}
	else if(state == 5 )								
	{
		slave_datatemp[state] = data;
		state ++;
	}
	else
	{
		state = 0;
	}
	
	if(state == 6)
	{
		Slave_DataAnl();
		state = 0;
	}
	
}

void Slave_DataAnl(void)
{	
	static u8 last_mode = 0;
	if(slave_datatemp[1] != last_mode)
	{
		if(slave_datatemp[1] == 1)
		{
			OPMV_Param_Set(slave_datatemp[2]);//ʹopenmv������ֵ�޸�ģʽ
		}
		last_mode = slave_datatemp[1];
	}
	
	if(slave_datatemp[1] == 1) //openmv��ֵ����ģʽ
	{
		if(slave_datatemp[2] != 0)
		{
			OPMV_Param_Set(slave_datatemp[2]);  // ʹ�ô���3����
		}
	}
	else  //���˻�ģʽ�л�
	{
		if(slave_datatemp[2] == 1)
		{
			flag.task = (flag.task + 1) % 5;
		}
		if(flag.task == 4)  //�����ǲ����޸�ģʽ
		{
			if(slave_datatemp[2] == 2)
			{
				parameter.index = (parameter.index + 1)% 8;
			}
			else if(slave_datatemp[2] == 3)
			{
				if(parameter.index == SHOT_TIME)
				{
					parameter.param[parameter.index] +=1000;
				}
				else if(parameter.index <= HOVER_TIME)  //ʱ��ֵ ��λ��ms
				{
					parameter.param[parameter.index] += 100;				
				}
				else  //�ٶ�ֵ  ��λ��cm/s
				{
					parameter.param[parameter.index] += 2;	
				}
			}
			else if(slave_datatemp[2] == 4)
			{
				if(parameter.index == SHOT_TIME)
				{
					parameter.param[parameter.index] -=1000;
				}
				else if(parameter.index <= HOVER_TIME)  //ʱ��ֵ ��λ��ms
				{
					parameter.param[parameter.index] -= 100;				
				}
				else  //�ٶ�ֵ  ��λ��cm/s
				{
					parameter.param[parameter.index] -= 2;	
				}
			}
		}
		if(slave_datatemp[3] == 1)
		{
			one_key_take_off();
		}
	}
	
	static int last_dis = 0;
	
	if((int)((slave_datatemp[4] << 8) + slave_datatemp[5])<1000 && (int)((slave_datatemp[4] << 8) + slave_datatemp[5])>100)
	{
		distance = (u16)((slave_datatemp[4] << 8) + slave_datatemp[5]) / 10.0 * 0.2 + last_dis * 0.8;
		last_dis = distance;
		flag.ultra_ok = 1;
	}
	else
	{
		flag.ultra_ok = 0;
		distance = last_dis;
	}
}

void LED_ON(void)
{
	u8 cmd = 0x01;
	Drv_Uart2SendBuf(&cmd,1);
}

void LED_OFF(void)
{
	u8 cmd = 0x00;
	Drv_Uart2SendBuf(&cmd,1);
}

void Param_Init(void)
{
	parameter.param[FORWARD_TIME] = 3000;
	parameter.param[LEFT_TIME] = 1500;
	parameter.param[HOVER_TIME] = 2000;	
	
	parameter.param[MOVE_VEL] = 15;
	parameter.param[FORWARD_VEL] = 15;
	parameter.param[BACK_VEL] = 30;
	parameter.param[DISTANCE] = 40;
	
	parameter.param[SHOT_TIME] = 5000;
	
	
	
	
}
