#ifndef _DRV_LED_H_
#define _DRV_LED_H_

#include "sysconfig.h"

void Dvr_LedInit(void);
void Drv_LedOnOff(u8 led, u8 onoff);

#endif
