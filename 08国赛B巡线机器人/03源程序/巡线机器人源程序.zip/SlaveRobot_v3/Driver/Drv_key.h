#include "sysconfig.h"

void Drv_KeyInit(void);

void Key_Task(u32 dT_ms);
