#ifndef _DRV_SKZ5_H_
#define _DRV_SKZ5_H_

#include "sysconfig.h"

#define N2 8


void TOF_GetOneByte(uint8_t data);
void TOF_DataAnl(uint8_t *data_buf);
void Get_TOF_Height(void);
extern float	Laser_height_mm;

#endif
