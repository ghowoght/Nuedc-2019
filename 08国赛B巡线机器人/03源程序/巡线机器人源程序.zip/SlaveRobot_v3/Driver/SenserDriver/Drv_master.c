#include "Drv_master.h"
#include "FcData.h"

#include "Drv_openmv.h"
#include "Drv_Uart.h"

u8 Drv_Master_Init(void)
{
	return 1;
}

/*
1			2						3
0xAA	openmvģʽ	����
*/

u8 Master_datatemp[20];
void Master_GetOneByte(u8 data)
{
	if(data == 0x00)
	{
		ROM_GPIOPinWrite(GPIOD_BASE, GPIO_PIN_0, 0);
	}
	if(data == 0x01)
	{
		ROM_GPIOPinWrite(GPIOD_BASE, GPIO_PIN_0, GPIO_PIN_0);
	}
	if(data == 0x02)
	{
		flag.ultra_switch = 2;
	}
	
//	static u8 state = 0;
	
//	if(state == 0 && data == 0xAA)						//֡ͷ	
//	{
//		Master_datatemp[state] = data;
//		state ++;
//	}
//	else if(state == 1)											
//	{
//		Master_datatemp[state] = data;
//		state ++;
//	}
//	else if(state == 2 )								
//	{
//		Master_datatemp[state] = data;
//		state ++;
//	}
//	else if(state == 3 )								
//	{
//		Master_datatemp[state] = data;
//		state ++;
//	}
//	else
//	{
//		state = 0;
//	}
//	
//	if(state == 2)
//	{
//		Master_DataAnl();
//		state = 0;
//	}
	
}

void Master_DataAnl(void)
{
//	OPMV_Param_Set(Master_datatemp[1]);  // ʹ�ô���3����
}

/////////////////////////////////////////////////////////////////////////////////////
//���ݲ�ֺ궨�壬�ڷ��ʹ���1�ֽڵ���������ʱ������int16��float�ȣ���Ҫ�����ݲ�ֳɵ����ֽڽ��з���
#define BYTE0(dwTemp)       ( *( (char *)(&dwTemp)		) )
#define BYTE1(dwTemp)       ( *( (char *)(&dwTemp) + 1) )
#define BYTE2(dwTemp)       ( *( (char *)(&dwTemp) + 2) )
#define BYTE3(dwTemp)       ( *( (char *)(&dwTemp) + 3) )

#define TAOF_DELAY_TIME 5000   //���������ʱ

u8 data_to_send[20];
void Data_Ex_Task(u8 dT_ms)
{
	if(flag.data_send == 1)
	{
		static int taof_cnt = 0;
		u8 _cnt = 0;
		data_to_send[_cnt++] = 0xAA;
		
		if(flag.mode == OPMV_MODE_SET)
		{
			data_to_send[_cnt++] =OPMV_MODE_SET;
			data_to_send[_cnt++] = flag.opmv_para_set;
			
		}
		else if(flag.mode == UAV_MODE_SET)
		{
			data_to_send[_cnt++] = UAV_MODE_SET;
			data_to_send[_cnt++] = flag.uav_task;
			
		}
		
		if(flag.one_key_take_off == 1)
		{
			if(taof_cnt <= TAOF_DELAY_TIME) 
			{
				taof_cnt += dT_ms;
				data_to_send[_cnt++] = 0;
			}
			else		//��ʱ��5�����
			{
				data_to_send[_cnt++] = 1;
				flag.one_key_take_off = 0;
			}
		}
		else
		{
			taof_cnt = 0;
			data_to_send[_cnt++] = 0;
		}
		flag.opmv_para_set = 0;
		
		flag.uav_task = 0;
		data_to_send[_cnt++]=distance[0];
		data_to_send[_cnt++]=distance[1];
		Drv_Uart2SendBuf(data_to_send, _cnt);
		
		if(taof_cnt == 0)
		{
			flag.data_send = 0;
		}
	}
}
