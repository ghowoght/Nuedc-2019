#ifndef _MASTER_H_
#define _MASTER_H_
#include "sysconfig.h"

u8 		Drv_Master_Init(void);
void 	Master_GetOneByte(u8 data);
void 	Master_DataAnl(void);

void Data_Ex_Task(u8 dT_ms);

#endif
