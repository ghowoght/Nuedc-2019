#ifndef _DRV_OPENMV_H_
#define _DRV_OPENMV_H_

#include "sysconfig.h"

void OPENMV_GetOneByte(uint8_t data);
void OPENMV_DataAnl(uint8_t *data_buf);

void OPMV_Param_Set(u8 cmd);

#endif
