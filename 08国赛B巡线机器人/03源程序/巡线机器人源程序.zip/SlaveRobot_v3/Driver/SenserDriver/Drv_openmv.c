#include "Drv_openmv.h"
#include "FcData.h"
#include "Math.h"
#include "math.h"
#include "Drv_Uart.h"


u8 openmv_datatemp[20];  //���յ������ݻ���

/*
 *openmv���ڽ��ս�����ʽ
 *
 *					1		  |		  2	  	|	  	3		  |	  	4		  ~			7		  |			 8		  ~	  	11	  	|	
 *				 
 *(Ѱ��) 	֡ͷ		  	ģʽ��	 		��ɫ����		  				X								   		  	Y 							
 *
 *(Ѳ��) 	֡ͷ				ģʽ				�ո�			 				 rho							  			theta 	 				 	
 *
 */

void OPENMV_GetOneByte(uint8_t data)
{
	static u8 state = 0;
	
	if(state == 0 && data == 'A')						//֡ͷ	
	{
		state = 1;
		openmv_datatemp[0] = data;
		
	}
	else if(state == 1)												//ģʽ
	{
		state = 2;
		openmv_datatemp[1] = data - 48;
	}
	else if(state == 2 )											
	{
		state = 3;
		openmv_datatemp[2] = data;
	}
	
/*��һ������*/
	else if(state == 3)			
	{
		state = 4;
		openmv_datatemp[3] = data - 48;
	}
	else if(state == 4)			
	{
		state = 5;
		openmv_datatemp[4] = data - 48;
	}
	else if(state == 5)			
	{
		state = 6;
		openmv_datatemp[5] = data - 48;
	}
	else if(state == 6)			
	{
		state = 7;
		openmv_datatemp[6] = data - 48;
	}
	
/*�ڶ�������*/
	else if(state == 7)			
	{
		state = 8;
		openmv_datatemp[7] = data - 48;
	}
	else if(state == 8)			
	{
		state = 9;
		openmv_datatemp[8] = data - 48;
	}
	else if(state == 9)			
	{
		state = 10;
		openmv_datatemp[9] = data - 48;
	}
	else if(state == 10)			
	{
		state = 0;
		openmv_datatemp[10] = data - 48;
		
		OPENMV_DataAnl(openmv_datatemp);
	}
	else
		state = 0;
}


void OPENMV_DataAnl(uint8_t *data_buf)
{
	flag.mode = openmv_datatemp[1];  //ģʽ
}

/*openmv��ֵ����*/
void OPMV_Param_Set(u8 cmd)
{
	Drv_Uart3SendBuf(&cmd,1);
}

