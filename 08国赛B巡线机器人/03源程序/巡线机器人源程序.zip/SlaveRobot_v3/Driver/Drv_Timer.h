#include "timer.h"
#include "hw_ints.h"
#include "sysconfig.h"


void Time0_A_Init(void);


