#include "FcData.h"
#include "Parameter.h"

_flag flag;

u8 distance[2] = {0};