/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __ANO_FCDATA_H
#define __ANO_FCDATA_H
/* Includes ------------------------------------------------------------------*/
#include "config.h"
/* Exported types ------------------------------------------------------------*/
#define TRUE 1
#define FALSE 0 

enum
{
	X = 0,
	Y = 1,
	Z = 2,
	VEC_XYZ,
};

enum
{
	ROL = 0,
	PIT = 1,
	YAW = 2,
	VEC_RPY,
};

enum
{
	KP = 0,
	KI = 1,
	KD = 2,
	PID,
};


enum _openmv__mode
{
	TRACK = 1,  //ѭ��
	FOLLOW, 	//����
};

enum opmv_para_set
{
	SWITCH = 1,
	ADD,
	SUBTRACT,
	OK,
};

enum 
{
	UAV_MODE_SET,
	OPMV_MODE_SET,
};

typedef struct
{
	u8 mode;
	u8 openmv_ok;
	u8 target_loss;
	u8 key_enable;
	u8 opmv_para_set;
	u8 one_key_take_off;
	u8 uav_task;
	
	u8 data_send;
	u8 ultra_data_ok;
	u8 data_send_enable;
	u8 ultra_switch;
}_flag;
extern _flag flag;

typedef struct
{
	int x;
	int y;
}_vector2_st;

typedef struct
{
	int x;
	int y;
	int z;
}_vector3_st;

typedef struct
{
	float rho;
	float theta;
}_line_st;

extern u8 distance[2];

/* Exported constants --------------------------------------------------------*/
/* Exported macro ------------------------------------------------------------*/
/* Exported functions ------------------------------------------------------- */


#endif

