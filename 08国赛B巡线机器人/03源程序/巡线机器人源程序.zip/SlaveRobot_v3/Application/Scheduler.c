/******************** (C) COPYRIGHT 2019 ANO Tech ********************************
 * 作者    ：匿名科创
 * 官网    ：www.anotc.com
 * 淘宝    ：anotc.taobao.com
 * 技术Q群 ：190169595
 * 描述    ：任务调度
**********************************************************************************/
#include "Scheduler.h"
#include "Drv_Bsp.h"
#include "LED.h"
#include "Drv_led.h"
#include "Drv_key.h"
#include "Drv_master.h"
#include "Drv_Uart.h"
#include "FcData.h"

#define CIRCLE_NUM 20
//static u8 lt0_run_flag;
//static u8 circle_cnt[2];
void INT_1ms_Task()
{	
//	//标记1ms执行
//	lt0_run_flag ++;
//	//灯光驱动
//	LED_1ms_DRV();

//	//循环计数
//	circle_cnt[0] ++;
//	//20次循环
//	circle_cnt[0] %= CIRCLE_NUM;
//	//
//	if(!circle_cnt[0])
//	{
//		//
//		
//	}
}


static void Loop_Task_0(u32 dT_us)//1ms执行一次
{
	LED_1ms_DRV();
}

static void Loop_Task_1(u32 dT_us)	//2ms执行一次
{
	Key_Task(2);
}

static void Loop_Task_2(u32 dT_us)	//6ms执行一次
{

}


static void Loop_Task_5(u32 dT_us)	//11ms执行一次
{	
	LED_Task2(11);
}



static void Loop_Task_8(u32 dT_us)	//20ms执行一次
{
	u8 data = 0x55;
	Drv_Uart1SendBuf(&data,1);
	Drv_Uart5SendBuf(&data,1);
	flag.ultra_data_ok = 0;
//	UARTprintf("%d %d\r\n",(int)((distance[0]<<8)+distance[1]),flag.ultra_switch);
	Data_Ex_Task(20);
//	ROM_GPIOPinWrite(GPIOD_BASE, GPIO_PIN_0, GPIO_PIN_0);
}


static void Loop_Task_9(u32 dT_us)	//50ms执行一次
{

}

//////////////////////////
//调度器程序
//////////////////////////

//系统任务配置，创建不同执行频率的“线程”
static sched_task_t sched_tasks[] = 
{
	//任务n,    周期us,   上次时间us
	{Loop_Task_0 ,  1000,  0 },
	{Loop_Task_1 ,  2000,  0 },
	{Loop_Task_2 ,  6000,  0 },
//	{Loop_Task_2 ,  2500,  0 },
//	{Loop_Task_3 ,  2500,  0 },
//	{Loop_Task_4 ,  2500,  0 },
	{Loop_Task_5 ,  11000,  0 },
//	{Loop_Task_6 ,  9090,  0 },
//	{Loop_Task_7 ,  9090,  0 },
	{Loop_Task_8 , 20000,  0 },
	{Loop_Task_9 , 50000,  0 },
//	{Loop_Task_10,100000,  0 },
};

//根据数组长度，判断线程数量
#define TASK_NUM (sizeof(sched_tasks)/sizeof(sched_task_t))

u8 Main_Task(void)
{
	uint8_t index = 0;
	
	//循环判断其他所有线程任务，是否应该执行
	uint32_t time_now,delta_time_us;
	for(index=0;index < TASK_NUM;index++)
	{
		//获取系统当前时间，单位US
		 time_now = GetSysRunTimeUs();//SysTick_GetTick();
		//进行判断，如果当前时间减去上一次执行的时间，大于等于该线程的执行周期，则执行线程
		if(time_now - sched_tasks[index].last_run >= sched_tasks[index].interval_ticks)
		{
			delta_time_us = (u32)(time_now - sched_tasks[index].last_run);

			//更新线程的执行时间，用于下一次判断
			sched_tasks[index].last_run = time_now;
			//执行线程函数，使用的是函数指针
			sched_tasks[index].task_func(delta_time_us);

		}	 
	}
	
	return 0;
}

/******************* (C) COPYRIGHT 2019 ANO TECH *****END OF FILE************/
	

