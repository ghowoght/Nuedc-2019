#include "LED.h"
#include "MATH.h"
#include "Drv_led.h"


u16 led_accuracy = 20;//��ʱ��Ӧ��LED_Duty()����������ͬ
float LED_Brightness[4] = {0,20,0,0}; //TO 20 //XBRG


//LED��1ms��������1ms��ʱ�ж�����á�
void LED_1ms_DRV( ) //0~20
{
	static u16 led_cnt[4];
	u8 i;
	for(i=0;i<4;i++)
	{
			
		if( led_cnt[i] < LED_Brightness[i] )
		{
			switch(i)
			{
				case 2:	
					Drv_LedOnOff(LED_R, 1);//LED1_ON;
				break;
				case 3:	
					Drv_LedOnOff(LED_G, 1);//LED2_ON;
				break;
				case 1:	
					Drv_LedOnOff(LED_B, 1);//LED3_ON;
				break;
				case 0:	
					Drv_LedOnOff(LED_S, 1);//LED4_ON;
				break;
			}
		}
		else
		{
			switch(i)
			{
				case 2:	
					Drv_LedOnOff(LED_R, 0);//LED1_OFF;
				break;
				case 3:	
					Drv_LedOnOff(LED_G, 0);//LED2_OFF;
				break;
				case 1:	
					Drv_LedOnOff(LED_B, 0);//LED3_OFF;
				break;
				case 0:	
					Drv_LedOnOff(LED_S, 0);//LED4_OFF;
				break;
			}
		}
		
		if(++led_cnt[i]>=led_accuracy)
		{
			led_cnt[i] = 0;
		}
	}
	

}

static void ledOnOff(u8 led)
{
	for(u8 i=0; i<LED_NUM; i++)
	{
		if(led & (1<<i))
			LED_Brightness[i] = 20;
		else
			LED_Brightness[i] = 0;
	}
}
void ledBreath(u8 dT_ms,u8 led,u16 T)
{
	static u8 dir[LED_NUM];
	
	for(u8 i=0; i<LED_NUM; i++)
	{
		if(led & (1<<i))
		{
			switch(dir[i])
			{
				case 0:
					LED_Brightness[i] += safe_div(led_accuracy,((float)T/(dT_ms)),0);
					if(LED_Brightness[i]>20)
					{
						dir[i] = 1;
					}
				
				break;
				case 1:
					LED_Brightness[i] -= safe_div(led_accuracy,((float)T/(dT_ms)),0);
					if(LED_Brightness[i]<0)
					{
						dir[i] = 0;
					}
					
				break;
					
				default:
					dir[i] = 0;
				break;
			}
		}
		else
			LED_Brightness[i] = 0;
	}
}
//					��������   LED     ��ʱ��    ��ʱ��
void ledFlash(u8 dT_ms,u8 led, u16 on_ms,u16 off_ms)
{
	static u16 tim_tmp;
	
	if(tim_tmp < on_ms)
		ledOnOff(led);
	else
		ledOnOff(0);
	
	tim_tmp += dT_ms;
	if(tim_tmp >= (on_ms + off_ms))
		tim_tmp = 0;
}

_led_sta LED_STA;
#include "FcData.h"
void LED_Task2(u8 dT_ms)
{
	static u16 timtmp = 0;
	static u8  statmp = 0;
	static u8  modtmp = 0;
		
	u8 times = 2;
	if(statmp == 0)
	{
		if(modtmp < times)
		{
			if(timtmp < 60)
			{
				if(flag.mode)
				{
					ledOnOff(BIT_RLED);
				}
				else
				{
					ledOnOff(BIT_GLED);
				}
			}
			else
				ledOnOff(0);
			timtmp += dT_ms;
			
			if(timtmp > 200)
			{
				timtmp = 0;
				modtmp++;
			}
		}
		else
		{
			modtmp = 0;
			statmp = 1;
		}
	}
	else		//ÿһ��ѭ���󣬼�һ����Ƴ���ʱ
	{
		ledOnOff(0);
		timtmp += dT_ms;
		if(timtmp > 1000)
		{
			timtmp = 0;
			statmp = 0;
			modtmp = 0;
		}
	}
	
}


