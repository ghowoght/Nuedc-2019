#include "sysconfig.h"
#include "Drv_Bsp.h"
#include "Scheduler.h"

#include "Drv_led.h"

int main(void)
{
	Drv_BspInit();

	while(1)
	{
		Main_Task();
	}
}
