#ifndef __OLED_H
#define __OLED_H

#include "sysconfig.h"

void OLED_Task(uint32_t dT_ms);

	

#endif