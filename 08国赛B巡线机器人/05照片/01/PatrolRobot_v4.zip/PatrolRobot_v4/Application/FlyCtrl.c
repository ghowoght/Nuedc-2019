#include "FlyCtrl.h"
#include "Ano_DT.h"
#include "Drv_openmv.h"
#include "FcData.h"
#include "MotionCal.h"
#include "ProgramCtrl_User.h"

_fly_ct_st fly_ctrl;

vel_set_st vel_set;


//巡线结构体
_line_st fb_line;
_line_st exp_line = {0,0};

#include "FlightCtrl.h"
#include "IMU.h"
#include "LocCtrl.h"
#include "Parameter.h"
#include "Drv_openmv.h"
#include "Drv_openmv_2.h"
#include "Drv_Uart.h"

#include "UWB.h"
#include "Drv_slave.h"

void FlyCtrlDataAnl(u8 *data)
{

	fly_ctrl.cmd_state[0] = *(data+2);
	
	if(fly_ctrl.cmd_state[0] == 0x01)
	{
		one_key_take_off();
	}
	
	else if(fly_ctrl.cmd_state[0] == 0x02)
	{
		one_key_land();
	}
	
	else if(fly_ctrl.cmd_state[0] == 0xA0)
	{
		flag.unlock_cmd = 0;
	}
	
}


_vector2_st target_point;

_vector2_st uv_loc;


enum FSM
{
	S0,
	S1,
	S2,
	S3,
	S4,
	S5,
	S6,
	S7,
	S8,
	S9,
	S10,
	S11,
	S12,
	S13,
	S14,
	S15,
	S16,
	S17,
};


#define MOTIONLESS_THRESHOLD  10		 //静止检测阈值
#define HOVER_TIME 				    3000  //悬停时间 单位：ms
#define SHOT_TIME							12000	//拍照时间

u8  state = S0;
void FlyCtrl_Task(u8 dT_ms)  //周期：20ms
{	
	OPMV_Data_Cal_Task(wcz_hei_fus.out,dT_ms);
	Loc_Cal_Task(dT_ms);
	
	static int state_cnt;
	
	if(flag.flying == 1 && flag.auto_take_off_land == AUTO_TAKE_OFF_FINISH) 
	{		
			if(state == S0)
			{
				state_cnt += dT_ms;
				if(state_cnt >= 5000)  
				{
//					one_key_land();
//					state_cnt = 0;
					state = S1;
					state_cnt = 0;
				}
				vel_set.h_cmps[X] = 0;
				vel_set.h_cmps[Y] = 0;
				vel_set.yaw_dps = 0;
			}
			else if(state == S1) //前进
			{				
				vel_set.h_cmps[X] = FORWARD_VEL;				
				vel_set.h_cmps[Y] = 0;
				if(flag.target_loss == 0)
				{
					state = S2;
				}
			}
			else if(state == S2) //对准杆，并校正距离
			{
				target_point.x = -real_point.x;
				/*位置控制*/
				Loc_2level_Ctrl(dT_ms);
				
				vel_set.h_cmps[X] = loc_val_2[X].out;
				
				if(my_abs(target_point.x) <= 10 )///&& (flag.ultra_ok == 1 || (distance >= (EXP_DISTANCE - 5) && distance <= (EXP_DISTANCE + 5))))   //静止检测
				{
					Track_Roll_Ctrl(dT_ms);
					if(distance >= (EXP_DISTANCE - 5) && distance <= (EXP_DISTANCE + 10))
					{
						if(state_cnt <= 1000)
						{
							state_cnt += dT_ms;
						}
						else
						{
//							one_key_land();
//							state = S0;
							u8 cmd = 6;  //检测黄色异物
							Drv_Uart3SendBuf(&cmd,1);
							state = S3;
							state_cnt = 0;
						}
					}
					else
					{
						state_cnt = 0;
					}
					vel_set.h_cmps[Y] = val_rol.out;
				}
				else
				{
					vel_set.h_cmps[Y] = 0;
					state_cnt = 0;
				}						
			}
			else if(state == S3) //继续前进，检测到黄色异物，进入下一状态
			{
				vel_set.h_cmps[X] = FORWARD_VEL;
				vel_set.h_cmps[Y] = 0;
				state_cnt += dT_ms;
				if(flag.openmv_sta == FIND_YELLOW)
				{
					LED_ON();
					state = S5;  /* 直接跳到S5*/
				}
				else if(state_cnt >= 10000)
				{
					state = S7;
					state_cnt = 0;
					u8 cmd = 7;  //检测第二根杆
					Drv_Uart3SendBuf(&cmd,1);
				}
			}
			else if(state == S4) //对准黄色异物
			{
				target_point.x = -real_point.x;
				/*位置控制*/
				Loc_2level_Ctrl(dT_ms);
				
				vel_set.h_cmps[X] = loc_val_2[X].out;
				if(my_abs(target_point.x) <= 10)   //静止检测
				{
					if(state_cnt <= 2000)
					{
						state_cnt += dT_ms;
					}
					else
					{
						state = S5;
						state_cnt = 0;
					}
				}
				else
				{
					state_cnt = 0;
				}				
			}
			else if(state == S5) //靠近黄色异物,当进入拍照范围内开始拍照
			{
				
				if(state_cnt >= 500)
				{
					vel_set.h_cmps[Y] = 0;
					OPMV_Shot();
					state = S6;
					state_cnt = 0;
				}
				else 
				{
//					vel_set.h_cmps[Y] = 5;
					state_cnt += dT_ms;
				}
			}
			else if(state == S6) //等待拍照完毕
			{
				
				if(state_cnt <= SHOT_TIME)
				{
					state_cnt += dT_ms;
					vel_set.h_cmps[X] = 0;
					vel_set.h_cmps[Y] = 0;
				}
				else 
				{
					LED_OFF();
					u8 cmd = 7;  //检测第二根杆
					Drv_Uart3SendBuf(&cmd,1);
					state_cnt = 0;
					state = S7;
				}
			}
			else if(state == S7) //拍照完毕，继续前进
			{
				vel_set.h_cmps[X] = FORWARD_VEL;
				vel_set.h_cmps[Y] = 0;
				if(flag.openmv_sta == FIND_QR)
				{
					state = S8;
				}
			}
			else if(state == S8) //对正二维码，校正距离
			{
				target_point.x = -real_point.x;
				/*位置控制*/
				Loc_2level_Ctrl(dT_ms);
				
				vel_set.h_cmps[X] = loc_val_2[X].out;
				
				if(my_abs(target_point.x) <= 10 && flag.ultra_ok == 1)   //静止检测
				{
					Track_Roll_Ctrl(dT_ms);
					if(distance >= (EXP_DISTANCE - 5) && distance <= (EXP_DISTANCE + 5))
					{
						if(state_cnt <= 1000)
						{
							state_cnt += dT_ms;
						}
						else
						{
							OPMV_Shot();
							state = S9;
							state_cnt = 0;
						}
					}
					else
					{
						state_cnt = 0;
					}
					vel_set.h_cmps[Y] = val_rol.out;
				}
				else
				{
					vel_set.h_cmps[Y] = 0;
					state_cnt = 0;
				}						
			}
			else if(state == S9) //等待拍照完毕
			{
				
				if(state_cnt <= SHOT_TIME)
				{
					
					state_cnt += dT_ms;
					vel_set.h_cmps[X] = 0;
					vel_set.h_cmps[Y] = 0;
				}
				else 
				{
					one_key_land();
					state = S0;
//					state_cnt = 0;
//					state = S9;
				}
			}
			
			else if(state == S9)
			{
				vel_set.h_cmps[X] = FORWARD_VEL;
				vel_set.h_cmps[Y] = 0;
				if(state_cnt <= _50_CM_TIME)
				{
					state_cnt += dT_ms;
				}
				else
				{
					state = S10;
					state_cnt = 0;
				}
			}
			else if(state == S10)
			{
				vel_set.h_cmps[X] = 0;
				vel_set.h_cmps[Y] = FORWARD_VEL;
				if(state_cnt <= _100_CM_TIME)
				{
					state_cnt += dT_ms;
				}
				else
				{
					state = S11;
					state_cnt = 0;
				}
			}
			else if(state == S11)
			{
				vel_set.h_cmps[X] = -FORWARD_VEL;
				vel_set.h_cmps[Y] = 0;
				if(state_cnt <= _100_CM_TIME)
				{
					state_cnt += dT_ms;
				}
				else
				{
					state = S12;
					state_cnt = 0;
				}
			}
	}
	else 
	{
		FlyCtrlReset();
		state = S0;
	}		
		
	if(flag.unlock_sta !=0)
	{
		Set_HXYcmps(vel_set.h_cmps[X],vel_set.h_cmps[Y]);		
		Set_YAWdps(vel_set.yaw_dps);
		
	}
	else
	{
			FlyCtrlReset();
	}
}

void FlyCtrlReset()
{
	vel_set.h_cmps[X] = vel_set.h_cmps[Y] = vel_set.h_cmps[Z] = 0;
	vel_set.yaw_dps = 0;
	
	Set_HXYcmps(0,0);		
	Set_YAWdps(0);

}

/************************循迹控制**********************/

//循迹偏航控制参数
_PID_arg_st arg_yaw ; 

//循迹偏航控制参数
_PID_arg_st arg_rol ;

//循迹俯仰控制数据
_PID_val_st val_yaw;

//循迹俯仰控制数据
_PID_val_st val_rol;

void Track_Yaw_PID_Init(void)
{
	arg_yaw.kp = Ano_Parame.set.pid_track_yaw_level[KP];
	arg_yaw.ki = Ano_Parame.set.pid_track_yaw_level[KI];
	arg_yaw.kd_ex = Ano_Parame.set.pid_track_yaw_level[KD];
	arg_yaw.kd_fb =Ano_Parame.set.pid_track_yaw_level[KD];
	arg_yaw.k_ff = 0;
}

void Track_Roll_PID_Init(void)
{
	arg_rol.kp = Ano_Parame.set.pid_track_rol_level[KP];
	arg_rol.ki = Ano_Parame.set.pid_track_rol_level[KI];
	arg_rol.kd_ex = Ano_Parame.set.pid_track_rol_level[KD];
	arg_rol.kd_fb =Ano_Parame.set.pid_track_rol_level[KD];
	arg_rol.k_ff = 0;
}
/*
 *循迹偏航角控制
 *输入 ：直线倾斜角
 *输出 ：期望偏航角速度
 */
void Track_Yaw_Ctrl(float dT_ms)
{
	fb_line.theta = line.theta;
	
	PID_calculate( dT_ms*1e-3f,            //周期（单位：秒）
										0,				//前馈值
										exp_line.theta,				//期望值（设定值）
										fb_line.theta,			//反馈值（）
										&arg_yaw, //PID参数结构体
										&val_yaw,	//PID数据结构体
										5,//积分误差限幅
										50			//integration limit，积分限幅									
										 );
	val_yaw.out = LIMIT(val_yaw.out, - 100, 100);
}	

/*
 *循迹横滚角控制
 *输入 ：与直线的距离
 *输出 ：期望水平Y方向速度
 */
void Track_Roll_Ctrl(float dT_ms)
{
	fb_line.rho = distance;
	
	exp_line.rho = EXP_DISTANCE;

	PID_calculate( dT_ms*1e-3f,            //周期（单位：秒）
									0,				//前馈值
									exp_line.rho,				//期望值（设定值）
									fb_line.rho,			//反馈值（）
									&arg_rol, //PID参数结构体
									&val_rol,	//PID数据结构体
									5,//积分误差限幅
									50			//integration limit，积分限幅									
									 );
	val_rol.out = -LIMIT(val_rol.out, - 100, 100);
}

