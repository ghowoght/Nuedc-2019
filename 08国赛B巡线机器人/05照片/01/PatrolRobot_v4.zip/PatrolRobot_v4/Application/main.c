#include "sysconfig.h"
#include "Drv_Bsp.h"
#include "Scheduler.h"
#include "FcData.h"
#include "Drv_Uart.h"

int main(void)
{
	
	Drv_BspInit();
	
	flag.start_ok = 1;

	while(1)
	{
		//��ѯ���������
		Main_Task();
	}
}
