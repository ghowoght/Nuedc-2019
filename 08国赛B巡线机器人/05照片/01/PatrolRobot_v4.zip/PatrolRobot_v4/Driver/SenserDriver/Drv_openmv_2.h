#ifndef _DRV_OPENMV2_H_
#define _DRV_OPENMV2_H_

#include "sysconfig.h"

#define N1 8

void OPENMV2_GetOneByte(uint8_t data);
void OPENMV2_DataAnl(uint8_t *data_buf);

void OPMV2_Data_Cal_Task(float fix_heigh,u8 dT_ms);
	
#endif
