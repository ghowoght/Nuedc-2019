#include "Drv_openmv.h"
#include "FcData.h"
#include "Math.h"
#include "math.h"
#include "Imu.h"
#include "Drv_Uart.h"

#define MV_Pixel_X	240.0f * 2.4f//(��������)
#define MV_Pixel_Y	320.0f * 2.4f
#define Shot_field_angle_X	90.0f 
#define Shot_field_angle_Y	115.0f 
#define	P_P2A_X	 MV_Pixel_X / Shot_field_angle_X
#define	P_P2A_Y	 MV_Pixel_Y / Shot_field_angle_Y

#define PC_P2L  0.01f

#define NUM  2
typedef struct
{
 float Position[NUM];//λ�ù�����
 float Speed[NUM];//�ٶȹ�����
 float Acceleration[NUM];//���ٶȹ�����
 float Pos_History[NUM];//��ʷ�ߵ�λ��
 float Vel_History[NUM];//��ʷ�ߵ��ٶ�
 float Acce_Bias[NUM];//�ߵ����ٶ�Ư����������
 float Last_Acceleration[NUM];
 float Last_Speed[NUM];
}SINS;

SINS openmv_sins;

u8 openmv_datatemp[20];  //���յ������ݻ���

/*
 *openmv���ڽ��ս�����ʽ
 *
 *					1		  |		  2	  	|	  	3		  |	  	4		  ~			7		  |			 8		  ~	  	11	  	|	
 *				 
 *(Ѱ��) 	֡ͷ		  	ģʽ��	 		��ɫ����		  				X								   		  	Y 							
 *
 *(Ѳ��) 	֡ͷ				ģʽ				�ո�			 				 rho							  			theta 	 				 	
 *
 */

/*Ѱ�����*/
u16 openmv_X_coordinate;	
u16 openmv_Y_coordinate;
int Transform_X_coordinate;
int Transform_Y_coordinate;

int True_X_coordinate_pix;
int True_Y_coordinate_pix;
float True_X_coordinate_len;
float True_Y_coordinate_len;
float P_c_x;		//Proportionality coefficient	����ϵ��
float P_c_y;

_vector2_st openmv_point[2];
_vector2_st last_point;
_vector2_st real_point;

u8 color_code_name;

/*Ѳ�߱���*/
_line_st line;
_line_st opmv_line;
_line_st last_line;

void OPENMV_GetOneByte(uint8_t data)
{
	static u8 state = 0;
	
	if(state == 0 && data == 'A')						//֡ͷ	
	{
		state = 1;
		openmv_datatemp[0] = data;
	}
	else if(state == 1)											//ģʽ
	{
		state = 2;
		openmv_datatemp[1] = data - 48;
	}
	else if(state == 2 )											
	{
		state = 3;
		openmv_datatemp[2] = data - 48;
	}
	
/*��һ������*/
	else if(state == 3)			
	{
		state = 4;
		openmv_datatemp[3] = data - 48;
	}
	else if(state == 4)			
	{
		state = 5;
		openmv_datatemp[4] = data - 48;
	}
	else if(state == 5)			
	{
		state = 6;
		openmv_datatemp[5] = data - 48;
	}
	else if(state == 6)			
	{
		state = 7;
		openmv_datatemp[6] = data - 48;
	}
	
/*�ڶ�������*/
	else if(state == 7)			
	{
		state = 8;
		openmv_datatemp[7] = data - 48;
	}
	else if(state == 8)			
	{
		state = 9;
		openmv_datatemp[8] = data - 48;
	}
	else if(state == 9)			
	{
		state = 10;
		openmv_datatemp[9] = data - 48;
	}
	else if(state == 10)			
	{
		state = 0;
		openmv_datatemp[10] = data - 48;
		OPENMV_DataAnl(openmv_datatemp);
	}
	else
		state = 0;
}


void OPENMV_DataAnl(uint8_t *data_buf)
{
	u8 openmv_mode = openmv_datatemp[1];  //ģʽ

	flag.openmv_sta = openmv_mode;
	
	openmv_point[0].x = openmv_datatemp[3] * 1000 + openmv_datatemp[4] * 100 
								 + openmv_datatemp[5] * 10   + openmv_datatemp[6];
	openmv_point[0].y = openmv_datatemp[7] * 1000 + openmv_datatemp[8] * 100 
								 + openmv_datatemp[9] * 10   + openmv_datatemp[10];
	
	openmv_point[0].x /= 10.0;							 
	openmv_point[0].y /= 10.0;
	
	if(openmv_point[0].x == 999 && openmv_point[0].y == 999)  //δ��⵽Ŀ��
	{
		flag.openmv_loss = 1;
		
		openmv_point[1].x = last_point.x;							 
		openmv_point[1].y = last_point.y;
	}
	else
	{			
		flag.openmv_loss = 0;
		
		openmv_point[1].x = openmv_point[0].x - 160;							 
		openmv_point[1].y = openmv_point[0].y - 120;
	}
}

#define LOSS_TIME 1000  // ms
void OPMV_Data_Cal_Task(float fix_heigh,u8 dT_ms)
{

	static int cnt = 0;
	
	if(flag.openmv_loss == 1)
	{
		cnt += dT_ms;
		if(cnt >= LOSS_TIME)
		{
			flag.target_loss = 1;  //openmv��Ұ��Ŀ�궪ʧ1s�����ж�Ŀ�궪ʧ
		}
		else
		{
			flag.target_loss = 0;
		}
	}
	else
	{
		flag.target_loss = 0;
		cnt = 0;
	}
	
	if(flag.target_loss == 0)  //Ŀ��û��ʧ
	{						
			real_point.x = 0.2 * openmv_point[1].x + 0.8 * real_point.x;                      
			real_point.y = 0.2 * openmv_point[1].y + 0.8 * real_point.y;
			
			last_point.x = openmv_point[1].x;
			last_point.y = openmv_point[1].y;
	}
	else
	{
		real_point.x = real_point.y = 0;
	}
	
	
}

/*openmv��ֵ����*/
void OPMV_Param_Set(u8 cmd)
{
	Drv_Uart3SendBuf(&cmd,1);
}

void OPMV_Shot(void)
{
	u8 cmd = 5;
	Drv_Uart3SendBuf(&cmd,1);
}
