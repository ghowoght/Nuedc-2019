#ifndef _SLAVE_H_
#define _SLAVE_H_
#include "sysconfig.h"

u8 		Drv_Slave_Init(void);
void 	Slave_GetOneByte(u8 data);
void 	Slave_DataAnl(void);

void LED_ON(void);
void LED_OFF(void);


#endif
