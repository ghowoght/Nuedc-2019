#ifndef __DRV_OLED_H
#define __DRV_OLED_H

#include "stdint.h"
#include "stdlib.h"

#define OLED_MODE 0
#define SIZE 16
#define XLevelL		0x00
#define XLevelH		0x10
#define Max_Column	128
#define Max_Row		64
#define	Brightness	0xFF 
#define X_WIDTH 	128
#define Y_WIDTH 	64	   



#define READ_SDA   ROM_GPIOPinRead (GPIOD_BASE,GPIO_PIN_1)	//SDA 
#define IIC_SDA_H  ROM_GPIOPinWrite(GPIOD_BASE,GPIO_PIN_1,GPIO_PIN_1)//SDA 
#define IIC_SDA_L  ROM_GPIOPinWrite(GPIOD_BASE,GPIO_PIN_1,0)//SDA
#define IIC_SCL_H  ROM_GPIOPinWrite(GPIOD_BASE,GPIO_PIN_0,GPIO_PIN_0)//SCL
#define IIC_SCL_L  ROM_GPIOPinWrite(GPIOD_BASE,GPIO_PIN_0,0)//SCL

#define OLED_SCLK_Clr() ROM_GPIOPinWrite(GPIOD_BASE,GPIO_PIN_0,0)//CLK
#define OLED_SCLK_Set() ROM_GPIOPinWrite(GPIOD_BASE,GPIO_PIN_0,GPIO_PIN_0)

#define OLED_SDIN_Clr() ROM_GPIOPinWrite(GPIOD_BASE,GPIO_PIN_1,0)//DIN
#define OLED_SDIN_Set() ROM_GPIOPinWrite(GPIOD_BASE,GPIO_PIN_1,GPIO_PIN_1)

#define OLED_CMD  0	//д����
#define OLED_DATA 1	//д����

void OLED_WrCmd(unsigned char IIC_Data);
void OLED_WrDat(unsigned char IIC_Data);

void OLED_GPIO_Init(void);
void OLED_Clear(void);
void OLED_DrawPoint(uint8_t x,uint8_t y,uint8_t t);
void OLED_Fill(uint8_t x1,uint8_t y1,uint8_t x2,uint8_t y2,uint8_t dot);
void OLED_ShowChar(uint8_t x,uint8_t y,uint8_t chr);
void OLED_ShowNum(uint8_t x,uint8_t y,uint32_t num,uint8_t len,uint8_t size);
void OLED_ShowString(uint8_t x,uint8_t y, uint8_t *p);	 
void OLED_Set_Pos(unsigned char x, unsigned char y);
void OLED_ShowCHinese(uint8_t x,uint8_t y,uint8_t no);
void OLED_ShowFloat(uint8_t x,uint8_t y,float num,uint8_t size);

void OLED_Init(void);

#endif



