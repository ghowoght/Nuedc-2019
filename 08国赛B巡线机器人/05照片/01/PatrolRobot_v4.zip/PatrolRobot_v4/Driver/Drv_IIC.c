#include "sysconfig.h"
#include "I2C.h"

#include "Drv_IIC.h"
#include "sysctl.h"
/***********************************************************
@��������Init_I2C
@��ڲ�������
@���ڲ�������
����������TM4CӲ��I2C3��ʼ��
*************************************************************/
void I2C_Init(void) {
  ROM_SysCtlPeripheralEnable(SYSCTL_PERIPH_I2C3); // Enable I2C1 peripheral
  ROM_SysCtlDelay(2); // Insert a few cycles after enabling the peripheral to allow the clock to be fully activated
  ROM_SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOD); // Enable GPIOA peripheral
  ROM_SysCtlDelay(2); // Insert a few cycles after enabling the peripheral to allow the clock to be fully activated
  
  // Use alternate function
  ROM_GPIOPinConfigure(GPIO_PD0_I2C3SCL);
  ROM_GPIOPinConfigure(GPIO_PD1_I2C3SDA);
  
  ROM_GPIOPinTypeI2CSCL(GPIOD_BASE, GPIO_PIN_0); // Use pin with I2C SCL peripheral
  ROM_GPIOPinTypeI2C(GPIOD_BASE, GPIO_PIN_1); // Use pin with I2C peripheral
	
  ROM_I2CMasterInitExpClk(I2C3_BASE, 400*100000,true); // Enable and set frequency to 400 kHz  100
//  ROM_I2CMasterInitExpClk(I2C3_BASE, SysCtlClockGet(),true);          
  ROM_SysCtlDelay(2); // Insert a few cycles after enabling the I2C to allow the clock to be fully activated
}

/***********************************************************
@��������i2cWriteData
@��ڲ�����uint8_t addr, uint8_t regAddr, uint8_t *data, uint8_t length
@���ڲ�������
����������I2Cд����
*************************************************************/
void i2cWriteData(uint8_t addr, uint8_t regAddr, uint8_t *data, uint8_t length) {
  ROM_I2CMasterSlaveAddrSet(I2C3_BASE, addr, false); // Set to write mode
  
  ROM_I2CMasterDataPut(I2C3_BASE, regAddr); // Place address into data register
  ROM_I2CMasterControl(I2C3_BASE, I2C_MASTER_CMD_BURST_SEND_START); // Send start condition
  while (ROM_I2CMasterBusy(I2C3_BASE)); // Wait until transfer is done
  
  for (uint8_t i = 0; i < length - 1; i++) {
    ROM_I2CMasterDataPut(I2C3_BASE, data[i]); // Place data into data register
    ROM_I2CMasterControl(I2C3_BASE, I2C_MASTER_CMD_BURST_SEND_CONT); // Send continues condition
    while (ROM_I2CMasterBusy(I2C3_BASE)); // Wait until transfer is done
  }
  
  ROM_I2CMasterDataPut(I2C3_BASE, data[length - 1]); // Place data into data register
  ROM_I2CMasterControl(I2C3_BASE, I2C_MASTER_CMD_BURST_SEND_FINISH); // Send finish condition
  while (ROM_I2CMasterBusy(I2C3_BASE)); // Wait until transfer is done
}

/***********************************************************
@��������i2cRead
@��ڲ�����uint8_t addr, uint8_t regAddr
@���ڲ�������
����������I2C������
*************************************************************/
uint8_t i2cRead(uint8_t addr, uint8_t regAddr) {
  ROM_I2CMasterSlaveAddrSet(I2C3_BASE, addr, false); // Set to write mode
  
  ROM_I2CMasterDataPut(I2C3_BASE, regAddr); // Place address into data register
  ROM_I2CMasterControl(I2C3_BASE, I2C_MASTER_CMD_SINGLE_SEND); // Send data
  while (ROM_I2CMasterBusy(I2C3_BASE)); // Wait until transfer is done
  
  ROM_I2CMasterSlaveAddrSet(I2C3_BASE, addr, true); // Set to read mode
  
  ROM_I2CMasterControl(I2C3_BASE, I2C_MASTER_CMD_SINGLE_RECEIVE); // Tell master to read data
  while (ROM_I2CMasterBusy(I2C3_BASE)); // Wait until transfer is done
  return ROM_I2CMasterDataGet(I2C3_BASE); // Read data
}

/***********************************************************
@��������i2cWrite
@��ڲ�����uint8_t addr, uint8_t regAddr, uint8_t data
@���ڲ�������
����������I2Cд����
*************************************************************/
void i2cWrite(uint8_t addr, uint8_t regAddr, uint8_t data) {
  i2cWriteData(addr, regAddr, &data, 1);
}


/***********************************************************
@��������i2cReadData
@��ڲ�����uint8_t addr, uint8_t regAddr, uint8_t *data,
uint8_t length
@���ڲ�������
����������I2C������
*************************************************************/
void i2cReadData(uint8_t addr, uint8_t regAddr, uint8_t *data, uint8_t length) {
  ROM_I2CMasterSlaveAddrSet(I2C3_BASE, addr, false); // Set to write mode
  ROM_I2CMasterDataPut(I2C3_BASE, regAddr); // Place address into data register
  ROM_I2CMasterControl(I2C3_BASE, I2C_MASTER_CMD_SINGLE_SEND); // Send data
  while (ROM_I2CMasterBusy(I2C3_BASE)); // Wait until transfer is done 
  ROM_I2CMasterSlaveAddrSet(I2C3_BASE, addr, true); // Set to read mode
  ROM_I2CMasterControl(I2C3_BASE, I2C_MASTER_CMD_BURST_RECEIVE_START); // Send start condition
  while (ROM_I2CMasterBusy(I2C3_BASE)); // Wait until transfer is done
  data[0] = ROM_I2CMasterDataGet(I2C3_BASE); // Place data into data register 
  for (uint8_t i = 1; i < length - 1; i++) 
	{
    ROM_I2CMasterControl(I2C3_BASE, I2C_MASTER_CMD_BURST_RECEIVE_CONT); // Send continues condition
    while (ROM_I2CMasterBusy(I2C3_BASE)); // Wait until transfer is done
    data[i] = ROM_I2CMasterDataGet(I2C3_BASE); // Place data into data register
  }
  ROM_I2CMasterControl(I2C3_BASE, I2C_MASTER_CMD_BURST_RECEIVE_FINISH); // Send finish condition
  while (ROM_I2CMasterBusy(I2C3_BASE)); // Wait until transfer is done
  data[length - 1] = ROM_I2CMasterDataGet(I2C3_BASE); // Place data into data register
}


void Single_WriteI2C(unsigned char SlaveAddress,unsigned char REG_Address,unsigned char REG_data)
{
  i2cWrite(SlaveAddress,REG_Address,REG_data);
}	

unsigned char Single_ReadI2C(unsigned char SlaveAddress,unsigned char REG_Address)
{
  return i2cRead(SlaveAddress,REG_Address);
}

short int Double_ReadI2C(unsigned char SlaveAddress,unsigned char REG_Address)
{
  unsigned char msb , lsb ;
  msb = i2cRead(SlaveAddress,REG_Address);
  lsb = i2cRead(SlaveAddress,REG_Address+1);
  return ( ((short int)msb) << 8 | lsb) ;
}

////////////////////////
/***********************************************************
@��������Init_I2C2
@��ڲ�������
@���ڲ�������
����������TM4CӲ��I2C��ʼ��
*************************************************************/
void Init_I2C0(void) {
  ROM_SysCtlPeripheralEnable(SYSCTL_PERIPH_I2C0); // Enable I2C0 peripheral
  ROM_SysCtlDelay(2); // Insert a few cycles after enabling the peripheral to allow the clock to be fully activated
  ROM_SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOB); // Enable GPIOB peripheral
  ROM_SysCtlDelay(2); // Insert a few cycles after enabling the peripheral to allow the clock to be fully activated
  
  // Use alternate function
  ROM_GPIOPinConfigure(GPIO_PB2_I2C0SCL);
  ROM_GPIOPinConfigure(GPIO_PB3_I2C0SDA);
  
  ROM_GPIOPinTypeI2CSCL(GPIOB_BASE, GPIO_PIN_2); // Use pin with I2C SCL peripheral
  ROM_GPIOPinTypeI2C(GPIOB_BASE, GPIO_PIN_3); // Use pin with I2C peripheral
  
  ROM_I2CMasterInitExpClk(I2C0_BASE, SysCtlClockGet(),true); // Enable and set frequency to 400 kHz
  
  ROM_SysCtlDelay(2); // Insert a few cycles after enabling the I2C to allow the clock to be fully activated
}

/***********************************************************
@��������i2cWriteData
@��ڲ�����uint8_t addr, uint8_t regAddr, uint8_t *data, uint8_t length
@���ڲ�������
����������I2Cд����
*************************************************************/
void i2c0WriteData(uint8_t addr, uint8_t regAddr, uint8_t *data, uint8_t length) {
  ROM_I2CMasterSlaveAddrSet(I2C0_BASE, addr, false); // Set to write mode
  
  ROM_I2CMasterDataPut(I2C0_BASE, regAddr); // Place address into data register
  ROM_I2CMasterControl(I2C0_BASE, I2C_MASTER_CMD_BURST_SEND_START); // Send start condition
  while (ROM_I2CMasterBusy(I2C0_BASE)); // Wait until transfer is done
  
  for (uint8_t i = 0; i < length - 1; i++) {
    ROM_I2CMasterDataPut(I2C0_BASE, data[i]); // Place data into data register
    ROM_I2CMasterControl(I2C0_BASE, I2C_MASTER_CMD_BURST_SEND_CONT); // Send continues condition
    while (ROM_I2CMasterBusy(I2C0_BASE)); // Wait until transfer is done
  }
  
  ROM_I2CMasterDataPut(I2C0_BASE, data[length - 1]); // Place data into data register
  ROM_I2CMasterControl(I2C0_BASE, I2C_MASTER_CMD_BURST_SEND_FINISH); // Send finish condition
  while (ROM_I2CMasterBusy(I2C0_BASE)); // Wait until transfer is done
}

/***********************************************************
@��������i2cRead
@��ڲ�����uint8_t addr, uint8_t regAddr
@���ڲ�������
����������I2C������
*************************************************************/
uint8_t i2c0Read(uint8_t addr, uint8_t regAddr) {
  ROM_I2CMasterSlaveAddrSet(I2C0_BASE, addr, false); // Set to write mode
  
  ROM_I2CMasterDataPut(I2C0_BASE, regAddr); // Place address into data register
  ROM_I2CMasterControl(I2C0_BASE, I2C_MASTER_CMD_SINGLE_SEND); // Send data
  while (ROM_I2CMasterBusy(I2C0_BASE)); // Wait until transfer is done
  
  ROM_I2CMasterSlaveAddrSet(I2C0_BASE, addr, true); // Set to read mode
  
  ROM_I2CMasterControl(I2C0_BASE, I2C_MASTER_CMD_SINGLE_RECEIVE); // Tell master to read data
  while (ROM_I2CMasterBusy(I2C0_BASE)); // Wait until transfer is done
  return ROM_I2CMasterDataGet(I2C0_BASE); // Read data
}

/***********************************************************
@��������i2cWrite
@��ڲ�����uint8_t addr, uint8_t regAddr, uint8_t data
@���ڲ�������
����������I2Cд����
*************************************************************/
void i2c0Write(uint8_t addr, uint8_t regAddr, uint8_t data) {
  i2c0WriteData(addr, regAddr, &data, 1);
}


/***********************************************************
@��������i2cReadData
@��ڲ�����uint8_t addr, uint8_t regAddr, uint8_t *data,
uint8_t length
@���ڲ�������
����������I2C������
*************************************************************/
void i2c0ReadData(uint8_t addr, uint8_t regAddr, uint8_t *data, uint8_t length) {
  ROM_I2CMasterSlaveAddrSet(I2C0_BASE, addr, false); // Set to write mode
  ROM_I2CMasterDataPut(I2C0_BASE, regAddr); // Place address into data register
  ROM_I2CMasterControl(I2C0_BASE, I2C_MASTER_CMD_SINGLE_SEND); // Send data
  while (ROM_I2CMasterBusy(I2C0_BASE)); // Wait until transfer is done 
  ROM_I2CMasterSlaveAddrSet(I2C0_BASE, addr, true); // Set to read mode
  ROM_I2CMasterControl(I2C0_BASE, I2C_MASTER_CMD_BURST_RECEIVE_START); // Send start condition
  while (ROM_I2CMasterBusy(I2C0_BASE)); // Wait until transfer is done
  data[0] = ROM_I2CMasterDataGet(I2C0_BASE); // Place data into data register 
  for (uint8_t i = 1; i < length - 1; i++) 
	{
    ROM_I2CMasterControl(I2C0_BASE, I2C_MASTER_CMD_BURST_RECEIVE_CONT); // Send continues condition
    while (ROM_I2CMasterBusy(I2C0_BASE)); // Wait until transfer is done
    data[i] = ROM_I2CMasterDataGet(I2C0_BASE); // Place data into data register
  }
  ROM_I2CMasterControl(I2C0_BASE, I2C_MASTER_CMD_BURST_RECEIVE_FINISH); // Send finish condition
  while (ROM_I2CMasterBusy(I2C0_BASE)); // Wait until transfer is done
  data[length - 1] = ROM_I2CMasterDataGet(I2C0_BASE); // Place data into data register
}
